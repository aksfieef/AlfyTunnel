plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.alfy.tunnel"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.alfy.tunnel"
        minSdk = 24
        targetSdk = 34
        versionCode = 91
        versionName = "2.3"
        resourceConfigurations += listOf("en", "in")
        ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a") }
    }
    externalNativeBuild {
        cmake { path = file("src/main/cpp/CMakeLists.txt") }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
        debug {
            isDebuggable = false
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
        freeCompilerArgs += listOf("-Xno-param-assertions", "-Xno-call-assertions", "-Xno-receiver-assertions")
    }
    buildFeatures {
        compose = true
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.14"
    }
    packaging {
        resources {
            excludes += setOf("DebugProbesKt.bin", "/kotlin/**", "/META-INF/*.version", "/META-INF/{AL2.0,LGPL2.1}", "/META-INF/versions/**", "META-INF/DEPENDENCIES", "META-INF/LICENSE*", "META-INF/NOTICE*", "META-INF/*.SF", "META-INF/*.DSA", "META-INF/*.RSA")
        }
    }
    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-core")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.3")
    implementation("androidx.core:core:1.13.1")
    implementation("androidx.datastore:datastore-preferences:1.1.1")
    implementation("com.hierynomus:sshj:0.41.2")
    implementation("com.jcraft:jzlib:1.1.3")
    implementation(files("libs/hev-socks5-tunnel.aar"))
}

// Unduh otomatis hev-socks5-tunnel.aar bila belum ada di app/libs (aman offline jika file sudah ditaruh manual).
val hevAar = layout.projectDirectory.file("libs/hev-socks5-tunnel.aar").asFile
val fetchHevAar by tasks.registering {
    onlyIf { !hevAar.exists() }
    doLast {
        fun download(url: String, dest: java.io.File): Boolean = try {
            val c = java.net.URL(url).openConnection() as java.net.HttpURLConnection
            c.connectTimeout = 20000; c.readTimeout = 60000; c.instanceFollowRedirects = true
            c.setRequestProperty("User-Agent", "AlfyTunnel-Build")
            if (c.responseCode !in 200..299) false else {
                dest.parentFile.mkdirs()
                val tmp = java.io.File(dest.path + ".part")
                c.inputStream.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                tmp.renameTo(dest) && dest.length() > 0
            }
        } catch (e: Exception) { false }

        var ok = false
        try {
            val c = java.net.URL("https://api.github.com/repos/heiher/hev-socks5-tunnel/releases/latest").openConnection() as java.net.HttpURLConnection
            c.connectTimeout = 20000; c.readTimeout = 30000
            c.setRequestProperty("User-Agent", "AlfyTunnel-Build")
            c.setRequestProperty("Accept", "application/vnd.github+json")
            if (c.responseCode in 200..299) {
                val json = groovy.json.JsonSlurper().parseText(c.inputStream.bufferedReader().readText()) as Map<*, *>
                val assets = json["assets"] as? List<*> ?: emptyList<Any>()
                val url = assets.mapNotNull { (it as? Map<*, *>)?.get("browser_download_url") as? String }
                    .firstOrNull { it.endsWith(".aar") }
                if (url != null) ok = download(url, hevAar)
            }
        } catch (e: Exception) { }
        if (!ok) ok = download("https://github.com/heiher/hev-socks5-tunnel/releases/latest/download/hev-socks5-tunnel.aar", hevAar)
        if (!ok) throw GradleException("hev-socks5-tunnel.aar tidak ada & gagal diunduh. Taruh manual di app/libs/hev-socks5-tunnel.aar lalu build ulang.")
    }
}
tasks.named("preBuild") { dependsOn(fetchHevAar) }
