#include <jni.h>
#include <stdint.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#ifndef SO_ORIGINAL_DST
#define SO_ORIGINAL_DST 80
#endif

/* Membaca alamat tujuan asli (sebelum REDIRECT iptables) dari socket yang di-accept.
 * Return: (ip_host_order << 16) | port_host_order, atau -1 bila gagal / bukan IPv4. */
JNIEXPORT jlong JNICALL
Java_com_alfy_tunnel_OrigDst_getOriginalDst(JNIEnv *env, jclass clazz, jint fd) {
    (void) env;
    (void) clazz;
    struct sockaddr_in addr;
    socklen_t len = sizeof(addr);
    __builtin_memset(&addr, 0, sizeof(addr));
    if (getsockopt(fd, SOL_IP, SO_ORIGINAL_DST, &addr, &len) == 0 && addr.sin_family == AF_INET) {
        return (jlong) (((uint64_t) (uint32_t) ntohl(addr.sin_addr.s_addr) << 16) | (uint16_t) ntohs(addr.sin_port));
    }
    return -1L;
}
