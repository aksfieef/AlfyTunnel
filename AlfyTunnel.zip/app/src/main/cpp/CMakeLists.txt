cmake_minimum_required(VERSION 3.18.1)
project("origdst" C)
add_library(origdst SHARED origdst.c)
