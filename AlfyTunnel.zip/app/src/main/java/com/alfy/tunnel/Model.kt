package com.alfy.tunnel

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.update
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

data class Config(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "Config baru",
    val mode: Int = 0,
    val server: String = "",
    val proxy: String = "",
    val sni: String = "",
    val payload: String = DEFAULT_PAYLOAD,
    val dnsOn: Boolean = true,
    val dns1: String = "1.1.1.1",
    val dns2: String = "1.0.0.1",
    val isPinned: Boolean = false,
    val pilotType: String = "AUTO",
    val customTag: String = "",
    val privateKey: String = "",
    val keyPass: String = "",
    val wsFrame: Boolean = false
) {
    fun toJson(): JSONObject = JSONObject()
        .put("id", id).put("name", name).put("mode", mode).put("server", server)
        .put("proxy", proxy).put("sni", sni).put("payload", payload)
        .put("dnsOn", dnsOn).put("dns1", dns1).put("dns2", dns2)
        .put("isPinned", isPinned)
        .put("pilotType", pilotType).put("customTag", customTag)
        .put("privateKey", privateKey).put("keyPass", keyPass).put("wsFrame", wsFrame)

    companion object {
        const val DEFAULT_PAYLOAD = ""

        fun fromJson(o: JSONObject): Config {
            val m = o.optInt("mode", 0)
            require(m in 0..2) { "mode tidak valid" }
            return Config(
                id = o.optString("id").ifBlank { UUID.randomUUID().toString() },
                name = o.getString("name"),
                mode = m,
                server = o.optString("server"),
                proxy = o.optString("proxy"),
                sni = o.optString("sni"),
                payload = o.optString("payload"),
                dnsOn = o.optBoolean("dnsOn", false),
                dns1 = o.optString("dns1", "1.1.1.1"),
                dns2 = o.optString("dns2", "1.0.0.1"),
                isPinned = o.optBoolean("isPinned", false),
                pilotType = o.optString("pilotType", "AUTO").ifBlank { "AUTO" },
                customTag = o.optString("customTag"),
                privateKey = o.optString("privateKey", ""),
                keyPass = o.optString("keyPass", ""),
                wsFrame = o.optBoolean("wsFrame", false)
            )
        }
    }
}

data class Srv(val host: String, val port: Int, val user: String, val pass: String) {
    companion object {
        fun parse(s: String): Srv? {
            val t = s.trim()
            val at = t.indexOf('@')
            if (at < 1) return null
            val hp = parseHp(t.substring(0, at)) ?: return null
            val up = t.substring(at + 1)
            val c = up.indexOf(':')
            // Format host:port@user (tanpa :pass) dipakai bersama Private Key -> pass kosong.
            if (c < 0) return if (up.isNotBlank()) Srv(hp.first, hp.second, up, "") else null
            if (c < 1) return null
            return Srv(hp.first, hp.second, up.substring(0, c), up.substring(c + 1))
        }
    }
}

fun parseHp(s: String): Pair<String, Int>? {
    val t = s.trim()
    val c = t.lastIndexOf(':')
    if (c < 1) return null
    val p = t.substring(c + 1).toIntOrNull() ?: return null
    if (p !in 1..65535) return null
    return t.substring(0, c) to p
}

/** Proxy: host:port atau user:pass@host:port (untuk header Proxy-Authorization). */
data class Px(val host: String, val port: Int, val user: String?, val pass: String?) {
    val auth: String?
        get() = if (user == null) null else android.util.Base64.encodeToString(
            "$user:${pass.orEmpty()}".toByteArray(Charsets.UTF_8), android.util.Base64.NO_WRAP
        )
    val hdr: String? get() = auth?.let { "Proxy-Authorization: Basic $it" }
}

fun parseProxy(s: String): Px? {
    val t = s.trim()
    val at = t.lastIndexOf('@')
    if (at < 0) return parseHp(t)?.let { Px(it.first, it.second, null, null) }
    val hp = parseHp(t.substring(at + 1)) ?: return null
    val cred = t.substring(0, at)
    val c = cred.indexOf(':')
    if (c < 1) return null
    return Px(hp.first, hp.second, cred.substring(0, c), cred.substring(c + 1))
}

enum class St { IDLE, CONNECTING, CONNECTED, RECONNECTING }

object Bus {
    val status = MutableStateFlow(St.IDLE)
    val logs = MutableStateFlow<List<String>>(emptyList())
    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.US)

    /** true setelah "Connected" tampil; direset saat sesi sambung baru dimulai. */
    @Volatile var muted = false

    @Synchronized
    fun log(m: String, force: Boolean = false) {
        val dbgOn = Prefs.dbg.value
        val pingOn = Prefs.pingOn.value
        // Log internal hanya muncul bila toggle terkait aktif.
        if (!dbgOn && (m.startsWith("Watchdog"))) return
        val isPing = m.startsWith("HTTP Ping")
        if (isPing && !pingOn) return
        // Setelah Connected: log non-ping berhenti bila Debug & Ping OFF; log HTTP Ping selalu lolos jika Ping aktif.
        if (!force && !isPing && muted && !dbgOn && !pingOn) return
        if (m == "Connected") muted = true
        val line = "[${fmt.format(Date())}] $m"
        logs.update { (it + line).takeLast(150) }
    }

    fun clear() {
        logs.value = emptyList()
    }
}

private val Context.ds by preferencesDataStore("alfy")

class Store(private val ctx: Context) {
    private val kC = stringPreferencesKey("cfgs")
    private val kS = stringPreferencesKey("cur")

    val configs: Flow<List<Config>> = ctx.ds.data.map { parse(it[kC]) }
    val current: Flow<String?> = ctx.ds.data.map { it[kS] }

    suspend fun saveAll(l: List<Config>) {
        ctx.ds.edit { it[kC] = JSONArray(l.map { c -> c.toJson() }).toString() }
    }

    suspend fun setCurrent(id: String) {
        ctx.ds.edit { it[kS] = id }
    }

    private fun parse(s: String?): List<Config> = try {
        val a = JSONArray(s ?: "[]")
        (0 until a.length()).map { Config.fromJson(a.getJSONObject(it)) }
    } catch (e: Exception) {
        emptyList()
    }
}
