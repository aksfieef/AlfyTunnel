package com.alfy.tunnel

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.VpnService
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.os.PowerManager
import android.widget.RemoteViews
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.net.Inet4Address
import java.net.NetworkInterface
import org.json.JSONObject
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException

class VpnSvc : VpnService() {
    companion object {
        const val ACT_START = "com.alfy.tunnel.START"
        const val ACT_STOP = "com.alfy.tunnel.STOP"
        const val ACT_RECONNECT = "com.alfy.tunnel.RECONNECT"
        const val EXTRA = "cfg"
        private const val NOTIF_GAP = 1000L
        private const val BC_RECONNECT = "com.alfy.tunnel.BC_RECONNECT"
        private const val BC_STOP = "com.alfy.tunnel.BC_STOP"
        private const val CH = "alfy_status"
        private const val NID = 1
        @Volatile var inst: VpnSvc? = null

        /** Sambung ulang total (dipakai tekan-tahan pada speedometer mengambang). */
        fun reconnect() {
            val s = inst ?: return
            s.requestHardReset()
        }

        /** Paksa notifikasi diperbarui sekarang juga (dipanggil dari UI/Prefs/VM). */
        fun refreshNotif() {
            val s = inst ?: return
            s.netH.post { s.refreshNotif() }
        }

        /** Config aktif diganti namanya: sinkronkan nama di service lalu update notifikasi. */
        fun renameLive(id: String, name: String) {
            val s = inst ?: return
            val c = s.lastCfg
            if (c != null && c.id == id) {
                val n = c.copy(name = name)
                s.lastCfg = n
                s.cfgName = name.ifBlank { "AlfyTunnel" }
                try { s.saveCfg(n) } catch (e: Throwable) { }
            }
            s.netH.post { s.refreshNotif() }
        }
    }

    @Volatile private var gen = 0
    @Volatile private var kick = false
    @Volatile private var wdGen = -1
    @Volatile private var wdStreak = 0
    @Volatile private var wdLast = 0L
    @Volatile private var connAt = 0L
    @Volatile private var resetAt = 0L
    private val GRACE_MS = 5000L
    private val reconLock2 = Any()
    // Waktu sukses terakhir (Auth complete). Watchdog manapun dilarang reset total dalam 10 detik sesudahnya.
    @Volatile private var lastConnectTime = 0L
    private val RESET_GRACE_MS = 10000L
    // Penanda gen yang pernah benar-benar tersambung (Watchdog Reconnecting hanya boleh aktif sesudah itu)
    @Volatile private var rcEverConn = -1
    private fun graceLeft(): Long {
        val t = lastConnectTime
        if (t == 0L) return 0L
        return (RESET_GRACE_MS - (System.currentTimeMillis() - t)).coerceAtLeast(0L)
    }
    @Volatile private var worker: Thread? = null
    @Volatile private var lastCfg: Config? = null
    private var tun: ParcelFileDescriptor? = null
    private var link: TunnelLink? = null
    private var stack: TunStack? = null
    private var proxy: HttpProxyServer? = null
    private var hud: Hud? = null
    private var wl: PowerManager.WakeLock? = null
    @Volatile private var baseInfo = "Menghubungkan…"
    @Volatile private var cfgName = "AlfyTunnel"
    @Volatile private var lastSig = ""
    // Anti-hilang: notifikasi diperbarui paling cepat sekali per NOTIF_GAP ms (update beruntun membuat
    // SystemUI membatalkan inflate tampilan yang sedang dibuka sehingga detail notifikasi kosong/hilang).
    private val notifLock = Any()
    @Volatile private var lastNotifAt = 0L
    private val notifFlush = Runnable { refreshNotif() }
    // Mode "Terputus": layanan foreground TETAP hidup (notifikasi + animasi warna) sampai app di-swipe / dihentikan paksa.
    @Volatile private var idleKeep = false
    @Volatile private var idleScan = false
    @Volatile private var destroyed = false
    private val ticker = object : Runnable {
        override fun run() {
            if (!idleKeep || destroyed) return
            refreshNotif()
            netH.postDelayed(this, if (Prefs.notifAnim()) 500L else 5000L)
        }
    }
    // Detik durasi tersambung: sambil CONNECTED, notifikasi diperbarui tiap detik
    private val connTick = object : Runnable {
        override fun run() {
            if (destroyed || Bus.status.value != St.CONNECTED) return
            refreshNotif()
            netH.postDelayed(this, 1000L)
        }
    }
    private fun connDur(): String {
        if (Bus.status.value != St.CONNECTED || connAt == 0L) return ""
        val s = ((System.currentTimeMillis() - connAt) / 1000L).coerceAtLeast(0L)
        val h = s / 3600; val m = (s % 3600) / 60; val sc = s % 60
        return if (h > 0) String.format("%d.%02d.%02d", h, m, sc) else String.format("%d.%02d", m, sc)
    }
    private val reconLock = Any()
    // Pengawas: bila status tersangkut CONNECTING/RECONNECTING terlalu lama atau worker mati diam-diam, sambung ulang total otomatis
    private var stateLast: St? = null
    private var stateAt = 0L
    private val supervisor = object : Runnable {
        override fun run() {
            if (destroyed) return
            try { superviseOnce() } catch (e: Throwable) { }
            netH.postDelayed(this, 15000L)
        }
    }
    // Watchdog 2 detik: status CONNECTING lebih dari CONN_WD_MS -> abort/cleanup (shutdown) lalu connect ulang otomatis
    private val CONN_WD_MS = 2000L
    @Volatile private var connWdGen = -1
    private val connWd = Runnable {
        if (destroyed) return@Runnable
        val g = connWdGen
        if (gen != g || Bus.status.value != St.CONNECTING) return@Runnable
        wdReset("Watchdog: macet Menyambungkan >${CONN_WD_MS / 1000} detik, batalkan & sambung ulang")
    }
    // Mutex semua watchdog: hanya satu reset total berjalan pada satu waktu
    private val wdBusy = java.util.concurrent.atomic.AtomicBoolean(false)
    private fun wdReset(reason: String): Boolean {
        val cfg = lastCfg ?: return false
        if (graceLeft() > 0L) { Bus.log("Watchdog: reset diabaikan (masa tenggang 10 detik setelah tersambung)"); return false }
        if (!wdBusy.compareAndSet(false, true)) return false
        Bus.log(reason)
        Thread {
            try {
                // Cek ulang tepat sebelum eksekusi: sukses koneksi bisa terjadi di antara keputusan reset dan thread ini berjalan
                if (graceLeft() > 0L) { Bus.log("Watchdog: reset dibatalkan (koneksi baru saja berhasil)"); return@Thread }
                performHardReset(cfg)
            } finally { wdBusy.set(false) }
        }.also { it.isDaemon = true; it.start() }
        return true
    }
    // Watchdog 1: status RECONNECTING lebih lama dari batas (Prefs) -> reset total
    private val rcWd: Runnable by lazy { Runnable {
        if (destroyed || !Prefs.wdReconOn.value) return@Runnable
        val g = rcWdGen
        if (gen != g || Bus.status.value != St.RECONNECTING || rcEverConn != g) return@Runnable
        val left = graceLeft()
        if (left > 0L) { netH.postDelayed(rcWd, left + 100L); return@Runnable } // masih masa tenggang: cek lagi setelahnya
        wdReset("Watchdog: macet Menyambung ulang >${Prefs.wdReconSec.value} detik, reset total")
    } }
    @Volatile private var rcWdGen = -1
    private fun armRcWd(g: Int) {
        netH.removeCallbacks(rcWd)
        if (!Prefs.wdReconOn.value) return
        rcWdGen = g
        netH.postDelayed(rcWd, Prefs.wdReconSec.value.coerceAtLeast(1) * 1000L)
    }
    // Watchdog 2: tersambung tapi byte TUN (rx+tx) tidak berubah selama batas (Prefs) -> reset total
    @Volatile private var trafWdGen = -1
    private fun startTrafficWd(g: Int) {
        if (trafWdGen == g) return
        trafWdGen = g
        Thread {
            var last = -1L
            var idle = 0
            try {
                while (gen == g && !destroyed) {
                    Thread.sleep(1000)
                    if (gen != g) break
                    val now = Mon.rx.get() + Mon.tx.get()
                    if (!Prefs.wdZeroOn.value || Bus.status.value != St.CONNECTED || last < 0L || now != last) {
                        idle = 0
                    } else {
                        idle++
                        if (idle >= Prefs.wdZeroSec.value.coerceAtLeast(1)) {
                            if (wdReset("Watchdog: tersambung tapi 0 KB/s selama ${Prefs.wdZeroSec.value} detik, reset total")) break
                            idle = 0
                        }
                    }
                    last = now
                }
            } catch (e: InterruptedException) { }
        }.also { it.isDaemon = true; it.start() }
    }
    private fun armConnWd(g: Int) {
        connWdGen = g
        netH.removeCallbacks(connWd)
        netH.postDelayed(connWd, CONN_WD_MS)
    }

    private fun superviseOnce() {
        val st = Bus.status.value
        val now = android.os.SystemClock.elapsedRealtime()
        if (st != stateLast) { stateLast = st; stateAt = now; return }
        if (st == St.IDLE) return
        val cfg = lastCfg ?: loadCfg() ?: return
        if (graceLeft() > 0L) return
        if (worker?.isAlive != true) {
            Bus.log("Pengawas: worker mati, sambung ulang total")
            lastCfg = cfg
            stateAt = now
            Thread { performHardReset(cfg) }.also { it.isDaemon = true; it.start() }
            return
        }
        if ((st == St.CONNECTING || st == St.RECONNECTING) && now - stateAt > 60000L) {
            Bus.log("Pengawas: macet >60 detik, sambung ulang total")
            stateAt = now
            Thread { performHardReset(cfg) }.also { it.isDaemon = true; it.start() }
        }
    }

    private fun statusIcon(): Int = when (Bus.status.value) {
        St.CONNECTED -> R.drawable.ic_stat_connected
        St.CONNECTING -> R.drawable.ic_stat_connecting
        St.RECONNECTING -> R.drawable.ic_stat_reconnect
        else -> R.drawable.ic_stat_connecting
    }

    /** Status berubah -> notifikasi (ikon & teks) langsung diperbarui, tanpa menunggu jeda anti-spam. */
    private fun forceNotif() {
        if (destroyed || (Bus.status.value == St.IDLE && !idleKeep)) return
        try {
            synchronized(notifLock) {
                getSystemService(NotificationManager::class.java).notify(NID, notif())
            }
        } catch (e: Throwable) { }
    }
    private var chMade = false
    private var netCb: ConnectivityManager.NetworkCallback? = null
    private var netSeen = false
    @Volatile private var curNet: Network? = null
    @Volatile private var lostNet: Network? = null
    @Volatile private var netChanged = false
    private val netH = Handler(Looper.getMainLooper())
    private val netKick = Runnable { fastReconnect() }
    private val stopPi by lazy {
        actionPi(10, ACT_STOP)
    }
    /** Tombol notifikasi langsung ke service (tanpa lompatan receiver) supaya cukup sekali ketuk. */
    private fun actionPi(code: Int, action: String): PendingIntent {
        val i = Intent(this, VpnSvc::class.java).setAction(action)
        val fl = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        return if (Build.VERSION.SDK_INT >= 26) PendingIntent.getForegroundService(this, code, i, fl)
        else PendingIntent.getService(this, code, i, fl)
    }
    private val reconPi by lazy {
        actionPi(20, ACT_RECONNECT)
    }
    private val openPi by lazy {
        PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
    }

    private val actRx = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            when (i?.action) {
                BC_RECONNECT -> requestHardReset()
                BC_STOP -> shutdown()
            }
        }
    }
    private var rxReg = false

    // ===== Global overlay toast (pill) =====
    private val ovScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val ovH = Handler(Looper.getMainLooper())
    private var ovView: android.view.View? = null
    private var ovWm: android.view.WindowManager? = null
    private val ovHide = Runnable { hideOverlay() }

    private fun hideOverlay() {
        ovH.removeCallbacks(ovHide)
        val v = ovView
        ovView = null
        if (v != null) { try { ovWm?.removeViewImmediate(v) } catch (e: Throwable) { } }
        ovWm = null
    }

    private fun showOverlay(text: String, color: Int) {
        hideOverlay()
        try {
            val acc = AccSvc.inst
            val canSys = Build.VERSION.SDK_INT < 23 || android.provider.Settings.canDrawOverlays(this)
            val host: Context = if (canSys) this else acc ?: return
            val type = if (canSys) {
                if (Build.VERSION.SDK_INT >= 26) android.view.WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                else android.view.WindowManager.LayoutParams.TYPE_PHONE
            } else android.view.WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
            val wm = host.getSystemService(Context.WINDOW_SERVICE) as android.view.WindowManager
            val dp = resources.displayMetrics.density
            val row = android.widget.LinearLayout(host).apply {
                orientation = android.widget.LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.CENTER_VERTICAL
                setPadding((12 * dp).toInt(), (8 * dp).toInt(), (20 * dp).toInt(), (8 * dp).toInt())
                background = android.graphics.drawable.GradientDrawable().apply {
                    setColor(android.graphics.Color.parseColor("#F0202020"))
                    cornerRadius = 100 * dp
                }
                addView(android.widget.ImageView(host).apply {
                    scaleType = android.widget.ImageView.ScaleType.FIT_CENTER
                    setImageResource(R.drawable.ic_launcher)
                }, android.widget.LinearLayout.LayoutParams((30 * dp).toInt(), (30 * dp).toInt()))
                addView(android.widget.TextView(host).apply {
                    this.text = text
                    setTextColor(color)
                    textSize = 15f
                    setTypeface(typeface, android.graphics.Typeface.BOLD)
                    setPadding((10 * dp).toInt(), 0, 0, 0)
                })
            }
            val lp = android.view.WindowManager.LayoutParams(
                android.view.ViewGroup.LayoutParams.WRAP_CONTENT,
                android.view.ViewGroup.LayoutParams.WRAP_CONTENT,
                type,
                android.view.WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    android.view.WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    android.view.WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                android.graphics.PixelFormat.TRANSLUCENT
            ).apply {
                gravity = android.view.Gravity.BOTTOM or android.view.Gravity.CENTER_HORIZONTAL
                y = (96 * dp).toInt()
            }
            wm.addView(row, lp)
            ovView = row
            ovWm = wm
            ovH.postDelayed(ovHide, 3000)
        } catch (e: Throwable) { }
    }

    override fun onCreate() {
        super.onCreate()
        // Notifikasi standar SEGERA, sebelum init apa pun & sebelum SSH dimulai
        try { fgStd("Menghubungkan…") } catch (e: Throwable) { }
        Prefs.init(this)
        inst = this
        hud = Hud(this, this)
        ovScope.launch {
            Bus.status.collect { st ->
                when (st) {
                    St.CONNECTED -> showOverlay("Connected", android.graphics.Color.rgb(0, 255, 0))
                    St.CONNECTING -> showOverlay("Menyambungkan...", android.graphics.Color.rgb(255, 0, 0))
                    St.RECONNECTING -> showOverlay("Menyambungkan ulang...", android.graphics.Color.rgb(255, 0, 0))
                    else -> {}
                }
                netH.post { forceNotif() }
                if (st == St.CONNECTED) { netH.removeCallbacks(connTick); netH.postDelayed(connTick, 1000L) }
            }
        }
        netH.postDelayed(supervisor, 15000L)
        regNet()
        try {
            val f = IntentFilter().apply { addAction(BC_RECONNECT); addAction(BC_STOP) }
            if (Build.VERSION.SDK_INT >= 33) registerReceiver(actRx, f, Context.RECEIVER_NOT_EXPORTED)
            else registerReceiver(actRx, f)
            rxReg = true
        } catch (e: Exception) { }
    }

    private fun requestHardReset() {
        val cfg = lastCfg
        if (cfg != null && Bus.status.value != St.IDLE) {
            // Anti ketuk beruntun: reset yang baru dimulai tidak dibatalkan oleh reset berikutnya
            val now = android.os.SystemClock.elapsedRealtime()
            if (now - resetAt < 4000L) return
            resetAt = now
            Thread { performHardReset(cfg) }.also { it.isDaemon = true; it.start() }
        }
    }

    private fun netValidated(): Boolean = try {
        val cm = getSystemService(ConnectivityManager::class.java)
        val n = cm.activeNetwork
        val c = if (n != null) cm.getNetworkCapabilities(n) else null
        c != null && c.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    } catch (e: Exception) { false }

    private fun fastReconnect() {
        if (worker?.isAlive == true && Bus.status.value != St.IDLE) {
            val left = GRACE_MS - (System.currentTimeMillis() - connAt)
            if (connAt != 0L && left > 0 && Bus.status.value == St.CONNECTED) {
                netH.removeCallbacks(netKick)
                netH.postDelayed(netKick, left + 200)
                return
            }
            // Jangan putus koneksi hanya karena status VALIDATED/callback jaringan: putus hanya bila jaringan fisik berganti atau link mati
            if (!netChanged && link?.alive == true) return
            netChanged = false
            requestHardReset()
        }
    }

    private fun regNet() {
        try {
            val cm = getSystemService(ConnectivityManager::class.java)
            val cb = object : ConnectivityManager.NetworkCallback() {
                private fun phys(n: Network): Boolean = try {
                    val c = cm.getNetworkCapabilities(n)
                    c == null || !c.hasTransport(NetworkCapabilities.TRANSPORT_VPN)
                } catch (e: Throwable) { true }

                override fun onAvailable(network: Network) {
                    if (!phys(network)) return
                    val prev = curNet
                    curNet = network
                    if (!netSeen) { netSeen = true; return }
                    if (Bus.status.value == St.RECONNECTING) {
                        // Sedang menyambung ulang & jaringan kembali: coba sekarang, jangan menunggu jeda
                        lostNet = null
                        netChanged = true
                        netH.removeCallbacks(netKick)
                        netH.postDelayed(netKick, 500)
                        return
                    }
                    if (network == lostNet) { lostNet = null; probeAfterRecover(); return } // jaringan sama pulih: pastikan soket masih hidup
                    if (prev == network) return
                    netChanged = true
                    netH.removeCallbacks(netKick)
                    netH.postDelayed(netKick, 1000)
                }
                override fun onLost(network: Network) {
                    // Jangan memutus di sini: keep-alive SSH yang menentukan koneksi benar-benar mati.
                    if (network == curNet) { lostNet = network; curNet = null }
                }
            }
            cm.registerDefaultNetworkCallback(cb)
            netCb = cb
        } catch (e: Exception) { }
    }

    /** Jaringan yang sama pulih: soket bisa saja sudah mati diam-diam; cek cepat lewat tunnel, bila gagal langsung sambung ulang. */
    private fun probeAfterRecover() {
        val l = link ?: return
        val g = gen
        Thread {
            try { Thread.sleep(1000) } catch (e: InterruptedException) { return@Thread }
            if (gen != g || Bus.status.value != St.CONNECTED) return@Thread
            if (!probeOnce(l, 3000, 4000L) && gen == g && Bus.status.value == St.CONNECTED) {
                Bus.log("Jaringan pulih tapi tunnel mati, sambung ulang")
                kick = true
                try { l.close() } catch (e: Exception) { }
            }
        }.also { it.isDaemon = true; it.start() }
    }

    private fun unregNet() {
        netH.removeCallbacks(netKick)
        try { netCb?.let { getSystemService(ConnectivityManager::class.java).unregisterNetworkCallback(it) } } catch (e: Exception) { }
        netCb = null
    }

    private fun saveCfg(c: Config) {
        try { getSharedPreferences("alfy_svc", MODE_PRIVATE).edit().putString("last", c.toJson().toString()).apply() } catch (e: Throwable) { }
    }

    private fun loadCfg(): Config? = try {
        getSharedPreferences("alfy_svc", MODE_PRIVATE).getString("last", null)?.let { Config.fromJson(JSONObject(it)) }
    } catch (e: Throwable) { null }

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        if (i?.action != ACT_STOP && i?.action != ACT_RECONNECT) leaveIdle()
        // SELALU startForeground lebih dulu (Intent null / restart START_STICKY / Always-On VPN dari sistem)
        fg(if (i?.action == ACT_STOP || i?.action == ACT_RECONNECT) baseInfo else "Menghubungkan…")
        acquireWl()
        if (i?.action == ACT_START) {
            val cfg = try {
                Config.fromJson(JSONObject(i?.getStringExtra(EXTRA) ?: ""))
            } catch (e: Exception) {
                null
            }
            if (cfg == null) {
                Bus.log("Config tidak valid")
                shutdown(false)
            } else if (worker?.isAlive != true) {
                cfgName = cfg.name.ifBlank { "AlfyTunnel" }
                lastCfg = cfg
                saveCfg(cfg)
                val g = ++gen
                worker = Thread { run(cfg, g) }.also { it.start() }
            }
        } else if (i?.action == ACT_RECONNECT) {
            requestHardReset()
        } else if (i?.action == ACT_STOP) {
            try { getSharedPreferences("alfy_svc", MODE_PRIVATE).edit().remove("last").apply() } catch (e: Throwable) { }
            lastCfg = null
            shutdown()
        } else {
            // null / restart sistem / Always-On VPN (action android.net.VpnService): lanjutkan config terakhir
            val cfg = lastCfg ?: loadCfg()
            if (cfg != null && worker?.isAlive != true) {
                lastCfg = cfg
                cfgName = cfg.name.ifBlank { "AlfyTunnel" }
                val g = ++gen
                worker = Thread { run(cfg, g) }.also { it.start() }
            } else if (cfg == null) {
                shutdown(false)
            }
        }
        return START_STICKY
    }

    // HARD RESET: jalankan cleanup yang SAMA PERSIS dengan tombol "Putus" (shutdown), lalu mulai ulang bersih seperti cold start.
    // Wajib dipanggil dari thread background (ada Thread.sleep).
    private fun performHardReset(cfg: Config) {
        synchronized(reconLock) {
            resetAt = android.os.SystemClock.elapsedRealtime()
            Bus.log("Hard reset koneksi")
            val oldWorker = worker
            // Cleanup identik dengan "Putus": gen++, interrupt worker, tutup link/proxy/stack/TUN, status IDLE
            shutdown()
            if (destroyed) return
            val mine = gen
            try { oldWorker?.join(1500) } catch (e: InterruptedException) { }
            try { Thread.sleep(1000) } catch (e: InterruptedException) { }
            // Bila user menekan "Putus" / service dihentikan selama jeda, batalkan
            if (gen != mine || Bus.status.value != St.IDLE) return
            // Mulai ulang seperti pertama kali (jalur ACT_START)
            leaveIdle()
            fg("Menghubungkan…")
            acquireWl()
            val g = ++gen
            worker = Thread { run(cfg, g) }.also { it.start() }
        }
    }

    // Active Watchdog: probe lewat tunnel (DNS-over-TCP ke 8.8.8.8:53 via kanal SSH).
    // Ping exec tidak dipakai karena app dikecualikan dari VPN (ping akan lewat jaringan asli, bukan tunnel).
    private fun probeOnce(l: TunnelLink, connMs: Int = 2000, joinMs: Long = 5000): Boolean {
        val ok = java.util.concurrent.atomic.AtomicBoolean(false)
        val ch = arrayOfNulls<SshChan>(1)
        val raw = Prefs.pingUrl.value.trim().ifBlank { "http://cp.cloudflare.com" }
        val https = raw.startsWith("https://", true)
        val noScheme = raw.substringAfter("://")
        val hp = noScheme.substringBefore('/')
        val path = "/" + noScheme.substringAfter('/', "")
        val host = hp.substringBefore(':')
        val port = hp.substringAfter(':', "").toIntOrNull() ?: if (https) 443 else 80
        val t = Thread {
            try {
                val c = l.open(host, port)
                ch[0] = c
                c.connect(connMs)
                ok.set(true) // kanal direct-tcpip terbuka = sesi SSH hidup
                if (https) {
                    // HTTPS: kanal tunnel terbuka ke host = tunnel sehat
                    ok.set(true)
                } else {
                    val q = "GET $path HTTP/1.1\r\nHost: $host\r\nConnection: close\r\n\r\n"
                    c.outputStream.write(q.toByteArray())
                    c.outputStream.flush()
                    val b = ByteArray(4)
                    c.inputStream.read(b, 0, 4)
                }
            } catch (e: Throwable) {
            }
        }.also { it.isDaemon = true; it.start() }
        try { t.join(joinMs) } catch (e: InterruptedException) { }
        try { ch[0]?.disconnect() } catch (e: Exception) { }
        return ok.get()
    }

    private fun startWatchdog(l: TunnelLink, g: Int) {
        if (wdGen == g) return
        wdGen = g
        Thread {
            var fails = 0
            var streak = wdStreak
            var lastRecon = wdLast
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            try {
                while (gen == g) {
                    Thread.sleep(Prefs.pingInterval.value.toLong().coerceAtLeast(1000L))
                    if (gen != g) break
                    if (!Prefs.pingOn.value || Bus.status.value != St.CONNECTED || !l.alive) { fails = 0; continue }
                    if (System.currentTimeMillis() - connAt < GRACE_MS) { fails = 0; continue }
                    // Layar mati + opsi "Hanya Cek Saat Layar Menyala" aktif: jeda ping, koneksi tetap berjalan
                    if (Prefs.pingScreenOnly.value && !pm.isInteractive) { fails = 0; continue }
                    val tmo = Prefs.pingTimeout.value.coerceAtLeast(1000)
                    // Minimal 1 kali gagal; nilai lama 0 (dulu = nonaktif) dianggap default 2 agar tidak reset di kegagalan pertama
                    val maxF = Prefs.pingFails.value.let { if (it < 1) 2 else it }
                    val t0 = System.currentTimeMillis()
                    if (probeOnce(l, tmo, tmo.toLong())) {
                        fails = 0
                        Bus.log("HTTP Ping 200 OK (${System.currentTimeMillis() - t0}ms)")
                    } else {
                        fails++
                        Bus.log("HTTP Ping Gagal")
                        Bus.log("Watchdog: ping gagal ($fails/$maxF)")
                        if (maxF > 0 && fails >= maxF) {
                            // Pengaman 1: probe tambahan dengan timeout longgar (anti false-positive)
                            if (gen != g) break
                            if (probeOnce(l, tmo * 2, tmo * 2L)) {
                                Bus.log("Watchdog: probe tambahan berhasil, batal sambung ulang")
                                fails = 0
                                continue
                            }
                            if (gen != g || Bus.status.value != St.CONNECTED || !l.alive) { fails = 0; continue }
                            if (!Prefs.alwaysReconnect.value) {
                                Bus.log("Watchdog: ping gagal, Always Reconnect mati (tidak sambung ulang)")
                                fails = 0
                                continue
                            }
                            Bus.log("Watchdog: koneksi mati, paksa sambung ulang")
                            fails = 0
                            // Pengaman 2: anti reconnect-loop (exponential backoff)
                            val now = System.currentTimeMillis()
                            streak = if (lastRecon != 0L && now - lastRecon < 60000) streak + 1 else 1
                            lastRecon = now
                            wdStreak = streak
                            wdLast = now
                            if (streak >= 3) {
                                val back = minOf(120000L, 10000L shl minOf(streak - 3, 4))
                                Bus.log("Watchdog: reconnect beruntun ($streak), jeda ${back / 1000} detik")
                                var w = 0L
                                while (w < back && gen == g) { Thread.sleep(1000); w += 1000 }
                            }
                            if (gen != g) break
                            if (graceLeft() > 0L) { Bus.log("Watchdog: reset diabaikan (masa tenggang 10 detik setelah tersambung)"); fails = 0; continue }
                            val cfg = lastCfg
                            if (cfg != null) performHardReset(cfg)
                            break
                        }
                    }
                }
            } catch (e: InterruptedException) {
            }
        }.also { it.isDaemon = true; it.start() }
    }

    private fun run(cfg: Config, g: Int) {
        Bus.status.value = St.CONNECTING
        armConnWd(g)
        Bus.muted = false
        startLog()
        val l: TunnelLink = if (cfg.useSlowDns) {
            Bus.log("Jalur SlowDNS (DNS tunneling) aktif, NS=${cfg.dnsNs.trim()}")
            SlowDnsLink(this, cfg)
        } else {
            SshLink(this, cfg)
        }
        link = l
        var attempt = 0
        try {
            while (gen == g) {
                try {
                    l.connect()
                    if (gen != g) break
                    // Auth complete: status CONNECTED seketika, sebelum langkah lain; matikan watchdog fase koneksi
                    synchronized(reconLock2) {
                        lastConnectTime = System.currentTimeMillis()
                        connAt = lastConnectTime
                        rcEverConn = g
                        netH.removeCallbacks(connWd)
                        netH.removeCallbacks(rcWd)
                        Bus.status.value = St.CONNECTED
                    }
                    val existing = stack
                    if (tun == null || existing == null || !existing.isRunning) {
                        val t = build(cfg) ?: throw IOException("Gagal membuat antarmuka VPN (izin dicabut?)")
                        if (gen != g) { try { t.close() } catch (e: Exception) { }; break }
                        tun = t
                        try { existing?.stop() } catch (e: Exception) { }
                        val s = TunStack(FileInputStream(t.fileDescriptor), FileOutputStream(t.fileDescriptor), l)
                        stack = s
                        Thread { s.loop() }.also { it.isDaemon = true }.start()
                    }
                    if (Prefs.hotspot.value && Prefs.hotspotMode.value == 1 && proxy == null) {
                        proxy = HttpProxyServer(l).also { it.start() }
                    }
                    attempt = 0
                    note("Terhubung")
                    Bus.log("Connected")
                    hud?.start()
                    startWatchdog(l, g)
                    startTrafficWd(g)
                    while (gen == g && l.alive) Thread.sleep(500)
                    if (gen == g) Bus.log("Koneksi SSH terputus")
                } catch (e: InterruptedException) {
                    break
                } catch (e: Throwable) {
                    Bus.log("Gagal: ${e.message ?: e.javaClass.simpleName}")
                }
                l.close()
                if (gen != g) break
                stack?.reset()
                attempt++
                Bus.status.value = St.RECONNECTING
                if (rcEverConn == g) armRcWd(g)
                note("Menyambung ulang…")
                val w = minOf(8, attempt * 2)
                Bus.log("Coba lagi dalam $w detik (percobaan $attempt)")
                for (k in 0 until w * 2) {
                    if (gen != g) break
                    if (kick) { kick = false; break }
                    Thread.sleep(500)
                }
            }
        } catch (e: InterruptedException) {
        }
        try { l.close() } catch (e: Exception) { }
        if (gen == g) shutdown()
    }

    private fun build(cfg: Config): ParcelFileDescriptor? {
        val b = Builder()
            .setSession("AlfyTunnel")
            .setMtu(Prefs.mtu.value.coerceIn(576, 1500))
            .setBlocking(true)
            .addAddress("10.8.0.2", 32)
            .addRoute("0.0.0.0", 0)
        if (Prefs.hotspot.value && Prefs.hotspotMode.value == 0) {
            // Subnet klien hotspot/USB tethering diarahkan ke TUN agar paket klien masuk TunStack
            for (net in listOf("192.168.42.0", "192.168.43.0", "192.168.49.0")) {
                try { b.addRoute(net, 24) } catch (e: Exception) { }
            }
            Bus.log("Hotspot sharing aktif (rute 192.168.42/43/49.x)")
        }
        if (cfg.dnsOn) {
            b.addDnsServer(cfg.dns1.trim())
            if (cfg.dns2.isNotBlank()) b.addDnsServer(cfg.dns2.trim())
        }
        try {
            b.addDisallowedApplication(packageName)
        } catch (e: Exception) {
        }
        return b.establish()
    }

    /** keep=true: VPN diputus tapi service foreground + notifikasi ("Terputus") tetap hidup. keep=false: berhenti total. */
    @Synchronized
    private fun shutdown(keep: Boolean = true) {
        gen++
        netH.removeCallbacks(connWd)
        netH.removeCallbacks(rcWd)
        kick = false
        wdStreak = 0
        connAt = 0L
        lastConnectTime = 0L
        netChanged = false
        val w = worker
        worker = null
        try { w?.interrupt() } catch (e: Exception) { }
        try { link?.close() } catch (e: Exception) { }
        link = null
        hud?.stop()
        try { if (wl?.isHeld == true) wl?.release() } catch (e: Exception) { }
        wl = null
        lastSig = ""
        try { proxy?.stop() } catch (e: Exception) { }
        proxy = null
        stack?.stop()
        stack = null
        try { tun?.close() } catch (e: Exception) { }
        tun = null
        if (Bus.status.value != St.IDLE) Bus.log("Terputus")
        Bus.status.value = St.IDLE
        if (keep && !destroyed) {
            enterIdle()
        } else {
            leaveIdle()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun enterIdle() {
        idleKeep = true
        baseInfo = "Terputus"
        lastSig = ""
        if (!idleScan) { idleScan = true; try { Mon.dbmUse(this, true) } catch (e: Throwable) { } }
        val n = try { notif() } catch (e: Throwable) { stdNotif("Terputus") }
        fgPost(n)
        netH.removeCallbacks(ticker)
        netH.post(ticker)
    }

    private fun leaveIdle() {
        idleKeep = false
        netH.removeCallbacks(ticker)
        if (idleScan) { idleScan = false; try { Mon.dbmUse(this, false) } catch (e: Throwable) { } }
    }

    private fun fgPost(n: Notification) {
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SYSTEM_EXEMPTED)
            else startForeground(NID, n)
        } catch (e: Throwable) {
            try { startForeground(NID, n) } catch (e2: Throwable) { }
        }
    }

    // Swipe dari recent apps: JANGAN hentikan service, pastikan tetap foreground.
    override fun onTaskRemoved(rootIntent: Intent?) {
        // Sedang "Terputus" (tidak ada tunnel): app di-swipe -> notifikasi & service benar-benar dihentikan.
        if (idleKeep && Bus.status.value == St.IDLE) {
            leaveIdle()
            try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (e: Throwable) { }
            stopSelf()
            return
        }
        try { fg(baseInfo) } catch (e: Throwable) { }
        acquireWl()
        // Dihapus dari recent saat sedang menyambung ulang: lewati jeda tunggu, coba lagi sekarang
        if (Bus.status.value == St.RECONNECTING) kick = true
    }

    override fun onRevoke() {
        shutdown(false)
    }

    override fun onDestroy() {
        destroyed = true
        leaveIdle()
        if (inst === this) inst = null
        ovScope.cancel()
        hideOverlay()
        netH.removeCallbacks(supervisor)
        netH.removeCallbacks(connWd)
        netH.removeCallbacks(rcWd)
        unregNet()
        if (rxReg) { try { unregisterReceiver(actRx) } catch (e: Exception) { }; rxReg = false }
        if (Bus.status.value != St.IDLE) shutdown(false)
        try { if (wl?.isHeld == true) wl?.release() } catch (e: Exception) { }
        wl = null
        super.onDestroy()
    }

    private fun liveName(): String = (lastCfg?.name ?: cfgName).ifBlank { "AlfyTunnel" }

    private fun shownNameNow(): String {
        if (!Prefs.cfgNameNotif.value) return "AlfyTunnel"
        val hl = Prefs.hostLabel.value.trim()
        return if (hl.isNotBlank()) hl else liveName()
    }

    private fun notif(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        val b: Notification.Builder
        if (Build.VERSION.SDK_INT >= 26) {
            if (!chMade) {
                nm.createNotificationChannel(NotificationChannel(CH, "Status VPN", NotificationManager.IMPORTANCE_LOW))
                chMade = true
            }
            b = Notification.Builder(this, CH)
        } else {
            b = Notification.Builder(this)
        }
        val (d, w, m) = Usage.totals()
        val sp = Prefs.notifSpeed.value
        val on = Prefs.notifOn.value
        val now = System.currentTimeMillis()
        fun cs(t: String, base: Int): CharSequence = if (on) rainbowText(t, sp, now, IntArray(0), base) else t
        val l1 = cs(Mon.infoLine(), 0)
        val dur = connDur()
        val l3 = cs("Data hari ini: ${Usage.fmtBytes(d)}" + (if (dur.isNotEmpty()) " - $dur" else ""), 8)
        val l4 = cs("Minggu ini: ${Usage.fmtBytes(w)} \u2022 Bulan ini: ${Usage.fmtBytes(m)}", 8)
        val shownName = shownNameNow()
        val title = cs(shownName, 0)
        val act = cs("PUTUS", 0)
        val connected = Bus.status.value == St.CONNECTED
        val idle = Bus.status.value == St.IDLE
        val statusTxt = when {
            idle -> "Terputus"
            connected -> "Connected"
            Bus.status.value == St.CONNECTING -> "Menghubungkan…"
            else -> "Menyambungkan ulang..."
        }
        val lSt = cs(statusTxt, 0)
        val smallTitle = cs("$shownName \u2022 $statusTxt", 0)
        val iconRes = statusIcon()
        lastSig = sigNow()
        lastNotifAt = android.os.SystemClock.elapsedRealtime()
        // Android 12+ membuang span warna di notifikasi standar; view kustom mempertahankannya
        val rv = RemoteViews(packageName, R.layout.notif)
        rv.setTextViewText(R.id.n_speed, title)
        rv.setTextViewText(R.id.n_status, lSt)
        rv.setTextViewText(R.id.n_info, l1)
        rv.setTextViewText(R.id.n_usage, l3)
        rv.setTextViewText(R.id.n_week, l4)
        val rs = RemoteViews(packageName, R.layout.notif_small)
        rs.setTextViewText(R.id.n_speed, smallTitle)
        rs.setTextViewText(R.id.n_info, l1)
        rs.setTextViewText(R.id.n_usage, l3)
        val nb = b.setSmallIcon(iconRes)
            .setContentTitle(title)
            .setContentText(l1)
            .setStyle(Notification.DecoratedCustomViewStyle())
            .setCustomContentView(rs)
            .setCustomBigContentView(rv)
            .setContentIntent(openPi)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setCategory(Notification.CATEGORY_SERVICE)
        if (Build.VERSION.SDK_INT >= 31) nb.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE)
        if (!idle) {
            nb.addAction(Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_stat), act, stopPi).build())
            nb.addAction(Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_refresh), "Sambung Ulang", reconPi).build())
        }
        return nb.build().also { it.flags = it.flags or Notification.FLAG_ONGOING_EVENT or Notification.FLAG_NO_CLEAR }
    }

    private fun sigNow(): String {
        val (d, w, m) = Usage.totals()
        val tk = if (Prefs.notifAnim()) System.currentTimeMillis() / NOTIF_GAP else 0L
        return "${Bus.status.value}|${liveName()}|${Prefs.hostLabel.value}|$baseInfo|${Prefs.cfgNameNotif.value}|$d|$w|$m|${Mon.infoLine()}|${Prefs.notifOn.value}|${Prefs.notifSpeed.value}|$tk|${connDur()}"
    }

    fun refreshNotif() {
        try {
            synchronized(notifLock) {
                if (lastSig == sigNow()) return
                val wait = lastNotifAt + NOTIF_GAP - android.os.SystemClock.elapsedRealtime()
                if (wait > 0) {
                    netH.removeCallbacks(notifFlush)
                    netH.postDelayed(notifFlush, wait)
                    return
                }
                getSystemService(NotificationManager::class.java).notify(NID, notif())
            }
        } catch (e: Exception) { }
    }

    private fun startLog() {
        var vn = "-"
        var vc = 0L
        try {
            val pi = packageManager.getPackageInfo(packageName, 0)
            vn = pi.versionName ?: "-"
            vc = if (Build.VERSION.SDK_INT >= 28) pi.longVersionCode else pi.versionCode.toLong()
        } catch (e: Exception) {
        }
        Bus.log(
            "Running on ${Build.MANUFACTURER.lowercase()} ${Build.MODEL} (${Build.HARDWARE}), Android ${Build.VERSION.RELEASE} " +
                "(${Build.ID}) API ${Build.VERSION.SDK_INT}. Version $vn Build $vc."
        )
        acquireWl()
        Bus.log("Local ip, " + localIp())
    }

    @Synchronized
    private fun acquireWl() {
        if (!Prefs.wakeLock.value) return
        try {
            if (wl?.isHeld == true) return
            val w = (getSystemService(POWER_SERVICE) as PowerManager).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "AlfyTunnel:tunnel")
            w.setReferenceCounted(false)
            w.acquire()
            wl = w
            Bus.log("Wakelock acquired")
        } catch (e: Exception) { }
    }

    private fun localIp(): String {
        try {
            for (ni in NetworkInterface.getNetworkInterfaces().toList()) {
                if (!ni.isUp || ni.isLoopback || ni.name.startsWith("tun")) continue
                for (a in ni.inetAddresses.toList()) if (a is Inet4Address && !a.isLoopbackAddress) return a.hostAddress ?: "-"
            }
        } catch (e: Exception) { }
        return "-"
    }

    private fun stdNotif(t: String): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        val b: Notification.Builder
        if (Build.VERSION.SDK_INT >= 26) {
            if (!chMade) {
                nm.createNotificationChannel(NotificationChannel(CH, "Status VPN", NotificationManager.IMPORTANCE_LOW))
                chMade = true
            }
            b = Notification.Builder(this, CH)
        } else {
            b = Notification.Builder(this)
        }
        return b.setSmallIcon(statusIcon())
            .setContentTitle("AlfyTunnel")
            .setContentText(t)
            .setContentIntent(openPi)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setCategory(Notification.CATEGORY_SERVICE)
            .also { if (Build.VERSION.SDK_INT >= 31) it.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE) }
            .build()
            .also { it.flags = it.flags or Notification.FLAG_ONGOING_EVENT or Notification.FLAG_NO_CLEAR }
    }

    /** startForeground() dengan notifikasi standar polos (tanpa custom view/Prefs) agar muncul seketika. */
    private fun fgStd(t: String) {
        baseInfo = t
        val n = stdNotif(t)
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SYSTEM_EXEMPTED)
            else startForeground(NID, n)
        } catch (e: Throwable) {
            try { startForeground(NID, n) } catch (e2: Throwable) { }
        }
    }

    private fun fg(t: String) {
        if (Bus.status.value != St.CONNECTED && !idleKeep) { fgStd(t); return }
        baseInfo = t
        val n = try { notif() } catch (e: Throwable) { stdNotif(t) }
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SYSTEM_EXEMPTED)
            } else {
                startForeground(NID, n)
            }
        } catch (e: Throwable) {
            try { startForeground(NID, n) } catch (e2: Throwable) { }
        }
    }

    private fun note(t: String) {
        baseInfo = t
        getSystemService(NotificationManager::class.java).notify(NID, notif())
    }
}
