package com.alfy.tunnel

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.SystemClock
import android.util.Base64
import android.view.View
import kotlin.math.max
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * Animasi "berpikir" gaya Claude: titik-titik yang berubah bentuk (satu titik -> deret 3 titik ->
 * kotak 2x2 yang berputar/bertukar -> segitiga berputar). Gerakannya diambil frame-demi-frame
 * dari video referensi (60 fps, 1271 frame), lalu diputar berulang. Warna dibuat warna-warni
 * (pelangi mengalir mengikuti posisi titik + waktu).
 */
// KATALOG ANIMASI (nomor = urutan siklus; fase 4..18 = cabang `when(idx)` idx 0..14 di onDraw, tiap fase PHASE detik):
// 1 asli | 2 roda kanan | 3 roda kiri | 4 Lissajous | 5 Baling-baling | 6 Pusaran | 7 Infinity | 8 Bintang Ganda | 9 Ular
// 10 Tukar Posisi | 11 Spirograf | 12 Bunga | 13 Pantulan | 14 Morfosis | 15 Pendulum | 16 Rotor | 17 Giroskop | 18 Menggelinding
// Tambah animasi: cabang baru di `when(idx)`, naikkan 15 pada `15 * PHASE` & `min(14, ...)`, perbarui katalog ini.
class ClaudeView(c: Context) : View(c) {
    private val dn = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val hsv = FloatArray(3)
    private val sizePx = (22 * dn).toInt()
    private val unit = 0.42f * dn          // 1 piksel video = 0,42 dp
    private val startMs = SystemClock.uptimeMillis()

    // Lebar mengikuti lebar teks data di bawahnya (0 = lebar bawaan); animasi tetap digambar di tengah dengan skala sama
    var matchW = 0
        set(v) { if (field != v) { field = v; requestLayout() } }

    // Faktor regang posisi (x dan y sama, supaya proporsi gerak tetap seperti aslinya); ukuran titik & waktu tetap
    private fun stretch() = if (matchW > 0) ((matchW / 2f - 4.9f * unit) / (20.25f * unit)).coerceAtLeast(1f) else 1f

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        val h = if (matchW > 0) max(sizePx, Math.ceil(2.0 * (18.25f * unit * stretch() + 4.9f * unit)).toInt()) else sizePx
        setMeasuredDimension(if (matchW > 0) matchW else sizePx, h)
    }

    override fun onDraw(cv: Canvas) {
        val elapsed = (SystemClock.uptimeMillis() - startMs) / 1000f
        val t = elapsed % (DURATION + 2 * WHEEL + 15 * PHASE)
        val mx = width / 2f
        val my = height / 2f
        val xs = stretch()
        if (t < DURATION) {
            val loopT = t
            val fi = min(FRAMES - 1, (loopT * FPS).toInt())
            // Sambungan mulus di ujung loop: mengecil ke tengah di akhir, membesar di awal
            val edge = min(min(loopT / 0.15f, (DURATION - loopT) / 0.25f), 1f).coerceIn(0f, 1f)
            val d = DATA
            val base = fi * 12
            for (k in 0 until 4) {
                val o = base + k * 3
                val rr = d[o + 2].toInt() and 0xFF
                if (rr == 0) continue
                val dx = ((d[o].toInt() and 0xFF) - 128) / 4f
                val dy = ((d[o + 1].toInt() and 0xFF) - 128) / 4f
                dot(cv, mx + dx * unit * edge * xs, my + dy * unit * edge * xs, rr / 20f * unit * edge, dx, dy, elapsed)
            }
        } else if (t >= DURATION + 2 * WHEEL) {
            // 15 animasi tambahan (titik yang sama): Lissajous, Baling-baling, Pusaran, Infinity, Bintang Ganda, Ular, Tukar Posisi, Spirograf, Bunga, Pantulan, Morfosis, Pendulum, Rotor, Giroskop, Menggelinding; masing-masing 2 putaran loop
            val w = t - DURATION - 2 * WHEEL
            val idx = min(14, (w / PHASE).toInt())
            val wt = w - idx * PHASE
            val edge = min(min(wt / 0.4f, (PHASE - wt) / 0.4f), 1f).coerceIn(0f, 1f)
            val p = (2.0 * Math.PI * wt / LOOP).toFloat()
            for (k in 0 until 4) {
                val q = k * (Math.PI / 2).toFloat()
                val dx: Float
                val dy: Float
                when (idx) {
                    0 -> { val z = k * 0.7f; dx = 17f * sin(3f * p + z); dy = 17f * sin(2f * p + z + 1.5707964f) }
                    1 -> { val rad = 18f * (0.22f + 0.78f * (0.5f + 0.5f * cos(2f * p))); dx = rad * cos(p + q); dy = rad * sin(p + q) }
                    2 -> { val rad = 9f + 9f * sin(p + q); dx = rad * cos(2f * p + q); dy = rad * sin(2f * p + q) }
                    3 -> { dx = 18f * sin(p + q); dy = 9f * sin(2f * (p + q)) }
                    4 -> {
                        val pr = k / 2
                        val cx = 11f * cos(p + pr * 3.1415927f)
                        val cy = 11f * sin(p + pr * 3.1415927f)
                        val a = -3f * p + (k % 2) * 3.1415927f + pr * 1f
                        dx = cx + 7f * cos(a); dy = cy + 7f * sin(a)
                    }
                    5 -> {
                        val tt = p - k * 0.5f
                        val c = cos(tt); val sn = sin(tt)
                        dx = 17f * Math.copySign(Math.sqrt(Math.abs(c).toDouble()).toFloat(), c)
                        dy = 17f * Math.copySign(Math.sqrt(Math.abs(sn).toDouble()).toFloat(), sn)
                    }
                    6 -> {
                        // Tukar posisi: pasangan titik bergantian (atas, bawah, kiri, kanan) berputar 180 derajat
                        val u = (wt / LOOP) % 1f
                        val st = (u * 4f).toInt() % 4
                        val x4 = (u * 4f) % 1f
                        val ph = 3.1415927f * x4 * x4 * (3f - 2f * x4)
                        val bx = if (k % 2 == 0) -10f else 10f
                        val by = if (k < 2) -10f else 10f
                        val inPair = when (st) { 0 -> k < 2; 1 -> k >= 2; 2 -> k % 2 == 0; else -> k % 2 == 1 }
                        if (inPair) {
                            val cx = if (st == 0 || st == 1) 0f else bx
                            val cy = if (st == 0) -10f else if (st == 1) 10f else 0f
                            val sg = if (st == 0 || st == 2) 1f else -1f
                            val a = Math.atan2((by - cy).toDouble(), (bx - cx).toDouble()).toFloat() + sg * ph
                            dx = cx + 10f * cos(a); dy = cy + 10f * sin(a)
                        } else { dx = bx; dy = by }
                    }
                    7 -> {
                        val tt = 3f * p - k * 0.9f
                        dx = 3.6f * (2f * cos(tt) + 3f * cos(tt * 2f / 3f))
                        dy = 3.6f * (2f * sin(tt) - 3f * sin(tt * 2f / 3f))
                    }
                    8 -> {
                        val tt = p + k * 0.8f
                        val rad = 18f * cos(2f * tt)
                        dx = rad * cos(tt); dy = rad * sin(tt)
                    }
                    9 -> {
                        val fx = intArrayOf(3, 2, 4, 3)[k]
                        val fy = intArrayOf(2, 3, 3, 4)[k]
                        dx = 17f * tri(fx * p + k * 0.8f)
                        dy = 17f * tri(fy * p + k * 0.8f + 1f)
                    }
                    10 -> {
                        // Morfosis: garis -> kotak -> garis tegak -> belah ketupat -> segitiga -> garis
                        val u5 = ((wt / LOOP) % 1f) * 5f
                        val i = u5.toInt() % 5
                        val f = u5 % 1f
                        val z = ((f - 0.4f) / 0.6f).coerceIn(0f, 1f)
                        val e2 = z * z * (3f - 2f * z)
                        val a = SH[i]; val b = SH[(i + 1) % 5]
                        dx = a[2 * k] + (b[2 * k] - a[2 * k]) * e2
                        dy = a[2 * k + 1] + (b[2 * k + 1] - a[2 * k + 1]) * e2
                    }
                    11 -> { dx = -13.5f + 9f * k; dy = 16f * sin((4 + k) * p) }
                    12 -> {
                        val a = intArrayOf(4, -3, 2, -1)[k] * p + k
                        val rad = floatArrayOf(6f, 10f, 14f, 18f)[k]
                        dx = rad * cos(a); dy = rad * sin(a)
                    }
                    13 -> {
                        val a = 2f * p + q
                        dx = 18f * cos(a); dy = 18f * sin(a) * cos(p)
                    }
                    else -> {
                        // Menggelinding: kotak 2x2 terguling 2 langkah ke kanan, lalu 2 langkah ke kiri
                        val u4 = ((wt / LOOP) % 1f) * 4f
                        val j = u4.toInt() % 4
                        val f = u4 % 1f
                        val sf = f * f * (3f - 2f * f)
                        val rx = if (k % 2 == 0) -6f else 6f
                        val ry = if (k < 2) -6f else 6f
                        val px: Float
                        val vx: Float
                        val th: Float
                        if (j < 2) { px = -12f + 12f * j + 6f; vx = rx - 6f; th = 1.5707964f * sf }
                        else { px = 12f - 12f * (j - 2) - 6f; vx = rx + 6f; th = -1.5707964f * sf }
                        val vy = ry - 6f
                        dx = px + vx * cos(th) - vy * sin(th)
                        dy = 6f + vx * sin(th) + vy * cos(th) + 2.5f
                    }
                }
                dot(cv, mx + dx * unit * edge * xs, my + dy * unit * edge * xs, 4.5f * unit * edge, dx, dy, elapsed)
            }
        } else {
            // Animasi roda (titik yang sama): 4 titik melingkar berputar 3x ke kanan, lalu 3x ke kiri
            val w = t - DURATION
            val right = w < WHEEL
            val wt = if (right) w else w - WHEEL
            val edge = min(min(wt / 0.4f, (WHEEL - wt) / 0.4f), 1f).coerceIn(0f, 1f)
            val a0 = 1080f * (wt / WHEEL) * (if (right) 1f else -1f)
            for (k in 0 until 4) {
                val a = Math.toRadians((a0 + k * 90f).toDouble())
                val dx = (18.25f * Math.cos(a)).toFloat()
                val dy = (18.25f * Math.sin(a)).toFloat()
                dot(cv, mx + dx * unit * edge * xs, my + dy * unit * edge * xs, 4.5f * unit * edge, dx, dy, elapsed)
            }
        }
        postInvalidateOnAnimation()
    }

    private fun tri(a: Float): Float = (2.0 / Math.PI * Math.asin(Math.sin(a.toDouble()))).toFloat()

    private fun dot(cv: Canvas, x: Float, y: Float, r: Float, dx: Float, dy: Float, elapsed: Float) {
        hsv[0] = (((dx * 7f + dy * 4f + elapsed * 80f) % 360f) + 360f) % 360f
        hsv[1] = 0.72f
        hsv[2] = 1f
        paint.color = Color.HSVToColor(255, hsv)
        cv.drawCircle(x, y, max(r, 0.1f), paint)
    }

    private companion object {
        const val FPS = 60f
        const val FRAMES = 1271
        const val DURATION = FRAMES / FPS
        val SH = arrayOf(
            floatArrayOf(-13.5f, 0f, -4.5f, 0f, 4.5f, 0f, 13.5f, 0f),
            floatArrayOf(-10f, -10f, 10f, -10f, -10f, 10f, 10f, 10f),
            floatArrayOf(0f, -13.5f, 0f, -4.5f, 0f, 4.5f, 0f, 13.5f),
            floatArrayOf(0f, -14f, 14f, 0f, 0f, 14f, -14f, 0f),
            floatArrayOf(0f, -15f, 13f, 10f, -13f, 10f, 0f, 3f)
        )
        const val PHASE = 8f   // detik per animasi tambahan
        const val LOOP = 4f    // detik per putaran gerak
        const val WHEEL = 5f   // detik per animasi roda (3 putaran)

        // Data per frame: 4 slot x (dx, dy, radius); dx/dy = (nilai-128)/4 px dari pusat, radius = nilai/20 px (0 = kosong)
        val DATA: ByteArray = Base64.decode(arrayOf(
        "f4FdgIAAgIAAgIAAf4FdgIAAgIAAgIAAf4FdgIAAgIAAgIAAgX8agIAAgIAAgIAAgX8agIAAgIAAgIAAgoAdgIAAgIAAgIAAfoAmgIAAgIAAgI",
        "AAfoAmgIAAgIAAgIAAfoAmgIAAgIAAgIAAfoAmgIAAgIAAgIAAgYBPgIAAgIAAgIAAgYBPgIAAgIAAgIAAhoBrgIAAgIAAgIAAhoBrgIAAgIAA",
        "gIAAl4BmZIBBgIAAgIAAl4BmZIBBgIAAgIAAnoB2WIBCgIAAgIAAnoB2WIBCgIAAgIAAp4B+S4BLgIAAgIAAp4B+S4BLgIAAgIAArICHQoBKgI",
        "AAgIAArICHQoBKgIAAgIAAsYCHPIBQgIAAgIAAsYCHPIBQgIAAgIAAwIBxN4FXjYBEgIAAwIBxN4FXjYBEgIAAw4BuNYBfi4FGgIAAw4BuNYBf",
        "i4FGgIAAxoBsNIBkhoA9gIAAxoBsNIBkhoA9gIAAyYBsNIBnhIBCgIAAyYBsNIBnhIBCgIAAyoBtM4Bqg4FGgIAAyoBtM4Bqg4FGgIAAyoBtNI",
        "BogIBDgIAAyoBtNIBogIBDgIAAyoBtNIBqf4BAgIAAyoBtNIBqf4BAgIAANoBmzoBge4FGgIAANoBmzoBge4FGgIAANoBmzYBje4FGgIAANoBm",
        "zYBje4FGgIAANoBozYBje4FGgIAANoBozYBje4FGgIAANoBmzYBje4FGgIAANoBmzYBje4FGgIAAN4FlzoBgeIBCgIAAN4FlzoBgeIBCgIAAN4",
        "BozoBgeIFDgIAAN4BozoBgeIFDgIAAPIBszoBgcoBKgIAAPIBszoBgcoBKgIAAP4FqzoBgbIFIgIAAP4FqzoBgbIFIgIAATICEzoBggIAAgIAA",
        "TICEzoBggIAAgIAAUIF9zYBfgIAAgIAAUIF9zYBfgIAAgIAAUIF+zYBfgIAAgIAAUIF+zYBfgIAAgIAAQIFtzoBfbIFGgIAATICEzoBggIAAgI",
        "AATICEzoBggIAAgIAAUoJ5y4BXgIAAgIAAUoJ5y4BXgIAAgIAAWIR4yYBTgIAAgIAAWIR4yYBTgIAAgIAAYIV8xn9XgIAAgIAAYIV8xn9XgIAA",
        "gIAAZIaAwn5OgIAAgIAAZIaAwn5OgIAAgIAAdIl1vn1USn5NgIAAdIl1vn1USn5NgIAAf411RXxSuXxMgIAAf411RXxSuXxMgIAAi5BxQH5OtH",
        "pLgIAAi5BxQH5OtHpLgIAAi5BxQH5OtHpLgIAAnYuHO35QgIAAgIAApIyGN39RgIAAgIAApIyGN39RgIAAgIAAqY2JNIFQgIAAgIAAqY2JNIFQ",
        "gIAAgIAAt5htMYNdmnBKgIAAtphwMYRdmnBKgIAAtphwMYRdmnBKgIAAvphwMIdjk21HgIAAvphwMIdjk21HgIAAxJdtMoxgi2lGgIAAxJdtMo",
        "xgi2lGgIAAyZVlM5Njg2ZEgIAAyZVlM5Njg2ZEgIAAM5NmyZVmg2ZEgIAAM5NmyZVmg2ZEgIAAPqFkzY1ec19HgIAAPqFkzY1ec19HgIAARapm",
        "zoddal1CgIAARapmzoddal1CgIAAT7FqzIJXYV1HgIAAT7FqzIJXYV1HgIAAWrdtyXtYWV9HgIAAWrdtyXtYWV9HgIAAZbdwxXVXUmRHgIAAZb",
        "dwxXVXUmRHgIAAcrZywHJSSmlMgIAAcrZywHJSSmlMgIAAgbFwQ3BMunBLgIAAjqxwP3VRs29LgIAAjqxwP3VRs29LgIAAm6dwOnlMrG9HgIAA",
        "m6dwOnlMrG9HgIAAqaBwNn1Yo29JgIAAqaBwNX1YpG9GgIAAqaBwNX1YpG9GgIAAs5luMYJZm3BKgIAAs5luMYJZm3BKgIAAvJNvMIRbk3FGgI",
        "AAvJNvMIRbk3FGgIAAw49wMYVdi3JGgIAAw49wMYVdi3JGgIAAyIpsM4ZmgnVBgIAAyIpsM4ZmgnVBgIAANodqy4ZmeXdHgIAAO4htzYRecnhK",
        "gIAAO4htzYRecnhKgIAATISCzYNdgIAAgIAATISCzYNdgIAAgIAAUYSAy4NXgIAAgIAAUYSAy4NXgIAAgIAAVoZwyIJWgIAAgIAAVoZwyIJWgI",
        "AAgIAAYIR+xIFSgIAAgIAAYIR+xIFSgIAAgIAAZoKMwIFSgIAAgIAAZoKMwIFSgIAAgIAAeoJ0u4BLR4BKgIAAeoJ0u4BLR4BKgIAAhoF3QoBK",
        "toBGgIAAhoF3QoBKtoBGgIAAm4CFPYBQgIAAgIAAm4CFPYBQgIAAgIAAnoB5OYBNgIAAgIAAnoB5OYBNgIAAgIAApoF1NoBUgIAAgIAApoF1No",
        "BUgIAAgIAApoF4NoBVgIAAgIAApoF4NoBVgIAAgIAArIB5NIBRgIAAgIAArIB5NIBRgIAAgIAAsYCGMIBbgIAAgIAAsYCGMIBbgIAAgIAAwYBt",
        "MIBckYBJgIAAwYBtMIBckYBJgIAAw4BuMIBii4BKgIAAw4BuMIBii4BKgIAAw4BuMIBii4FGgIAAw4BuMIBii4FGgIAAx4FmMIBkh4BCgIAAx4",
        "FmMIBkh4BCgIAAy39nN39keoFKgIAAy39nN39ke4FGgIAAy39nN39ke4FGgIAASHpkwn1acYdGgIAASHpkwn1acYdGgIAASXplwn1acYdGgIAA",
        "SXplwn1ZcYdGgIAASXplwn1ZcYdGgIAAYnptt39IgIAAgIAAYnptt39IgIAAgIAAYnptt39KgIAAgIAAYnptt39KgIAAgIAAanltroBHgIAAgI",
        "AAanltroBHgIAAgIAAb3p1pIJJgIAAgIAAb3p1pIJJgIAAgIAAgH+XgIAAgIAAgIAAgH+IgIAAgIAAgIAAgH+IgIAAgIAAgIAAgH+IgIAAgIAA",
        "gIAAgH+IgIAAgIAAgIAAgIFvgIAAgIAAgIAAgIFvgIAAgIAAgIAAf4FTgIAAgIAAgIAAf4FTgIAAgIAAgIAAf4BAgIAAgIAAgIAAf4E3gIAAgI",
        "AAgIAAf4E3gIAAgIAAgIAAfoAmgIAAgIAAgIAAfoAmgIAAgIAAgIAAfoAmgIAAgIAAgIAAf4AmgIAAgIAAgIAAf4AmgIAAgIAAgIAAf4AmgIAA",
        "gIAAgIAAgIBMgIAAgIAAgIAAgIBNgIAAgIAAgIAAgIBNgIAAgIAAgIAAgIBQgIAAgIAAgIAAgIBQgIAAgIAAgIAAgH9ZgIAAgIAAgIAAgH9ZgI",
        "AAgIAAgIAAgIBvgIAAgIAAgIAAgIBugIAAgIAAgIAAgIBugIAAgIAAgIAAf3+OgIAAgIAAgIAAf3+OgIAAgIAAgIAAgIC3gIAAgIAAgIAAgIC3",
        "gIAAgIAAgIAAoKBhn11dYKNdX2FZoKBhn11dYKNdX2FZqFJmq6tmV61jVlZdqFJmq6tmV61jVlZdsbBrUFFnU7Nmrk1isbBrUFFnU7Nmrk1isU",
        "lttLNrULdqTk5nsUlttLNrULdqTk5ntrVvskdtTrpqTE1otrVvskdtTrpqTE1ot7ZvtEZsTEtsTLprt7ZvtEZsTEtsTLprubdwS0pstEZsTLtr",
        "ubdwS0pstEZsTLtrubdwS0pstEZsTLtrubdwS0pstEZsTLtrS0lvtEZsubdsTLtrS0lvtEZsubdsTLtrS0lvuLdttEZsTLtrS0lvuLdttEZsTL",
        "truLdvS0lvtEZsTLtruLdvS0lvtEZsTLtrTLpwuLdutUZtTEttTLpwuLdutUZtTEtttkduS7lutrRtTU5qtkduS7lutrRtTU5qtatuSrhtuEhs",
        "UVdotatuSrhtuEhsUVdosqJzt0huU2BtSrhtsqJzt0huU2BtSrhtr5h3t0huSrhtV2tor5h3t0huSrhtV2toqIh1t0hxSrhtXHhoqmCjY4luSr",
        "htgIAAqmCjY4luSrhtgIAAqmCiSrhtZIppgIAApVSgWquTgIAAgIAApVShWquVgIAAgIAApVShWquVgIAAgIAAn0yfX7OWgIAAgIAAe0Byt0hv",
        "Sbhvhbpse0Byt0hwSbhvhbpse0Byt0hwSbhvhbpsbzpyuEhwkcFwSrhvbzpyuEhwkcFwSrhvZDhzuEhxm8RwSbhtZDhzuEhxm8RwSbhto8JvXD",
        "ptSbhtuUhto8JvXDptSbhtuUhtXDptSbhtuUhto8NsXDptSbhtuUhto8NsrcBzUkBtSbhtuUhtrcBzUkBtSbhtuUhtsb1wUEFuSrhtuUhtsb1w",
        "UEFuSrhtuUhtuUhvs7xvTURtSrdsuUhvs7xvTURtSrdsuElvS7ZvTEZstbtsS7ZvuEluTEZstbtsS7ZvuEluTEZstbtsS0dwuEptTLNrtrprtk",
        "xwTLBuSkhtt7potkxwTLBuSkhtt7pouLluSkhttVBtTqtruLluSkhttVBtTqtrs1dwSkhtuLltUKZrs1dwSkhtuLltUKZrsV9wSkhtuLltVJ1o",
        "sV9wSkhtuLltVJ1orGxzSkhtuLhtWJJnrGxzSkhtuLhtWJJnpX11SkhtuLhtXoNmpX11SkhtuLhtXoNmqaOfSkhtZnJkgIAAqaOfSkhtZnJkgI",
        "AAo62mW1OXgIAAgIAAo62mW1OXgIAAgIAAnLekSkhtfE9ngIAAnLekSkhtfE9ngIAAt7hyeMFvSUhth0Nmt7hyeMFvSUhth0Nma8dwuLhwSkht",
        "lDxoa8dwuLhwSkhtlDxouLhvYshuSkhtnTpruLhvYshuSkhtnTprW8Zyt7hvSkhtpTtsW8Zyt7hvSkhtpTtsqz9vuLhvVcNvSkhtqz9vuLhvVc",
        "NvSkhtr0ByuLhvSkhtUsBtr0ByuLhvSkhtUsBtsUJxuLhvSkltTr5ssUJxuLhvSkltTr5sS7lwSklutEZuuLdtS7lwSklutEZuuLdtS7pwtEZv",
        "SkluuLdtS7pwtUZvSkluuLdtS7pwtUZvSkluuLdtSrlvt7VttkdtTE1otrJwTVBtSrltt0dstrJvSrltTVBtt0dsta1ySrltt0dsT1Vmta1ySr",
        "ltt0dsT1Vms6huuEdtSrhtUVxls6huuEdtSrhtUVxlqpBuuEdtWnFtSrhtqpBuuEdtWnFtSrhtq5BvuEdtWnFtSrhtq5BvuEdtWnFtSrhtpH9y",
        "uEdvSrhtYIFkpH9yuEdvSrhtYIFkqFqgSrhtaJNogIAAqFqgSrhtaJNogIAAo0+iXLCUgIAAgIAAo0+iXLCUgIAAgIAAt0dwgkhtSrhtf7Rjt0",
        "dwgkhtSrhtf7RjdTxyt0hySbhti79rdTxyt0hySbhti79rt0hyaThtSbhtlsNrt0hyaThtSbhtlsNruEdwYThtSbhtn8RouEdwYThtSbhtn8Ro",
        "uEdvSrhtrMFtVD5ruEdvSrhtrMFtVD5ruEdvSrhtrMFtVD5ruEdvSrhtrMFtVD5ruEhwSrhtrMFtVD5ruEhwSrhtrMFtVD5ruEhwSrdts71qT0",
        "NquEhwSrdts71qT0NquEhySrZstLtrTEVouEhySrZstLtrTEVot0lxS0dvtbtsTLRrt0lxS0dvtbtsTLRrS0dwtktwTLJttrpqS0dwtktwTLJt",
        "trltS0dwtktwTLJttrltSkhtSrhtt7hquEhoSkhtSrhtt7hquEhoSkhtSrhtt0lst7hrTEpttUprTLZrtLZrTEpttUprTLZrtLZrUbBtUVBssK",
        "9nsFBmUbBtUVBssK9nsFBmo6Rio1xhXlxgXqRgo6Rio1xhXlxgXqRggIB3gIAAgIAAgIAAgIB3gIAAgIAAgIAAf39cgIAAgIAAgIAAf39cgIAA",
        "gIAAgIAAf39cgIAAgIAAgIAAf39cgIAAgIAAgIAAf4BTgIAAgIAAgIAAf4BTgIAAgIAAgIAAgIBQgIAAgIAAgIAAgIBQgIAAgIAAgIAAgIBNgI",
        "AAgIAAgIAAgIBNgIAAgIAAgIAAgIBNgIAAgIAAgIAAgIBNgIAAgIAAgIAAgoAdgIAAgIAAgIAAgoAdgIAAgIAAgIAAgoAdgIAAgIAAgIAAgoAd",
        "gIAAgIAAgIAAl4BmZH8+gIAAgIAAl4BmZH8+gIAAgIAAl4BmZH8+gIAAgIAAl4BmZH8+gIAAgIAAn4B1WIBDgIAAgIAAn4B1WIBDgIAAgIAAp4",
        "CAS4BLgIAAgIAAp4CAS4BLgIAAgIAArICHQoBKgIAAgIAArICHQoBKgIAAgIAAsICEO4BNgIAAgIAAsICEO4BNgIAAgIAAwYBuN4FXjoBEgIAA",
        "wYBuN4FXjoBEgIAAw4BuNX9dioBKgIAAw4BuNX9dioBKgIAAx4BnNIBjhoA9gIAAx4BnNIBjhoA9gIAAyIBqNIBmhYBCgIAAyIBqNIBmhYBCgI",
        "AAyoBtNIBmg4FFgIAAyoBtNIBmg4FFgIAAyoBtM4BqgIBDgIAAyoBtM4BqgIBDgIAAyoBtM4Bqf4BBgIAAyoBtM4Bqf4BBgIAAzYBkNoBke4FG",
        "gIAAzYBkNoBke4FGgIAAzYBkNoBke4FGgIAAzYBkNoBke4FGgIAANoBkzYBje4FGgIAANoBkzYBje4FGgIAANoFnzoBgeIBDgIAANoFnzoBgeI",
        "BDgIAAN4BnzoBgeIBDgIAAN4BnzoBgeIBDgIAAO4FrzoBgcYBIgIAAO4FrzoBgcYBIgIAAO4FrzoBgcYBIgIAAO4FrzoBgcYBIgIAAP4FqzoBg",
        "bYBCgIAAP4FqzoBgbYBCgIAAS4CCzoFggIAAgIAAS4CCzoFggIAAgIAAUIF9zYBggIAAgIAAUIF9zYBggIAAgIAAUoJ4yoBWgIAAgIAAUoJ4yo",
        "BWgIAAgIAAWIR2yX9SgIAAgIAAWIR2yX9SgIAAgIAAYIV8xn5agIAAgIAAYIV8xn5agIAAgIAAaYaMvnxUgIAAgIAAaYaMvnxUgIAAgIAAaYaM",
        "vnxUgIAAgIAAaYaMvnxUgIAAgIAAgI1yuntPRH1OgIAAgI1yuntPRH1OgIAAi5ByQH5NtHlJgIAAi5ByQH5NtHlJgIAAnYuHO39MgIAAgIAAnY",
        "uHO39MgIAAgIAApIyHN39QgIAAgIAApIyHN39QgIAAgIAAqYyFNYBTgIAAgIAAqYyFNYBTgIAAgIAAt5hrMYRdmnBKgIAAt5hrMYRdmnBKgIAA",
        "v5hsMIdjk21HgIAAv5hsMIdjk21HgIAAw5dtMYxfimhKgIAAw5dtMYxfimhKgIAAyZVlNJJjg2ZEgIAAyZVlNJJjg2ZEgIAAPqJlzY1ec19IgI",
        "AAPqJlzY1ec19IgIAAPqJlzY1dc19IgIAAPqJlzY1dc19IgIAARqpmzoddal5DgIAARqpmzoddal5DgIAAT7JqzIJVYV5DgIAAT7JqzIJVYV5D",
        "gIAAWrdsyXtXWWBKgIAAWrdsyXtXWWBKgIAAZbdwxnZTUmVKgIAAZbdwxnZTUmVKgIAAc7dwwHJUSmlMgIAAc7dwwHJUSmlMgIAAgbFwQ3BMun",
        "BKgIAAgbFwQ3BMunBKgIAAjqxzPnRUsm9KgIAAjqxzPnRUsm9KgIAAm6dwOXlRrG9HgIAAm6dyOXlQrG9HgIAAm6dyOXlQrG9HgIAAqKByNX5X",
        "pG9GgIAAs5luMoJbm3BJgIAAs5luMoJbm3BJgIAAvJNsMIRbk3FGgIAAvJNsMIRbk3FGgIAAw49tMYVfi3NEgIAAw49tMYVfi3NCgIAAw49tMY",
        "Vfi3NCgIAAyIpqM4dognVCgIAAzIdmN4hkeXdHgIAAzIdmN4hkeXdHgIAAO4htzYRecnhKgIAAO4htzYRecnhKgIAATISCzYNdgIAAgIAATIWA",
        "zYNdgIAAgIAATIWAzYNdgIAAgIAAUYSAy4NXgIAAgIAAVoZxyIJWgIAAgIAAVoZxyIJWgIAAgIAAYIN+xIFSgIAAgIAAYIN+xIFSgIAAgIAAZY",
        "KJwIFRgIAAgIAAZYKJwIFRgIAAgIAAhoF7QYBNtYFKgIAAhoF7QYBNtYFKgIAAhoF7QoBKtYFKgIAAhoF7QoBKtYFKgIAAmoCEPYBQgIAAgIAA",
        "moCEPYBQgIAAgIAAnoB5OYBNgIAAgIAAnoB5OYBNgIAAgIAApYB3Nn9XgIAAgIAApYB3Nn9XgIAAgIAArYB4NIBVgIAAgIAArYB4NIBVgIAAgI",
        "AAr4CDMoBWgIAAgIAAr4CDMoBWgIAAgIAAsYCIMIBdgIAAgIAAsYCIMIBdgIAAgIAAwYBtMIBhkYBIgIAAwYBtMIBhkYBIgIAAw4FuL4BijIFI",
        "gIAAw4FuL4BijIFIgIAAx4FoMIBlh4BCgIAAx4FoMIBlh4BCgIAAy39oN4BjeoFKgIAAy39oN4BjeoFKgIAAy39mN39me4FGgIAAy39mN39me4",
        "FGgIAAP3xgx31edIY9gIAAP3xgx31edIY9gIAASXpkwn1ZcIdFgIAASXpkwn1ZcIdFgIAAWnt0vX1XgIAAgIAAWnt0vX1XgIAAgIAAYnpst39L",
        "gIAAgIAAYnpst39LgIAAgIAAaXtvroFMgIAAgIAAaXtvroFMgIAAgIAAb3p1pIJJgIAAgIAAb3p1pIJJgIAAgIAAdHl7m4VRgIAAgIAAdHl7m4",
        "VRgIAAgIAAgX+VgIAAgIAAgIAAgX+VgIAAgIAAgIAAgH+IgIAAgIAAgIAAgH+IgIAAgIAAgIAAgYFwgIAAgIAAgIAAgYFwgIAAgIAAgIAAf4BV",
        "gIAAgIAAgIAAf4BVgIAAgIAAgIAAf4BAgIAAgIAAgIAAf4BAgIAAgIAAgIAAf4AmgIAAgIAAgIAAf4AmgIAAgIAAgIAAf4AmgIAAgIAAgIAAf4",
        "AmgIAAgIAAgIAAf4AmgIAAgIAAgIAAf4AmgIAAgIAAgIAAgH9LgIAAgIAAgIAAgH9LgIAAgIAAgIAAgH9LgIAAgIAAgIAAgH9LgIAAgIAAgIAA",
        "gH9LgIAAgIAAgIAAgIBNgIAAgIAAgIAAgIBNgIAAgIAAgIAAf39cgIAAgIAAgIAAf4CMgIAAgIAAgIAAf4CMgIAAgIAAgIAAf4CMgIAAgIAAgI",
        "AAgIC4gIAAgIAAgIAAgIC4gIAAgIAAgIAAgIC4gIAAgIAAgIAAq6tmqFJmWK5jVldfsbBsUVFqU7RkrkxisbBsUVFqU7Rkrk1isbBsUVFqU7Rk",
        "rk1isbBsUVFqU7Rlrk1isUlttLNrULhoT05ksUlttLNrULhoT05ktrVvTblus0dtTExotrVvTblus0dtTExot7ZvtEZtTEtsTLprubdwTLpttE",
        "VrSktquLdvTLtttEZrSkpquLdvTLtttEZrSkpqubdwS0pstEZrTLtrubdwS0pstEZrTLtrubdwtEVtS0psTLtrubdwtEVtS0psTLtrtEVvuLdv",
        "SkluTLpttEVvuLdvSkluTLptSklutEVtTLptuLdsSklutEVtTLptuLdsSkluuLdutEVtTLptSkluuLdutEVtTLptS7lvtUZuuLZuS0tsS7lvtU",
        "ZuuLZuS0tsS7lwuLZuTEtstUZrS7lwuLZuTEtstUZrtbByt0hvSrluTlJptbByt0hvSrluTlJptkhvtKpvSrltUFdptkhvtKpvSrltUFdpsqJz",
        "U2BtSrhtt0hssqJzU2BtSrhtt0hssqJzUmBtSrhtt0hssqJzUmBtSrhtt0hsrph4t0huSrhtV2porph4t0huSrhtV2pon3V4t0hwSrhtY4lsn3",
        "V4t0hwSrhtY4lsn3Z4t0hwSrhtY4psn3Z4t0hwSrhtY4pspVSgSrhtbpxjgIAAe0BxSbhthbptuEhqe0BySbhtuEhshrpqe0BySbhtuEhshrpq",
        "e0BySrhthbptuEhsbzp0uEhtSrhtksFtbzpzuEhtSrhtkcFtbzpzuEhtSrhtkcFtZDhzuEhtSbhtm8RquEhwXDptSbhtpMNtuEhwXDptSbhtpM",
        "NtuEhwXDptSbhtpMNtqcFwuEhuSbhtVz1sqcFwuEhuSbhtVz1srsBvUkBtSbhtuUhsrsBvUkBtSbhtuUhssb5wUEFvuEhuSrhts7xvuEhvSrds",
        "TUVqs7xvuEhvSrdsTUVquEluTEZsS7ZstbtsuEluTEZsS7ZstbtsS0ZvuElvtbptS7NqS0ZvuElvtbptS7NqtkxvSkdtTLFst7pptVFxSkdtuL",
        "lsT6tptVFxSkdtuLlsT6tps1dwSkhtuLltUKVps1dwSkhtuLltUKVpsWBwt7lvSkhtVJ1orGx0t7lvSkhtWJJmrGx0t7lvSkhtWJJmpnxzt7hv",
        "SkhtXoNmpnxzt7hvSkhtXoNmpX11SkhtuLhtXoNmpX11SkhtuLhtXoNmo62iXFOagIAAgIAAo62iXFOagIAAgIAApK2jXFOZgIAAgIAApK2jXF",
        "OZgIAAgIAAnLegSkhtfE9ngIAAnLegSkhtfE9ngIAAeMF0t7hvSUhtiENkeMF0t7hvSUhtiENkbMdxSUhtuLhskzxqbMdxSUhtuLhskzxqYshu",
        "SUhtuLhsnTprYshuSUhtuLhsnTprW8ZvpDttSUhtuLhrVcNvqj9tSkhtuLhrVcNvqj9tSkhtuLhrr0BxSkhtUsBtuLhqr0BxSkhtUsBtuLhqsk",
        "JxSkhtuLhsTr5sskJxSkhtuLhsTr5st7dxSklutEVrTLxqt7dxSklutEVrTLxqt7dwS7pttUZsS0ppuLduS7pttUZsS0ppuLduS7pttUZsS0pp",
        "t7RvSrlutkZsTE1ot7RvSrlutkZsTE1otrJwSrltt0dsTFBrtrJwSrltt0dsTFBrta1vSrhtuEdsT1Vlta1vSrhtuEdsT1Vls6hwt0dvSrhtUV",
        "xns6hwt0dvSrhtUVxnsZ9xSrhtuEdsVWVosZ9xSrhtuEdsVWVoq5BxSrhtuEdtWnJqq5BxSrhtuEdtWnJqpH9xuEdtSrhtX4FkpH9xuEdtSrht",
        "X4FkqFqeSrhtaJRogIAAqFqeSrhtaJRogIAAok+hXLCUgIAAgIAAok+hXLCUgIAAgIAAuEhvgkhtSbhtfrRmuEhvgkhtSbhtfrRmdTxyuEdtSb",
        "hti79saThvuEdvSbhtlsNnaThvuEdvSbhtlsNnYTlvuEdvSbhtoMVoYTlvuEdvSbhtoMVoWTpwuEdvSbhtp8NsWTpwuEdvSbhtp8NsVD5tuEdt",
        "SbhtrMFtVD5tuEdtSbhtrMFtuEdusb9uUUBtSbhtuEdusb9uUUBtSbhtuEduSbdts71qT0NquEduSbdts71qT0Nqt0hzSrdstLtrTEVot0hzSr",
        "dstLtrTEVouEluSrdstLtrTEVouEluSrdstLtrTEVouEtuSkdttbptTLJquEtuSkdttbptTLJqtk9ySkhtt7lrTa9otk9ySkhtt7lrTa9otFNy",
        "SkhtUKpst7lrtFNySkhtUKpst7lrslt1SkhtU6Jst7lsslt1SkhtU6Jst7lsslt1SkhtU6Jst7lsslt1SkhtU6Jst7lsqnN2SkhtuLhqW4toqn",
        "N2SkhtuLhqW4tooYdySkhtuLhpYnxopqefWVeagIAAgIAApqefWVeagIAAgIAAoLOiXU6VgIAAgIAAfrx1gkhtSkhtt7htfrx0Skhtgkhtt7ht",
        "frx0Skhtgkhtt7htcsRwSkhtt7hsjj5ocsRwSkhtt7hsjj5ocsR2Skhtt7htjj5qcsR2Skhtt7htjj5qZshwSUhtuLhtmDtrZshwSUhtuLhtmD",
        "trubhuSUhtojpsXsdrubhuSUhtojpsXsdruLhvSUhtWMNtqD1suLhvSUhtWMNtqD1subhvUsFuSUhtrT9rubhvUsFuSUhtrT9rsUFwublvUL9v",
        "SUhtsUFwublvUL9vSUhtuLhyskNwSUlvTb1quLhyskNwSUlvTb1qSUhtSrhtuLhtuEhrSUhtSrhtuLhtuEhrS7pwtUZsTExquLZqS7pwtUZsTE",
        "xquLZqSrlut7RtTE5stkdrSrlut7RtTE5stkdrtrBvSrltt0dqTlJqtrBvSrltt0dqTlJqtatvSrltt0dqUFhqtatvSrltt0dqUFhqsqFwU2Bt",
        "Srhtt0drsqFwU2BtSrhtt0drr5d2Srhtt0drV2tor5d2Srhtt0drV2toqIh1t0huSbhtXHhsqIh1t0huSbhtXHhsqmCgSbhtY4lsgIAAqmCgSb",
        "htY4lsgIAApVShWquVgIAAgIAApVShWquVgIAAgIAAn0ujX7OWgIAAgIAAn0ujX7OWgIAAgIAAt0hye0BuSbhthbpot0hye0BuSbhthbpobzpz",
        "t0hykcFvSbhtbzpzt0hykcFvSbhtt0hyZThxSbhtm8Rqt0hyZThxSbhtm8Rqt0hySbhtpMNtXDprt0hySbhtpMNtXDprt0hyqcFwVzxvSbhtt0",
        "hyqcFwVzxvSbhtuEhxrsBwUkBtSbhtuEhxrsBwUkBtSbhtuEhxsr9uUEFtSrhtuEhxsr9uUEFtSrhtuEhxTURvs7xvSrdtuEhxTURvs7xvSrdt",
        "S7ZvTEZtuElttbtsS7ZvTEZtuElttbtst0pvS0dstrprS7Nnt0pvS0dstrprS7NnSkhtt7ltt0xsTLBsSkhtt7ltt0xsTLBstVFyt7lwSkhtTq",
        "tttVFyt7lwSkhtTqttt7hys1dvSkhtUaZnt7hys1dvSkhtUaZnuLhwSkhtsmBtVJ1muLhwSkhtsmBtVJ1mrGx0Skhtt7lrWJJnrGx0Skhtt7lr",
        "WJJnpX12Skhtt7lrXoNmpX12Skhtt7lrXoNmqaOdSkhtZnFjgIAAqaOdSkhtZnFjgIAApK2iXFOYgIAAgIAApK2iXFOYgIAAgIAAnbehSkhtfE",
        "5kgIAAnbehSkhtfE5kgIAAeMF1SkhtuLltiENmeMF1SkhtuLltiENmt7hya8dxSkhtkz1qt7hya8dxSkhtkz1qSkhtYshtuLhtnTprSkhtYsht",
        "uLhtnTprW8ZySkhtpTttuLhtW8ZySkhtpTttuLhtqz5wt7huSkhtVcJtqz5wt7huSkhtVcJtr0BvSkhtUsBtuLhtr0BvSkhtUsBtuLhtskFuSk",
        "htT75tt7hsskFuSkhtT75tt7hsSkluuLdttERrTLxqSkluuLdttERrTLxqt7duS7pttUZsS0tqt7duS7pttUZsS0tqSrlut7VttkdqTE1oSrlu",
        "t7VttkdqTE1otrJvSrhtt0dsTVBotrJvSrhtt0dsTVBoSrhtta5tt0dsT1VmSrhtta5tt0dsT1Vms6hwSrhtuEdsUVxms6hwSrhtuEdsUVxmsZ",
        "5xSrhtuEdtVWVosZ5xSrhtuEdtVWVoq5BuuEdtSrhtWXJqq5BuuEdtSrhtWXJqo39wSrhtuEdtX4Fmo39wSrhtuEdtX4FmqFqgSbhtaJNogIAA",
        "qFqgSbhtaJNogIAAo1CdXa+WgIAAgIAAo1CdXa+WgIAAgIAAnEieSrhtfrVmgIAAnEieSrhtfrVmgIAAdTxyt0dvSbhti79rdTxyt0dvSbhti7",
        "9ruEhvajhtSbhtl8NkuEhvajhtSbhtl8NkYThvuEhvSbhtoMRqYThvuEhvSbhtoMRqWTpwuEhvSbhtp8NtWTpwuEhvSbhtp8NtuEhwSrhtrMFt",
        "VT5ruEhwSrhtrMFtVT5ruEhwsL9uUkBtSrhtuEhwSrdts71tT0NpuEhwSbdts71qT0JouEhwSbdts71qT0JouElvSbZvtLtrTEVoS0dwt0lvtb",
        "tsS7VqS0dwuElttbpsS7RqS0dwuElttbpsS7RqtktxSkhtTLJttrlttktySkhtTLJttrpptktySkhtTLJttrpptVNuSkhtUKptt7lrslt0Skht",
        "t7ltUqJsslt1Skhtt7ltUqJsslt1Skhtt7ltUqJsr2ZySkhtt7ltVphmqnN2SkhtuLhrW4ppqnN2SkhtW4ppuLhpqnN2SkhtW4ppuLhpood0Sk",
        "htuLhrYntmoYdySkhtuLhqYntmoodySUhtuLhoYntmoodySUhtuLhoYntmoodySUhtuLhoYntmp6iiWVeagIAAgIAAoLKjXk6UgIAAgIAAoLOk",
        "Xk+UgIAAgIAAoLOkXk+UgIAAgIAAcsR3SUhtuLhrjj5ocsR3SUhtuLhrjj5oZshwublvSkhtmDtsubhvSUhtojpsXsZsubhvSUhtojpsXsZsub",
        "hvqD1uWMNuSUhtubhvqD1uWMNuSUhtubhvUsFuSUhtrT9subhvUsFuSUhtrT9subhvUL9vSUhtsUFtubhvUL9vSUhtsUFtubhvSUltTbxtskRq",
        "ubhvSUltTbxtskRqubhvTbxuSklts0RtubhvTbxuSklts0RtS7lwt7ZvtkdqS0xqS7lwt7ZvtkdqS0xqt7NytkdvSrluTE9st7NytkdvSrluTE",
        "9stbFySrlutkdsTlJqtbFySrlutkdsTlJqtatvSrlutkdtUFhrtatvSrlutkdtUFhrsqJzU2BtSrltt0dtsqJzU2BtSrltt0dtrph1t0duSrht",
        "V2torph1t0duSrhtV2toqIh1t0dvSrhtXXlmqIh1t0dvSrhtXXlmq1+iSbhtZIppgIAAq1+iSbhtZIppgIAApVSfWquTgIAAgIAApVSfWquTgI",
        "AAgIAAn0ufYLOWgIAAgIAAn0ufYLOWgIAAgIAAe0ByuEhtSbhthbpre0ByuEhtSbhthbprbzp0t0hwkcFvSbhtbzp0t0hwkcFvSbhtbzl3kcFw",
        "uEduSbhtbzl3kcFwuEduSbhtZDhzt0dxSbhtm8RsZDhzt0dxSbhtm8RsuEduXDptSbhto8NtuEduXDptSbhto8NtVz1wuEduqsFuSbhtVz1wuE",
        "duqsFuSbhtrsBxuEduUkBtSbhtrsBxuEduUkBtSbhtsr1uSrdtUEFtuEhrsr1uSrdtUEFtuEhrs7xvTURtuEhsSrdss7xvTURtuEhsSrdsSkht",
        "Srhtt7dsuEhpSkhtSrhtt7dsuEhpSkhtSrhtt0hrt7dqSkhtSrhtt0hrt7dqSkhtSrhtt0hruLhoSkhtSrhtt0hruLhoSkhtSrhtt0hsuLhpSk",
        "htSrhtt0hsuLhpSkhtSrhtt0hsuLhpSkhtSrhtt0hsuLhpSkhtSrhtt0hsuLhpUbBtUVBsr1BmsLBmUbBtUU9ssLBor1BmUbBtUU9ssLBor1Bm",
        "o6NiolxhXlxgXqRgo6NiolxhXlxgXqRgolxhXlxgXqRgoqRgolxhXlxgXqRgoqRggICqgIAAgIAAgIAAgYB1gIAAgIAAgIAAgYB1gIAAgIAAgI",
        "AAgYB1gIAAgIAAgIAAf39hgIAAgIAAgIAAf39hgIAAgIAAgIAAgIBPgIAAgIAAgIAAgIBPgIAAgIAAgIAAgIBNgIAAgIAAgIAAgIBNgIAAgIAA",
        "gIAAgIBNgIAAgIAAgIAAgIBNgIAAgIAAgIAAf39BgIAAgIAAgIAAf39BgIAAgIAAgIAAf39BgIAAgIAAgIAAf39BgIAAgIAAgIAAhH49gIAAgI",
        "AAgIAAhH49gIAAgIAAgIAAinlLgIAAgIAAgIAAinlLgIAAgIAAgIAAinlLgIAAgIAAgIAAinlLgIAAgIAAgIAAlnJagIAAgIAAgIAAlnJagIAA",
        "gIAAgIAAlnJagIAAgIAAgIAAlnJagIAAgIAAgIAAnG9dgIAAgIAAgIAAnG9dgIAAgIAAgIAApWpmgIAAgIAAgIAApWpmgIAAgIAAgIAAqWdsgI",
        "AAgIAAgIAAqWdsgIAAgIAAgIAArWZtgIAAgIAAgIAArWZtgIAAgIAAgIAArWZugIAAgIAAgIAArWZugIAAgIAAgIAAsWJygIAAgIAAgIAAsWJy",
        "gIAAgIAAgIAAsmFwgIAAgIAAgIAAsmFwgIAAgIAAgIAAtV93gIAAgIAAgIAAtV93gIAAgIAAgIAAuF90bnQygIAAgIAAuF90bnQygIAAgIAAul",
        "51Z3I4gIAAgIAAul51Z3I4gIAAgIAAu114XGtNgIAAgIAAu114XGtNgIAAgIAAu114XGtPgIAAgIAAu114XGtPgIAAgIAAvFxyV2lYgIAAgIAA",
        "vFxyV2lYgIAAgIAAvFtsT2RjgIAAgIAAvFtsT2RjgIAAgIAAT2NsvFxigIAAgIAAT2NsvFxigIAAgIAAT2NsvVxkgIAAgIAAT2NsvVxkgIAAgI",
        "AAT2NsvVxkgIAAgIAAT2NsvVxkgIAAgIAATGFvu11fgIAAgIAATGFvu11fgIAAgIAASmBtt15Yf3EqgIAASmBtt15Yf3EqgIAASV9ytWFKf2wz",
        "gIAASV9ytWFKf2wzgIAARl51gWZFsWNDgIAARl51gWZFsWNDgIAARF5ygGBNq2c9gIAARF5ygGBNq2c9gIAAQ15zf1lYomw1gIAAQ15zf1lYom",
        "w1gIAAQl1wgFRdmnAdgIAAQl1wgFRdmnAdgIAAgEptQl1tgIAAgIAAgEptQl1tgIAAgIAAgUdwQ1xkgIAAgIAAgUdwQ1xkgIAAgIAAgUJyRFxm",
        "gIAAgIAAgUJyRFxmgIAAgIAAgUNzRFxmgIAAgIAAgUNzRFxmgIAAgIAAgT51SmFPb4kqgIAAgT51SmFPb4kqgIAAgDx4TmNRao1AgIAAgDx4Tm",
        "NRao1AgIAAgDx4TmNSao0+gIAAgDx4TmNSao0+gIAAgTpzY5FGVWdCgIAAgTpzY5FGVWdCgIAAgDp1X5NXW2pCgIAAgDhwVphgcnEfgIAAgDhw",
        "VphgcHYRgIAAgDhwVphgcHYRgIAAgThsVphgcHYRgIAAUpptgDhrgIAAgIAAUpptgDhrgIAAgIAAT51ofzhmgIAAgIAATJ9wfzxggIAAgIAATJ",
        "9wfztfgIAAgIAATJ9wfztfgIAAgIAASp9yfz5giogdgIAASKByf0RXj4swgIAASKB1f0RYj4o4gIAASKB1f0RYj4o4gIAARqF2f0pPl402gIAA",
        "RaF2m5BLf1FCgIAARaF3m5BLf1FAgIAARaF3m5BLf1FAgIAARKJzn5NYflszgIAARKJ1n5NYflszgIAARKJzoJNZflszgIAARKJzoJNZflszgI",
        "AAQ6JzqZhtgIAAgIAAQ6JwrZpsgIAAgIAAQqJyrZpsgIAAgIAAQqJyrZpsgIAAgIAAsZtwQ6FugIAAgIAAs59wRKFogIAAgIAAs59wRKFogIAA",
        "gIAAs59wRKFogIAAgIAAtaB2R6BigIAAgIAAtaB1R6BggIAAgIAAtaB1R6BggIAAgIAAtaB1R6BggIAAgIAAuaFwT5xRf5wzgIAAu6Fzf6NPVJ",
        "lGgIAAu6FzgKNMVJlIgIAAu6FzgKNMVJlIgIAAvKJygapPW5Q9gIAAvaJvf69XY5AtgIAAvKJwf69aY5AtgIAAvKJwf69aY5AtgIAAvaJxf7Rf",
        "cYcaao4WvKJvgbdqgIAAgIAAvaJtgbdpgIAAgIAAvaJtgbdpgIAAgIAAgbptu6JsgIAAgIAAgbptu6JsgIAAgIAAgbttu6FsgIAAgIAAgbttu6",
        "FsgIAAgIAAgcByt59dinoigIAAgcJys51TkHUtgIAAgcJys51TkHUtgIAAgcJzrZpMlnI4gIAAgcJzrZpMlnI4gIAAgMR3m3BMpZdDgIAAgMZ5",
        "n21dn5M1gIAAgMZ5n21dn5M1gIAAgMZ5n21dn5M2gIAAgMZ5n21dn5M2gIAAgMd0pWtdlpAmgIAAgMd0pWtdlpAmgIAAf8dtrWVogIAAgIAAf8",
        "dtrWVogIAAgIAAsWNwgMZqgIAAgIAAsWJzgMZrgIAAgIAAsWJzgMZrgIAAgIAAsWJzgMZsgIAAgIAAsWJzgMZsgIAAgIAAs2F1f8RkgIAAgIAA",
        "s2F1f8RkgIAAgIAAtmB1f8JegIAAgIAAtmB1f8JegIAAgIAAuF93f71dbnQzgIAAuF93f71dbnQzgIAAul51f7lRZnMzgIAAul51f7lRZnMzgI",
        "AAu113W2lPf6o8gIAAu113W2lPf6o8gIAAu1x2V2hZfp43gIAAu1x2V2hZfp43gIAAvFxwVGVefpIvgIAAvFxwVGVefpIvgIAAvFxsUGNmgIAA",
        "gIAAvFxsUGNmgIAAgIAAUGNtvF1qgIAAgIAAUGNtvF1qgIAAgIAAUGNtvF1qgIAAgIAAUGNtvF1qgIAAgIAATGByul1igIAAgIAATGByul1igI",
        "AAgIAASV91tGFQfmwzgIAASV91tGFQfmwzgIAARl5zsWNJgWZEgIAARl5zsWNJgWZEgIAARV5zgGBMqWdGgIAARV5zgGBMqWdGgIAARF5zgGBM",
        "qWZEgIAARF5zgGBMqWZEgIAAQ11zf1paoWwygIAAQ11zf1paoWwygIAAQ11zgFVdmnAdgIAAQ11zgFVdmnAdgIAAQ1xwgE9mgIAAgIAAQ1xwgE",
        "9mgIAAgIAAgEZtRFxlgIAAgIAAgEZtRFxlgIAAgIAAgEduRFxlgIAAgIAAgEduRFxlgIAAgIAAgUBtR11egIAAgIAAgUBtR11egIAAgIAAgT52",
        "S19Qb4kqgIAAgT52S19Qb4kqgIAAgTt2T2JTaYw+gIAAgTt2T2JTaYw+gIAAgTp0Y5BKVWdBgIAAgTp0Y5BKVWdBgIAAgTp0Y5BKVWdCgIAAgT",
        "p0Y5BKVWdCgIAAgTlwWpVaZXAkgIAAgTlwWpVaZXAkgIAAgDhvVphgcXQigIAAgDhvVphgcXQigIAAgDdsUpprgIAAgIAAgDdsUpprgIAAgIAA",
        "T5xpfzhlgIAAgIAAT5xpfzhlgIAAgIAAT5xpfzhmgIAAgIAAT5xpfzhmgIAAgIAATJ9wfzthgIAAgIAATJ9wfzthgIAAgIAASaByf0NYj4o4gI",
        "AARqF1f0pLlo04gIAARqF1f0pLlo04gIAARaFym5BMf1FBgIAARaFzm5BMf1FBgIAARaFym5BMf1FBgIAARaFym5BMf1FBgIAARKJwoJNYflsz",
        "gIAAQ6NxppVif2IrgIAAQ6JypZZggmIigIAAQ6JypZZggmIigIAAQ6NvqZhsgm4WgIAAQ6NvqZhsgG4RgIAAQ6NvqphtgG4RgIAAQ6NvqphtgG",
        "4RgIAAsJxvQ6JpgIAAgIAAs59wRKJpgIAAgIAAs59wRKJogIAAgIAAs59wRKJogIAAgIAAtaB2R6BhgIAAgIAAt6B3S55Tf5UtgIAAuKB1S55T",
        "gJUtgIAAuKB1S55TgJUtgIAAuaFzT5tUf5wzgIAAuaFzT5tUf5wzgIAAuaFwT5xUf5wzgIAAuaFwT5xUf5wzgIAAu6J3f6lRW5Q9gIAAu6J3f6",
        "lRW5Q9gIAAvKJzf65aZZAmgIAAvKJzf65aZZAmgIAAvKJwgLRfcYcagIAAvKJwgLRfcYcagIAAvaJvgbdrgIAAgIAAvaJvgbdrgIAAgIAAgbpv",
        "vKJpgIAAgIAAgbpvvKJpgIAAgIAAgL1vuqFqgIAAgIAAgL1vuqFqgIAAgIAAgcByt59dingdgIAAgcByt59dingdgIAAgMFzs51Wj3U1gIAAgM",
        "Fzs51Wj3U1gIAAgcJyrplIlXFCgIAAgcJyrplIlXFCgIAAgcR2m3BMpZdDgIAAgMZ2oGxan5M1gIAAgMZyoG1an5M2gIAAgMZyoG1an5M2gIAA",
        "gMd1pWtdl5AmgIAAgMd1pWtdl5AmgIAAgMdvqWdpgIAAgIAAgMdvqWdpgIAAgIAAgMdvrWVmgIAAgIAAgMdvrWVmgIAAgIAAsWJygMZsgIAAgI",
        "AAsWJygMZsgIAAgIAAs2Fyf8RjgIAAgIAAtmB1f8FggIAAgIAAtmB1f8FggIAAgIAAuF93f71dbXMygIAAuF93f71dbXMygIAAul51f7hRZ3E4",
        "gIAAul51f7hRZ3E4gIAAul15frJNYW5EgIAAul15frJNYW5EgIAAu1x6XGpMf6s2gIAAu1x6XGpMf6s2gIAAu113XGpMgKo8gIAAu113XGpMgK",
        "o8gIAAu112V2haf6AzgIAAu112V2haf6AzgIAAvFxxU2VffpItgIAAvFxxU2VffpItgIAAvFxrUWNjgYcagIAATGFuulxhgXcagIAATWFxulxg",
        "gXcagIAATWFxulxggXcagIAASl9vt11XgnIigIAASl9vt11XgnIigIAAS19wuF5UgnMkgIAAS19wuF5UgnMkgIAASV9wtGFJgG0tgIAAR15qsm",
        "NEgWZBgIAAR15qsmNEgWZBgIAARl5rgGFDq2Y7gIAARl5rgGFDq2Y7gIAARFxrflpaomwmgIAARFxrflpaomwmgIAAQ1xqf05mgIAAgIAAQ1xq",
        "f05mgIAAgIAAQ1xqfk5mgIAAgIAAQ1xqfk5mgIAAgIAAQ1xlf0xkgIAAgIAAgUhtQ1xjgIAAgIAAgUhtQ1xjgIAAgIAAgUhtQ1xjgIAAgIAAgE",
        "RtRVxdgIAAgIAAgUFvRl1agIAAgIAAgUFvRl1agIAAgIAAgUBzSl9NgIAAgIAAbUhYRWotgIAAgIAAbUhYRWotgIAAgIAAPmMvgIAAgIAAgIAA",
        "gIAAgIAAgIAAgIAAgIAAgIAAgIAAgIAAgIAAgIAAgIAAgIAAgIAAgIAAgIAAgIAAgIAAgIAAgIAAgIAAgIAAgIAAgIAAgIAA"
        ).joinToString(""), Base64.NO_WRAP)
    }
}
