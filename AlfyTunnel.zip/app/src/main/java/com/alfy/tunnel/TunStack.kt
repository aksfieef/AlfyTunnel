package com.alfy.tunnel

import java.io.DataInputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.Random
import java.util.concurrent.Callable
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

private const val M = 0xFFFFFFFFL
private val MSS: Int get() = (Prefs.mtu.value.coerceIn(576, 1500) - 40).coerceAtMost(1360)
private const val F_FIN = 1
private const val F_SYN = 2
private const val F_RST = 4
private const val F_PSH = 8
private const val F_ACK = 16

private fun u16(b: ByteArray, o: Int) = ((b[o].toInt() and 255) shl 8) or (b[o + 1].toInt() and 255)
private fun u32(b: ByteArray, o: Int) = (u16(b, o).toLong() shl 16) or u16(b, o + 2).toLong()
private fun p16(b: ByteArray, o: Int, v: Int) {
    b[o] = (v shr 8).toByte()
    b[o + 1] = v.toByte()
}
private fun p32(b: ByteArray, o: Int, v: Long) {
    p16(b, o, ((v shr 16) and 0xFFFF).toInt())
    p16(b, o + 2, (v and 0xFFFF).toInt())
}
private const val DNS_FALLBACK = (1L shl 24) or (1L shl 16) or (1L shl 8) or 1L // 1.1.1.1
private fun ipStr(v: Long) = "${(v shr 24) and 255}.${(v shr 16) and 255}.${(v shr 8) and 255}.${v and 255}"

private fun csum(b: ByteArray, o: Int, l: Int, init: Long = 0): Int {
    var s = init
    var i = o
    val e = o + l
    while (i + 1 < e) {
        s += ((b[i].toInt() and 255) shl 8) or (b[i + 1].toInt() and 255)
        i += 2
    }
    if (i < e) s += (b[i].toInt() and 255) shl 8
    while ((s shr 16) != 0L) s = (s and 0xFFFF) + (s shr 16)
    return (s.inv() and 0xFFFF).toInt()
}

/** Stack TCP/IP userspace minimal (pengganti tun2socks): TCP -> channel direct-tcpip SSH, DNS UDP -> DNS-over-TCP lewat SSH. */
class TunStack(
    private val tunIn: InputStream,
    private val tunOut: OutputStream,
    private val link: TunnelLink
) {
    @Volatile private var running = true
    @Volatile var isRunning: Boolean = false
        private set
    private val pool = Executors.newCachedThreadPool { r -> Thread(r).apply { isDaemon = true } }
    private val conns = ConcurrentHashMap<String, Conn>()
    private val wlock = Any()
    private val rnd = Random()
    private val EOF = ByteArray(0)

    fun loop() {
        isRunning = true
        val buf = ByteArray(32768)
        var sweep = System.currentTimeMillis()
        try {
            while (running) {
                val n = tunIn.read(buf)
                if (n < 0) break
                if (n > 0) {
                    try { handle(buf, n) } catch (e: Exception) { }
                }
                val now = System.currentTimeMillis()
                if (now - sweep > 1000) {
                    sweep = now
                    conns.values.forEach { if (now - it.last > 120000 || it.ackStalled(now)) it.kill(true) }
                }
            }
        } catch (e: Exception) { }
        stop()
    }

    fun reset() {
        conns.values.forEach { it.kill(true) }
    }

    fun stop() {
        running = false
        isRunning = false
        conns.values.forEach { it.kill(false) }
        gw.close()
        pool.shutdownNow()
    }

    private fun emit(p: ByteArray) {
        synchronized(wlock) {
            try {
                tunOut.write(p)
                Mon.rx.addAndGet(p.size.toLong())
            } catch (e: Exception) { }
        }
    }

    private fun handle(b: ByteArray, n: Int) {
        if (n < 20 || (b[0].toInt() shr 4) != 4) return
        val ihl = (b[0].toInt() and 15) * 4
        val tot = minOf(u16(b, 2), n)
        if (ihl < 20 || tot < ihl) return
        if ((u16(b, 6) and 0x3FFF) != 0) return
        val src = u32(b, 12)
        val dst = u32(b, 16)
        when (b[9].toInt() and 255) {
            6 -> tcp(b, ihl, tot, src, dst)
            17 -> udp(b, ihl, tot, src, dst)
        }
    }

    private fun tcp(b: ByteArray, o: Int, tot: Int, src: Long, dst: Long) {
        if (tot - o < 20) return
        val sp = u16(b, o)
        val dp = u16(b, o + 2)
        val seq = u32(b, o + 4)
        val ack = u32(b, o + 8)
        val doff = ((b[o + 12].toInt() shr 4) and 15) * 4
        val fl = b[o + 13].toInt() and 63
        val win = u16(b, o + 14)
        val ds = o + doff
        if (doff < 20 || ds > tot) return
        val dl = tot - ds
        val key = "$src:$sp>$dst:$dp"
        val c = conns[key]
        if ((fl and F_RST) != 0) {
            c?.kill(false)
            return
        }
        if (c == null) {
            if ((fl and F_SYN) != 0 && (fl and F_ACK) == 0) {
                newConn(key, src, sp, dst, dp, seq, win)
            } else if ((fl and F_ACK) != 0) {
                tcpPkt(dst, dp, src, sp, ack, 0, F_RST, null, 0, 0, false)
            } else {
                val a = (seq + dl + (if ((fl and (F_SYN or F_FIN)) != 0) 1 else 0)) and M
                tcpPkt(dst, dp, src, sp, 0, a, F_RST or F_ACK, null, 0, 0, false)
            }
            return
        }
        c.last = System.currentTimeMillis()
        if (!c.ready || (fl and F_SYN) != 0) return
        if ((fl and F_ACK) != 0 && ((ack - c.acked) and M) < 0x80000000L) c.acked = ack
        if ((fl and F_ACK) != 0) c.lastAckTime = System.currentTimeMillis()
        c.peerWin = win
        if (dl > 0) {
            var off = ds
            var len = dl
            var sq = seq
            if (((sq - c.peerNext) and M) >= 0x80000000L) {
                val ov = (c.peerNext - sq) and M
                if (ov < len) {
                    off += ov.toInt()
                    len -= ov.toInt()
                    sq = c.peerNext
                } else {
                    len = 0
                }
            }
            if (len > 0 && sq == c.peerNext) {
                c.q.offer(b.copyOfRange(off, off + len))
                c.peerNext = (c.peerNext + len) and M
            }
            c.send(F_ACK)
        }
        if ((fl and F_FIN) != 0) {
            if (!c.finRcv && ((seq + dl) and M) == c.peerNext) {
                c.finRcv = true
                c.peerNext = (c.peerNext + 1) and M
                c.q.offer(EOF)
            }
            c.send(F_ACK)
        }
        if (c.finSent && c.finRcv && c.acked == c.mySeq) c.kill(false)
    }

    private fun newConn(key: String, di: Long, sp: Int, ri: Long, rp: Int, irs: Long, win: Int) {
        val c = Conn(key, di, sp, ri, rp, irs, win)
        if (conns.putIfAbsent(key, c) != null) return
        pool.execute {
            try {
                val ch = link.open(ipStr(ri), rp)
                c.ch = ch
                c.rin = ch.inputStream
                c.rout = ch.outputStream
                ch.connect(10000)
            } catch (e: Throwable) {
                c.closed = true
                conns.remove(key)
                try { c.ch?.disconnect() } catch (x: Exception) { }
                tcpPkt(ri, rp, di, sp, 0, (irs + 1) and M, F_RST or F_ACK, null, 0, 0, false)
                return@execute
            }
            c.start()
        }
    }

    private fun tcpPkt(
        ri: Long, rp: Int, di: Long, dp: Int, seq: Long, ack: Long, fl: Int,
        d: ByteArray?, off: Int, len: Int, mss: Boolean
    ) {
        val th = if (mss) 24 else 20
        val tl = th + len
        val p = ByteArray(20 + tl)
        p[0] = 0x45
        p16(p, 2, p.size)
        p[6] = 0x40
        p[8] = 64
        p[9] = 6
        p32(p, 12, ri)
        p32(p, 16, di)
        p16(p, 10, csum(p, 0, 20))
        val t = 20
        p16(p, t, rp)
        p16(p, t + 2, dp)
        p32(p, t + 4, seq)
        p32(p, t + 8, ack)
        p[t + 12] = ((th / 4) shl 4).toByte()
        p[t + 13] = fl.toByte()
        p16(p, t + 14, 65535)
        if (mss) {
            p[t + 20] = 2
            p[t + 21] = 4
            p16(p, t + 22, MSS)
        }
        if (len > 0 && d != null) System.arraycopy(d, off, p, t + th, len)
        val pseudo = (ri shr 16) + (ri and 0xFFFF) + (di shr 16) + (di and 0xFFFF) + 6 + tl
        p16(p, t + 16, csum(p, t, tl, pseudo))
        emit(p)
    }

    private fun udpPkt(ri: Long, rp: Int, di: Long, dp: Int, d: ByteArray) {
        val p = ByteArray(28 + d.size)
        p[0] = 0x45
        p16(p, 2, p.size)
        p[6] = 0x40
        p[8] = 64
        p[9] = 17
        p32(p, 12, ri)
        p32(p, 16, di)
        p16(p, 10, csum(p, 0, 20))
        p16(p, 20, rp)
        p16(p, 22, dp)
        p16(p, 24, 8 + d.size)
        System.arraycopy(d, 0, p, 28, d.size)
        emit(p)
    }

    private fun udp(b: ByteArray, o: Int, tot: Int, src: Long, dst: Long) {
        if (tot - o < 8) return
        val sp = u16(b, o)
        val dp = u16(b, o + 2)
        val ul = u16(b, o + 4) - 8
        if (ul <= 0 || o + 8 + ul > tot) return
        val q = b.copyOfRange(o + 8, o + 8 + ul)
        if (dp != 53) {
            // Bukan DNS: lewat klien UDPGW (BadVPN) bila port UDPGW aktif, selain itu dibuang.
            val gp = Prefs.udpgwPort.value
            if (gp == 0) return
            pool.execute {
                try { gw.send(src, sp, dst, dp, q) } catch (e: Exception) { }
            }
            return
        }
        pool.execute {
            try {
                // DNS fallback: tujuan IP lokal (192.168/16, 10/8, 172.16/12) dialihkan ke 1.1.1.1
                val target = if (isLocalIp(dst)) DNS_FALLBACK else dst
                val r = dns(target, q)
                if (r != null) udpPkt(dst, 53, src, sp, r)
            } catch (e: Exception) { }
        }
    }

    private fun isLocalIp(v: Long): Boolean {
        val a = ((v shr 24) and 255).toInt()
        val b2 = ((v shr 16) and 255).toInt()
        return a == 10 || (a == 192 && b2 == 168) || (a == 172 && b2 in 16..31)
    }

    private val gw = UdpGw()

    /**
     * Klien UDPGW BadVPN. Satu koneksi TCP (lewat tunnel SSH) ke host SSH aktif:port UDPGW,
     * dipakai bersama oleh semua alur UDP (dibedakan conid).
     * Frame: [len LE u16][flags u8][conid LE u16][IPv4 4B][port BE u16][payload]; len = 9 + payload.
     */
    private inner class UdpGw {
        private val lock = Any()
        private var ch: SshChan? = null
        private var out: OutputStream? = null
        private var gen = 0
        private var nextId = 0
        private val flows = HashMap<Int, GwFlow>()
        private val ids = HashMap<String, Int>()

        private inner class GwFlow(val id: Int, val src: Long, val sp: Int, val dst: Long, val dp: Int) {
            @Volatile var last = System.currentTimeMillis()
        }

        fun send(src: Long, sp: Int, dst: Long, dp: Int, d: ByteArray) {
            if (d.size > 65000) return
            synchronized(lock) {
                if (!running) return
                val now = System.currentTimeMillis()
                // Buang alur UDP yang idle > 120 dtk
                if (flows.size > 64) {
                    val it = flows.values.iterator()
                    while (it.hasNext()) {
                        val f = it.next()
                        if (now - f.last > 120000) { it.remove(); ids.remove("${f.src}:${f.sp}>${f.dst}:${f.dp}") }
                    }
                }
                val key = "$src:$sp>$dst:$dp"
                var f = ids[key]?.let { flows[it] }
                if (f == null) {
                    if (flows.size >= 512) {
                        flows.values.minByOrNull { it.last }?.let { old ->
                            flows.remove(old.id); ids.remove("${old.src}:${old.sp}>${old.dst}:${old.dp}")
                        }
                    }
                    do { nextId = (nextId % 65535) + 1 } while (flows.containsKey(nextId))
                    f = GwFlow(nextId, src, sp, dst, dp)
                    flows[f.id] = f
                    ids[key] = f.id
                }
                f.last = now
                val o = ensure()
                val fr = ByteArray(11 + d.size)
                val len = 9 + d.size
                fr[0] = len.toByte(); fr[1] = (len shr 8).toByte()
                fr[2] = 0
                fr[3] = f.id.toByte(); fr[4] = (f.id shr 8).toByte()
                p32(fr, 5, dst)
                p16(fr, 9, dp)
                System.arraycopy(d, 0, fr, 11, d.size)
                try {
                    o.write(fr)
                    o.flush()
                    Mon.tx.addAndGet(d.size.toLong())
                } catch (e: Exception) {
                    drop()
                }
            }
        }

        private fun ensure(): OutputStream {
            out?.let { return it }
            val c = link.open(link.host, Prefs.udpgwPort.value)
            c.connect(10000)
            ch = c
            out = c.outputStream
            val g = ++gen
            val ins = c.inputStream
            pool.execute { readLoop(g, ins) }
            return out!!
        }

        private fun drop() {
            synchronized(lock) {
                try { ch?.disconnect() } catch (e: Exception) { }
                ch = null
                out = null
                gen++
            }
        }

        private fun readLoop(g: Int, i: InputStream) {
            try {
                val d = DataInputStream(i)
                while (running && g == gen) {
                    val len = d.readUnsignedByte() or (d.readUnsignedByte() shl 8)
                    val b = ByteArray(len)
                    d.readFully(b)
                    if (len < 3) continue
                    val fl = b[0].toInt() and 255
                    if ((fl and 1) != 0) continue // keepalive
                    val id = (b[1].toInt() and 255) or ((b[2].toInt() and 255) shl 8)
                    val ao = 3 + (if ((fl and 8) != 0) 18 else 6)
                    if (ao > len) continue
                    val f = synchronized(lock) { flows[id] } ?: continue
                    f.last = System.currentTimeMillis()
                    udpPkt(f.dst, f.dp, f.src, f.sp, b.copyOfRange(ao, len))
                }
            } catch (e: Exception) { }
            synchronized(lock) { if (g == gen) drop() }
        }

        fun close() {
            synchronized(lock) {
                try { ch?.disconnect() } catch (e: Exception) { }
                ch = null
                out = null
                gen++
                flows.clear()
                ids.clear()
            }
        }
    }

    private fun dns(dst: Long, q: ByteArray): ByteArray? {
        val ch = link.open(ipStr(dst), 53)
        val i = ch.inputStream
        val o = ch.outputStream
        try {
            ch.connect(5000)
            val f = pool.submit(Callable<ByteArray> {
                o.write(byteArrayOf((q.size shr 8).toByte(), q.size.toByte()) + q)
                o.flush()
                val d = DataInputStream(i)
                val r = ByteArray(d.readUnsignedShort())
                d.readFully(r)
                r
            })
            return f.get(6, TimeUnit.SECONDS)
        } finally {
            try { ch.disconnect() } catch (e: Exception) { }
        }
    }

    inner class Conn(
        val key: String, val di: Long, val sp: Int, val ri: Long, val rp: Int, irs: Long, win: Int
    ) {
        @Volatile var peerNext = (irs + 1) and M
        @Volatile var mySeq = rnd.nextInt().toLong() and M
        @Volatile var acked = 0L
        @Volatile var peerWin = win
        @Volatile var ready = false
        @Volatile var closed = false
        @Volatile var last = System.currentTimeMillis()
        @Volatile var lastAckTime = System.currentTimeMillis()
        @Volatile var finSent = false
        @Volatile var finRcv = false
        val q = LinkedBlockingQueue<ByteArray>()
        var ch: SshChan? = null
        lateinit var rin: InputStream
        lateinit var rout: OutputStream

        fun send(fl: Int, d: ByteArray? = null, off: Int = 0, len: Int = 0, mss: Boolean = false) {
            synchronized(this) {
                if (len > 0 && mySeq == acked) lastAckTime = System.currentTimeMillis()
                tcpPkt(ri, rp, di, sp, mySeq, peerNext, fl, d, off, len, mss)
                mySeq = (mySeq + len + (if ((fl and (F_SYN or F_FIN)) != 0) 1 else 0)) and M
            }
        }

        fun ackStalled(now: Long): Boolean =
            ready && !closed && ((mySeq - acked) and M) in 1..0x7FFFFFFFL && now - lastAckTime > 3000

        fun start() {
            acked = mySeq
            ready = true
            send(F_SYN or F_ACK, mss = true)
            pool.execute { writer() }
            pool.execute { reader() }
        }

        private fun writer() {
            try {
                while (true) {
                    val d = q.take()
                    if (d.isEmpty()) {
                        rout.close()
                        break
                    }
                    rout.write(d)
                    rout.flush()
                    Mon.tx.addAndGet(d.size.toLong())
                }
            } catch (e: Exception) {
                if (!closed) kill(true)
            }
        }

        private fun reader() {
            val buf = ByteArray(MSS)
            try {
                while (!closed) {
                    val n = rin.read(buf)
                    if (n < 0) break
                    var off = 0
                    while (off < n && !closed) {
                        val l = minOf(n - off, MSS)
                        val lim = maxOf(minOf(peerWin, 65535), MSS)
                        while (!closed && ((mySeq - acked) and M) + l > lim) {
                            if (ackStalled(System.currentTimeMillis())) { kill(true); return }
                            Thread.sleep(2)
                        }
                        if (closed) return
                        send(F_ACK or F_PSH, buf, off, l)
                        off += l
                    }
                }
                if (!closed) {
                    send(F_FIN or F_ACK)
                    finSent = true
                }
            } catch (e: Exception) {
                if (!closed) kill(true)
            }
        }

        fun kill(rst: Boolean) {
            if (closed) return
            closed = true
            conns.remove(key)
            if (rst && ready) {
                try {
                    tcpPkt(ri, rp, di, sp, mySeq, peerNext, F_RST or F_ACK, null, 0, 0, false)
                } catch (e: Exception) { }
            }
            q.offer(EOF)
            try { ch?.disconnect() } catch (e: Exception) { }
        }
    }
}
