package com.alfy.tunnel

import android.os.ParcelFileDescriptor
import java.io.DataInputStream
import java.io.IOException
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.Collections
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit

/**
 * Proxy transparan untuk Mode Sembunyikan VPN (Root): iptables REDIRECT mengarahkan TCP ke [tcpPort]
 * dan DNS UDP ke [dnsPort]; tujuan asli TCP dibaca via SO_ORIGINAL_DST lalu dipipa lewat SSH.
 */
class TransparentProxyServer(private val link: TunnelLink, private val dnsHost: String) {
    private val ss = ServerSocket().apply {
        reuseAddress = true
        bind(java.net.InetSocketAddress(InetAddress.getByName("127.0.0.1"), 0))
    }
    private val ds = DatagramSocket(0, InetAddress.getByName("127.0.0.1"))
    val tcpPort: Int = ss.localPort
    val dnsPort: Int = ds.localPort

    @Volatile private var running = false
    private val pool = Executors.newCachedThreadPool { r -> Thread(r).also { it.isDaemon = true } }
    private val guard: ScheduledExecutorService = Executors.newSingleThreadScheduledExecutor { r -> Thread(r).also { it.isDaemon = true } }
    private val socks = Collections.synchronizedSet(HashSet<Socket>())
    private val chans = Collections.synchronizedSet(HashSet<SshChan>())

    fun start() {
        if (running) return
        running = true
        pool.execute { acceptLoop() }
        pool.execute { dnsLoop() }
    }

    fun stop() {
        running = false
        try { ss.close() } catch (e: Throwable) { }
        try { ds.close() } catch (e: Throwable) { }
        synchronized(socks) { socks.toList() }.forEach { try { it.close() } catch (e: Throwable) { } }
        synchronized(chans) { chans.toList() }.forEach { try { it.disconnect() } catch (e: Throwable) { } }
        socks.clear()
        chans.clear()
        try { pool.shutdownNow() } catch (e: Throwable) { }
        try { guard.shutdownNow() } catch (e: Throwable) { }
    }

    private fun acceptLoop() {
        while (running) {
            val c = try { ss.accept() } catch (e: Throwable) { if (!running) break else continue }
            try { pool.execute { handle(c) } } catch (e: Throwable) { try { c.close() } catch (e2: Throwable) { } }
        }
    }

    private fun handle(c: Socket) {
        var ch: SshChan? = null
        try {
            val packed = ParcelFileDescriptor.fromSocket(c).use { OrigDst.getOriginalDst(it.fd) }
            if (packed < 0L) { c.close(); return }
            val ip = (packed ushr 16) and 0xFFFFFFFFL
            val ipStr = "${(ip shr 24) and 0xFF}.${(ip shr 16) and 0xFF}.${(ip shr 8) and 0xFF}.${ip and 0xFF}"
            val port = (packed and 0xFFFFL).toInt()
            if (port <= 0 || (ipStr == "127.0.0.1" && port == tcpPort)) { c.close(); return }
            socks.add(c)
            val chan = link.open(ipStr, port).also { it.connect(10000) }
            ch = chan
            chans.add(chan)
            c.tcpNoDelay = true
            val up = Thread {
                try {
                    val inp = c.getInputStream()
                    val out = chan.outputStream
                    val buf = ByteArray(16384)
                    while (true) {
                        val n = inp.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        out.flush()
                        Mon.tx.addAndGet(n.toLong())
                    }
                } catch (e: Throwable) {
                } finally {
                    try { c.close() } catch (e: Throwable) { }
                    try { chan.disconnect() } catch (e: Throwable) { }
                }
            }
            up.isDaemon = true
            up.start()
            try {
                val inp = chan.inputStream
                val out = c.getOutputStream()
                val buf = ByteArray(16384)
                while (true) {
                    val n = inp.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    out.flush()
                    Mon.rx.addAndGet(n.toLong())
                }
            } catch (e: Throwable) {
            } finally {
                try { c.close() } catch (e: Throwable) { }
                try { chan.disconnect() } catch (e: Throwable) { }
            }
        } catch (e: Throwable) {
        } finally {
            socks.remove(c)
            ch?.let { chans.remove(it) }
            try { c.close() } catch (e: Throwable) { }
            try { ch?.disconnect() } catch (e: Throwable) { }
        }
    }

    private fun dnsLoop() {
        while (running) {
            val pkt = DatagramPacket(ByteArray(4096), 4096)
            try { ds.receive(pkt) } catch (e: Throwable) { if (!running) break else continue }
            val q = pkt.data.copyOfRange(pkt.offset, pkt.offset + pkt.length)
            val addr = pkt.address
            val prt = pkt.port
            if (q.size < 12) continue
            try { pool.execute { dnsQuery(q, addr, prt) } } catch (e: Throwable) { }
        }
    }

    private fun dnsQuery(q: ByteArray, addr: InetAddress, prt: Int) {
        var ch: SshChan? = null
        var timer: java.util.concurrent.ScheduledFuture<*>? = null
        try {
            val chan = link.open(dnsHost, 53)
            ch = chan
            chans.add(chan)
            timer = try { guard.schedule({ try { chan.disconnect() } catch (e: Throwable) { } }, 6, TimeUnit.SECONDS) } catch (e: Throwable) { null }
            chan.connect(5000)
            val out = chan.outputStream
            out.write(byteArrayOf(((q.size shr 8) and 0xFF).toByte(), (q.size and 0xFF).toByte()))
            out.write(q)
            out.flush()
            val din = DataInputStream(chan.inputStream)
            val len = din.readUnsignedShort()
            if (len <= 0) throw IOException("DNS kosong")
            val resp = ByteArray(len)
            din.readFully(resp)
            if (running) ds.send(DatagramPacket(resp, resp.size, addr, prt))
        } catch (e: Throwable) {
        } finally {
            try { timer?.cancel(false) } catch (e: Throwable) { }
            ch?.let { chans.remove(it); try { it.disconnect() } catch (e: Throwable) { } }
        }
    }
}
