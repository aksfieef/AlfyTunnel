package com.alfy.tunnel

/** JNI mini: baca SO_ORIGINAL_DST dari socket hasil REDIRECT iptables. */
object OrigDst {
    init { System.loadLibrary("origdst") }

    /** (ipv4_host_order shl 16) or port, atau -1 bila gagal. */
    @JvmStatic
    external fun getOriginalDst(fd: Int): Long
}
