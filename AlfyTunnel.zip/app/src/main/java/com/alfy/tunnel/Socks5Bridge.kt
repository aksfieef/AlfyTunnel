package com.alfy.tunnel

import java.io.DataInputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.Collections
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit

/**
 * Server SOCKS5 lokal (127.0.0.1:port acak) untuk mesin hev-socks5-tunnel.
 * - NO AUTH, CONNECT (IPv4/Domain/IPv6) -> link.open(host, port), pipa dua arah.
 * - UDP ASSOCIATE: DNS (port 53) -> DNS-over-TCP lewat link.open(dnsHost, 53);
 *   UDP lain -> BadVPN UDPGW (link.open(link.host, Prefs.udpgwPort)) bila port UDPGW > 0, selain itu dibuang.
 */
class Socks5Bridge(private val link: TunnelLink, private val dnsHost: String) {
    private val loopback: InetAddress = InetAddress.getByName("127.0.0.1")
    private val ss = ServerSocket().apply {
        reuseAddress = true
        bind(InetSocketAddress(loopback, 0))
    }
    val port: Int = ss.localPort

    @Volatile private var running = false
    private val pool = Executors.newCachedThreadPool { r -> Thread(r).also { it.isDaemon = true } }
    private val guard: ScheduledExecutorService = Executors.newSingleThreadScheduledExecutor { r -> Thread(r).also { it.isDaemon = true } }
    private val socks = Collections.synchronizedSet(HashSet<Socket>())
    private val dgs = Collections.synchronizedSet(HashSet<DatagramSocket>())
    private val chans = Collections.synchronizedSet(HashSet<SshChan>())
    private val gw = UdpGw()

    fun start() {
        if (running) return
        running = true
        pool.execute { acceptLoop() }
    }

    fun stop() {
        running = false
        try { ss.close() } catch (e: Throwable) { }
        synchronized(socks) { socks.toList() }.forEach { try { it.close() } catch (e: Throwable) { } }
        synchronized(dgs) { dgs.toList() }.forEach { try { it.close() } catch (e: Throwable) { } }
        synchronized(chans) { chans.toList() }.forEach { try { it.disconnect() } catch (e: Throwable) { } }
        socks.clear()
        dgs.clear()
        chans.clear()
        try { gw.close() } catch (e: Throwable) { }
        try { pool.shutdownNow() } catch (e: Throwable) { }
        try { guard.shutdownNow() } catch (e: Throwable) { }
    }

    private fun acceptLoop() {
        while (running) {
            val c = try { ss.accept() } catch (e: Throwable) { if (!running) break else continue }
            try { pool.execute { handle(c) } } catch (e: Throwable) { try { c.close() } catch (e2: Throwable) { } }
        }
    }

    private fun reply(o: OutputStream, code: Int, addr: ByteArray = byteArrayOf(0, 0, 0, 0), port: Int = 0) {
        o.write(byteArrayOf(5, code.toByte(), 0, 1, addr[0], addr[1], addr[2], addr[3], (port shr 8).toByte(), port.toByte()))
        o.flush()
    }

    private fun handle(c: Socket) {
        var chan: SshChan? = null
        socks.add(c)
        try {
            c.tcpNoDelay = true
            c.soTimeout = 15000
            val inp = DataInputStream(c.getInputStream())
            val out = c.getOutputStream()
            if (inp.readUnsignedByte() != 5) return
            val nm = inp.readUnsignedByte()
            val ms = ByteArray(nm)
            inp.readFully(ms)
            if (ms.none { it.toInt() == 0 }) { out.write(byteArrayOf(5, -1)); out.flush(); return }
            out.write(byteArrayOf(5, 0)); out.flush()
            if (inp.readUnsignedByte() != 5) return
            val cmd = inp.readUnsignedByte()
            inp.readUnsignedByte() // RSV
            val atyp = inp.readUnsignedByte()
            val host: String = when (atyp) {
                1 -> { val a = ByteArray(4); inp.readFully(a); a.joinToString(".") { (it.toInt() and 255).toString() } }
                3 -> { val l = inp.readUnsignedByte(); val a = ByteArray(l); inp.readFully(a); String(a, Charsets.ISO_8859_1) }
                4 -> { val a = ByteArray(16); inp.readFully(a); InetAddress.getByAddress(a).hostAddress ?: return }
                else -> { reply(out, 8); return }
            }
            val dport = inp.readUnsignedShort()
            when (cmd) {
                1 -> {
                    val ch = link.open(host, dport)
                    chan = ch
                    chans.add(ch)
                    try { ch.connect(10000) } catch (e: Throwable) { reply(out, 5); return }
                    reply(out, 0)
                    c.soTimeout = 0
                    val up = Thread {
                        try {
                            val i = c.getInputStream()
                            val o = ch.outputStream
                            val buf = ByteArray(16384)
                            while (true) {
                                val n = i.read(buf)
                                if (n < 0) break
                                o.write(buf, 0, n)
                                o.flush()
                                Mon.tx.addAndGet(n.toLong())
                            }
                        } catch (e: Throwable) {
                        } finally {
                            try { c.close() } catch (e: Throwable) { }
                            try { ch.disconnect() } catch (e: Throwable) { }
                        }
                    }
                    up.isDaemon = true
                    up.start()
                    try {
                        val i = ch.inputStream
                        val o = c.getOutputStream()
                        val buf = ByteArray(16384)
                        while (true) {
                            val n = i.read(buf)
                            if (n < 0) break
                            o.write(buf, 0, n)
                            o.flush()
                            Mon.rx.addAndGet(n.toLong())
                        }
                    } catch (e: Throwable) {
                    }
                }
                3 -> {
                    val ds = DatagramSocket(0, loopback)
                    dgs.add(ds)
                    try {
                        reply(out, 0, loopback.address, ds.localPort)
                        c.soTimeout = 0
                        pool.execute { udpLoop(ds) }
                        // Asosiasi UDP hidup selama koneksi TCP kontrol terbuka.
                        try { while (inp.read() >= 0) { } } catch (e: Throwable) { }
                    } finally {
                        try { ds.close() } catch (e: Throwable) { }
                        dgs.remove(ds)
                        gw.forget(ds)
                    }
                }
                else -> reply(out, 7)
            }
        } catch (e: Throwable) {
        } finally {
            socks.remove(c)
            chan?.let { chans.remove(it) }
            try { c.close() } catch (e: Throwable) { }
            try { chan?.disconnect() } catch (e: Throwable) { }
        }
    }

    // ---------------------------------------------------------------- UDP

    private fun udpLoop(ds: DatagramSocket) {
        while (running && !ds.isClosed) {
            val pkt = DatagramPacket(ByteArray(65535), 65535)
            try { ds.receive(pkt) } catch (e: Throwable) { if (!running || ds.isClosed) break else continue }
            try { onUdp(ds, pkt) } catch (e: Throwable) { }
        }
    }

    /** Header UDP SOCKS5: RSV(2) FRAG(1) ATYP(1) DST.ADDR DST.PORT DATA */
    private fun onUdp(ds: DatagramSocket, pkt: DatagramPacket) {
        val d = pkt.data
        val n = pkt.length
        if (n < 10 || d[2].toInt() != 0) return
        val atyp = d[3].toInt() and 255
        val pe = when (atyp) {
            1 -> 8
            3 -> 5 + (d[4].toInt() and 255)
            4 -> 20
            else -> return
        }
        if (pe + 2 > n) return
        val dp = ((d[pe].toInt() and 255) shl 8) or (d[pe + 1].toInt() and 255)
        val off = pe + 2
        val hdr = d.copyOfRange(0, off)
        val data = d.copyOfRange(off, n)
        val ca = pkt.address
        val cp = pkt.port
        if (data.isEmpty()) return
        if (dp == 53) {
            pool.execute {
                try {
                    val r = dnsQuery(data) ?: return@execute
                    val o = hdr + r
                    if (running && !ds.isClosed) ds.send(DatagramPacket(o, o.size, ca, cp))
                } catch (e: Throwable) { }
            }
            return
        }
        // UDP lain: hanya lewat UDPGW (BadVPN, IPv4) bila port UDPGW aktif; selain itu dibuang.
        if (Prefs.udpgwPort.value <= 0 || atyp != 1 || data.size > 65000) return
        val ip = d.copyOfRange(4, 8)
        pool.execute { try { gw.send(ds, ca, cp, ip, dp, data) } catch (e: Throwable) { } }
    }

    /** DNS-over-TCP lewat tunnel SSH ke [dnsHost]:53. */
    private fun dnsQuery(q: ByteArray): ByteArray? {
        var ch: SshChan? = null
        var timer: java.util.concurrent.ScheduledFuture<*>? = null
        try {
            val chan = link.open(dnsHost, 53)
            ch = chan
            chans.add(chan)
            timer = try { guard.schedule({ try { chan.disconnect() } catch (e: Throwable) { } }, 6, TimeUnit.SECONDS) } catch (e: Throwable) { null }
            chan.connect(5000)
            val o = chan.outputStream
            o.write(byteArrayOf(((q.size shr 8) and 0xFF).toByte(), (q.size and 0xFF).toByte()))
            o.write(q)
            o.flush()
            Mon.tx.addAndGet(q.size.toLong())
            val din = DataInputStream(chan.inputStream)
            val len = din.readUnsignedShort()
            if (len <= 0) throw IOException("DNS kosong")
            val resp = ByteArray(len)
            din.readFully(resp)
            Mon.rx.addAndGet(len.toLong())
            return resp
        } catch (e: Throwable) {
            return null
        } finally {
            try { timer?.cancel(false) } catch (e: Throwable) { }
            try { ch?.disconnect() } catch (e: Throwable) { }
            ch?.let { chans.remove(it) }
        }
    }

    /**
     * Klien UDPGW BadVPN (sama seperti UdpGw di TunStack.kt): satu koneksi TCP ke host SSH aktif:port UDPGW,
     * dipakai bersama semua alur UDP (dibedakan conid).
     * Frame: [len LE u16][flags u8][conid LE u16][IPv4 4B][port BE u16][payload]; len = 9 + payload.
     */
    private inner class UdpGw {
        private inner class Flow(val id: Int, val ds: DatagramSocket, val ca: InetAddress, val cp: Int, val ip: ByteArray, val dp: Int) {
            @Volatile var last = System.currentTimeMillis()
            val key = "${ds.localPort}|${ca.hostAddress}:$cp>${ip.joinToString(".") { (it.toInt() and 255).toString() }}:$dp"
        }

        private val lock = Any()
        private var ch: SshChan? = null
        private var out: OutputStream? = null
        private var gen = 0
        private var nextId = 0
        private val flows = HashMap<Int, Flow>()
        private val ids = HashMap<String, Int>()

        fun send(ds: DatagramSocket, ca: InetAddress, cp: Int, ip: ByteArray, dp: Int, d: ByteArray) {
            synchronized(lock) {
                if (!running) return
                val now = System.currentTimeMillis()
                if (flows.size > 64) {
                    val it = flows.values.iterator()
                    while (it.hasNext()) {
                        val f = it.next()
                        if (now - f.last > 120000) { it.remove(); ids.remove(f.key) }
                    }
                }
                val probe = Flow(0, ds, ca, cp, ip, dp)
                val key = probe.key
                var f = ids[key]?.let { flows[it] }
                if (f == null) {
                    if (flows.size >= 512) {
                        flows.values.minByOrNull { it.last }?.let { old -> flows.remove(old.id); ids.remove(old.key) }
                    }
                    do { nextId = (nextId % 65535) + 1 } while (flows.containsKey(nextId))
                    f = Flow(nextId, ds, ca, cp, ip, dp)
                    flows[f.id] = f
                    ids[key] = f.id
                }
                f.last = now
                val o = ensure()
                val fr = ByteArray(11 + d.size)
                val len = 9 + d.size
                fr[0] = len.toByte(); fr[1] = (len shr 8).toByte()
                fr[2] = 0
                fr[3] = f.id.toByte(); fr[4] = (f.id shr 8).toByte()
                System.arraycopy(ip, 0, fr, 5, 4)
                fr[9] = (dp shr 8).toByte(); fr[10] = dp.toByte()
                System.arraycopy(d, 0, fr, 11, d.size)
                try {
                    o.write(fr)
                    o.flush()
                    Mon.tx.addAndGet(d.size.toLong())
                } catch (e: Exception) {
                    drop()
                }
            }
        }

        private fun ensure(): OutputStream {
            out?.let { return it }
            val c = link.open(link.host, Prefs.udpgwPort.value)
            c.connect(10000)
            ch = c
            out = c.outputStream
            val g = ++gen
            val ins = c.inputStream
            pool.execute { readLoop(g, ins) }
            return out!!
        }

        private fun drop() {
            synchronized(lock) {
                try { ch?.disconnect() } catch (e: Exception) { }
                ch = null
                out = null
                gen++
            }
        }

        private fun readLoop(g: Int, i: InputStream) {
            try {
                val d = DataInputStream(i)
                while (running && g == gen) {
                    val len = d.readUnsignedByte() or (d.readUnsignedByte() shl 8)
                    val b = ByteArray(len)
                    d.readFully(b)
                    if (len < 3) continue
                    val fl = b[0].toInt() and 255
                    if ((fl and 1) != 0) continue // keepalive
                    val id = (b[1].toInt() and 255) or ((b[2].toInt() and 255) shl 8)
                    val ao = 3 + (if ((fl and 8) != 0) 18 else 6)
                    if (ao > len) continue
                    val f = synchronized(lock) { flows[id] } ?: continue
                    f.last = System.currentTimeMillis()
                    val payload = b.copyOfRange(ao, len)
                    // Header UDP SOCKS5 balasan: RSV(2) FRAG ATYP=1 ADDR(4) PORT(2)
                    val o = ByteArray(10 + payload.size)
                    o[3] = 1
                    System.arraycopy(f.ip, 0, o, 4, 4)
                    o[8] = (f.dp shr 8).toByte(); o[9] = f.dp.toByte()
                    System.arraycopy(payload, 0, o, 10, payload.size)
                    try {
                        if (!f.ds.isClosed) f.ds.send(DatagramPacket(o, o.size, f.ca, f.cp))
                        Mon.rx.addAndGet(payload.size.toLong())
                    } catch (e: Throwable) { }
                }
            } catch (e: Exception) { }
            synchronized(lock) { if (g == gen) drop() }
        }

        /** Hapus semua alur milik satu asosiasi UDP yang sudah ditutup. */
        fun forget(ds: DatagramSocket) {
            synchronized(lock) {
                val it = flows.values.iterator()
                while (it.hasNext()) {
                    val f = it.next()
                    if (f.ds === ds) { it.remove(); ids.remove(f.key) }
                }
            }
        }

        fun close() {
            synchronized(lock) {
                try { ch?.disconnect() } catch (e: Exception) { }
                ch = null
                out = null
                gen++
                flows.clear()
                ids.clear()
            }
        }
    }
}
