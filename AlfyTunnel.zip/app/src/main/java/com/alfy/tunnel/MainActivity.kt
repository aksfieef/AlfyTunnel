package com.alfy.tunnel

import android.Manifest
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.runtime.key
import androidx.compose.ui.zIndex
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalViewConfiguration
import androidx.compose.ui.platform.ViewConfiguration
import androidx.compose.runtime.CompositionLocalProvider
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CardDefaults
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.DrawerDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.material3.LocalContentColor
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.animation.core.animateFloat
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        lifecycle.addObserver(androidx.lifecycle.LifecycleEventObserver { _, e ->
            if (e == androidx.lifecycle.Lifecycle.Event.ON_START) AppFg.fg.value = true
            else if (e == androidx.lifecycle.Lifecycle.Event.ON_STOP) AppFg.fg.value = false
        })
        setContent {
            AlfyTheme {
                androidx.compose.foundation.layout.Box {
                    App()
                }
            }
        }
        PermAsk.start(this)
    }

    override fun onDestroy() {
        super.onDestroy()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        PermAsk.next(this)
    }

    override fun onResume() {
        super.onResume()
        Prefs.resume.value = Prefs.resume.value + 1
        PermAsk.next(this)
        Hud.resumed = true
        val h = Hud.actHud ?: Hud(applicationContext).also { Hud.actHud = it }
        if (!Hud.svcOn) h.start()
        AppNotif.active = true
        AppNotif.reset()
        AppNotif.refresh(applicationContext)
    }

    override fun onPause() {
        Hud.resumed = false
        if (!Hud.svcOn) Hud.actHud?.stop()
        AppNotif.cancel(applicationContext)
        super.onPause()
    }
}

@Composable
fun AlfyTheme(content: @Composable () -> Unit) {
    val tr by Prefs.transparent.collectAsState()
    val card = if (tr) Color.Transparent else Color(0xFF1B1F27)
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFF4DD0C4),
            onPrimary = Color(0xFF00201D),
            secondaryContainer = Color(0xFF1F3B38),
            background = Color(0xFF0F1115),
            surface = Color(0xFF0F1115),
            surfaceVariant = card,
            surfaceContainerHighest = card,
            surfaceContainerHigh = card,
            surfaceContainer = card,
            surfaceContainerLow = card,
            error = Color(0xFFE57373),
            onError = Color(0xFF1A0000)
        ),
        content = content
    )
}

fun startVpn(ctx: Context, c: Config) {
    Bus.status.value = St.CONNECTING
    ContextCompat.startForegroundService(
        ctx,
        Intent(ctx, VpnSvc::class.java).setAction(VpnSvc.ACT_START).putExtra(VpnSvc.EXTRA, c.toJson().toString())
    )
}

@Composable
fun Field(
    v: String, label: String, enabled: Boolean = true, lines: Int = 1, mono: Boolean = false,
    onChange: (String) -> Unit
) {
    OutlinedTextField(
        value = v,
        onValueChange = onChange,
        label = { Text(label) },
        enabled = enabled,
        singleLine = lines == 1,
        minLines = lines,
        textStyle = if (mono) LocalTextStyle.current.copy(fontFamily = FontFamily.Monospace) else LocalTextStyle.current,
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
fun ModeRow(text: String, selected: Boolean, enabled: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().height(30.dp).clickable(enabled = enabled, onClick = onClick),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(
            selected = selected, onClick = onClick, enabled = enabled,
            modifier = Modifier.scale(0.75f).size(30.dp)
        )
        Text(text, fontSize = 13.sp)
    }
}

@Composable
fun CLabel(t: String) {
    Text(t, Modifier.padding(top = 6.dp, bottom = 2.dp), fontSize = 11.sp, color = Color.Gray)
}

@Composable
fun CField(
    v: String, label: String, enabled: Boolean = true, mono: Boolean = false,
    onChange: (String) -> Unit
) {
    Column(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Text(label, fontSize = 11.sp, color = Color.Gray)
        BasicTextField(
            value = v,
            onValueChange = onChange,
            enabled = enabled,
            textStyle = TextStyle(
                fontSize = 13.sp,
                color = if (enabled) MaterialTheme.colorScheme.onSurface else Color.Gray,
                fontFamily = if (mono) FontFamily.Monospace else FontFamily.Default
            ),
            cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
            modifier = Modifier.fillMaxWidth().padding(top = 2.dp)
        )
    }
}

@Composable
fun Section(content: @Composable ColumnScope.() -> Unit) {
    Card(
        Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp), content = content)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App(vm: MainVM = viewModel()) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val clip = LocalClipboardManager.current
    val drawer = rememberDrawerState(DrawerValue.Closed)
    val cfgs by vm.configs.collectAsState()
    val cur by vm.cur.collectAsState()
    val st by Bus.status.collectAsState()
    val logs by Bus.logs.collectAsState()
    val snack = remember { SnackbarHostState() }
    var menu by remember { mutableStateOf(false) }
    var renameId by remember { mutableStateOf<String?>(null) }
    var delId by remember { mutableStateOf<String?>(null) }
    var dupId by remember { mutableStateOf<String?>(null) }
    var showUdpgw by remember { mutableStateOf(false) }
    val udpgw by Prefs.udpgwPort.collectAsState()
    var showPaste by remember { mutableStateOf(false) }
    var showHotspot by remember { mutableStateOf(false) }
    var pasteText by remember { mutableStateOf("") }
    var pending by remember { mutableStateOf<List<Config>?>(null) }
    val locked = st != St.IDLE
    var screen by rememberSaveable { mutableStateOf(0) }
    val bgVer by Prefs.bgVer.collectAsState()
    val bgImg = remember(bgVer) {
        try { BitmapFactory.decodeFile(Img.bgFile(ctx).path)?.asImageBitmap() } catch (e: Throwable) { null }
    }

    fun toast(m: String) {
        scope.launch { snack.showSnackbar(m) }
    }

    fun doImport(t: String) {
        vm.parseBackup(t).onSuccess { l ->
            if (vm.conflicts(l) > 0) {
                pending = l
            } else {
                vm.importConfigs(l, false)
                toast("${l.size} config dipulihkan")
            }
        }.onFailure { toast("Format tidak valid: ${it.message}") }
    }

    val vpnPerm = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == Activity.RESULT_OK) startVpn(ctx, vm.cur.value) else toast("Izin VPN ditolak")
    }
    val saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        if (uri != null) scope.launch {
            runCatching {
                val text = vm.backupText()
                withContext(Dispatchers.IO) {
                    ctx.contentResolver.openOutputStream(uri, "wt")!!.use { it.write(text.toByteArray(Charsets.UTF_8)) }
                }
            }.onSuccess { toast("Backup tersimpan") }.onFailure { toast("Gagal menyimpan: ${it.message}") }
        }
    }
    val bgPick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) scope.launch {
            val ok = withContext(Dispatchers.IO) { runCatching { Img.saveBg(ctx, uri) }.getOrDefault(false) }
            toast(if (ok) "Latar diganti" else "Gambar tidak bisa dibaca")
        }
    }
    val opener = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            runCatching {
                withContext(Dispatchers.IO) {
                    String(ctx.contentResolver.openInputStream(uri)!!.use { it.readBytes() }, Charsets.UTF_8)
                }
            }.onSuccess { doImport(it) }.onFailure { toast("Gagal membaca berkas: ${it.message}") }
        }
    }

    Box(Modifier.fillMaxSize()) {
    if (bgImg != null) {
        Image(bgImg, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        if (!Prefs.transparent.collectAsState().value) Box(Modifier.fillMaxSize().background(Color(0x99000000)))
    }
    CompositionLocalProvider(LocalContentColor provides MaterialTheme.colorScheme.onSurface) {
    if (showHotspot) HotspotDialog(onDismiss = { showHotspot = false }, toast = { toast(it) })
    if (screen == 1) {
        SettingsScreen(onBack = { screen = 0 }, toast = { toast(it) }, vm = vm, locked = locked)
    } else
    ModalNavigationDrawer(
        drawerState = drawer,
        scrimColor = if (Prefs.transparent.collectAsState().value) Color.Transparent else DrawerDefaults.scrimColor,
        drawerContent = {
            val trD = Prefs.transparent.collectAsState().value
            ModalDrawerSheet(
                drawerContainerColor = if (trD) Color.Transparent else Color(0xFF0F1115),
                drawerTonalElevation = if (trD) 0.dp else 1.dp
            ) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Config", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                    FilledTonalButton(onClick = { vm.add() }, enabled = !locked) {
                        Icon(Icons.Default.Add, null)
                        Spacer(Modifier.width(4.dp))
                        Text("Tambah")
                    }
                }
                RbDivider()
                var localList by remember(cfgs) { mutableStateOf(cfgs) }
                val lockedNow by rememberUpdatedState(locked)
                val scrollSt = androidx.compose.foundation.rememberScrollState()
                val topTick by vm.topTick.collectAsState()
                LaunchedEffect(topTick) { if (topTick > 0) scrollSt.scrollTo(0) }
                // ---- Geser urutan (cara umum): tekan lama -> item mengikuti jari, item lain bergeser,
                //      urutan baru disimpan sekali saat jari dilepas. Daftar TIDAK diubah selama menggeser,
                //      jadi tidak ada loncat / bentrok layout.
                var dragId by remember { mutableStateOf<String?>(null) }
                var dragOff by remember { mutableStateOf(0f) }
                var dropIdx by remember { mutableStateOf(-1) }
                val tops = remember { HashMap<String, Float>() }   // posisi atas item (root) tanpa translasi
                val sizes = remember { HashMap<String, Float>() }
                val topScr = remember { HashMap<String, Int>() }   // nilai scroll saat 'tops' dicatat
                var boxTop by remember { mutableStateOf(0f) }
                var boxH by remember { mutableStateOf(0f) }
                var startTop by remember { mutableStateOf(0f) }
                var startScroll by remember { mutableStateOf(0) }
                val dragging = dragId != null
                val density = androidx.compose.ui.platform.LocalDensity.current
                val gapPx = with(density) { 12.dp.toPx() }
                val haptic = androidx.compose.ui.platform.LocalHapticFeedback.current

                fun updateDrop() {
                    val id = dragId ?: return
                    val sz = sizes[id] ?: return
                    val center = startTop + dragOff + sz / 2f
                    // Indeks tujuan = jumlah item lain yang titik tengahnya di atas pusat kartu yang diseret.
                    // Tidak ada "celah mati" & tidak bisa melompat; posisi item dikompensasi terhadap scroll terkini.
                    var pos = 0
                    for (k in localList) {
                        if (k.id == id) continue
                        val tp = tops[k.id] ?: continue
                        val eff = tp - (scrollSt.value - (topScr[k.id] ?: scrollSt.value))
                        if (eff + (sizes[k.id] ?: 0f) / 2f < center) pos++
                    }
                    dropIdx = pos
                }

                // Auto-scroll di tepi atas/bawah saat item diseret
                LaunchedEffect(dragId) {
                    val id = dragId ?: return@LaunchedEffect
                    while (dragId == id) {
                        val sz = sizes[id] ?: 0f
                        val vTop = startTop + dragOff
                        val edge = 90f
                        val dy = when {
                            vTop < boxTop + edge -> -14f
                            vTop + sz > boxTop + boxH - edge -> 14f
                            else -> 0f
                        }
                        if (dy != 0f) scrollSt.scrollBy(dy)
                        updateDrop()
                        androidx.compose.runtime.withFrameNanos { }
                    }
                }

                val baseVc = LocalViewConfiguration.current
                val slowVc = remember(baseVc) {
                    object : ViewConfiguration by baseVc {
                        override val longPressTimeoutMillis: Long = 500L
                    }
                }
                val appFg by AppFg.fg.collectAsState()
                val rbOff = if (appFg) {
                    val rbT = androidx.compose.animation.core.rememberInfiniteTransition(label = "rb")
                    rbT.animateFloat(
                        initialValue = 0f, targetValue = 900f,
                        animationSpec = androidx.compose.animation.core.infiniteRepeatable(
                            androidx.compose.animation.core.tween(2500, easing = androidx.compose.animation.core.LinearEasing)
                        ), label = "rbo"
                    ).value
                } else 0f
                val rbBrush = androidx.compose.ui.graphics.Brush.linearGradient(
                    colors = listOf(Color(0xFFFF1744), Color(0xFFFF9100), Color(0xFFFFEA00), Color(0xFF00E676),
                        Color(0xFF00B0FF), Color(0xFF651FFF), Color(0xFFD500F9), Color(0xFFFF1744)),
                    start = androidx.compose.ui.geometry.Offset(rbOff, rbOff),
                    end = androidx.compose.ui.geometry.Offset(rbOff + 900f, rbOff + 300f),
                    tileMode = androidx.compose.ui.graphics.TileMode.Repeated
                )
                CompositionLocalProvider(LocalViewConfiguration provides slowVc) {
                Box(
                    Modifier.fillMaxSize()
                        .trackBox { boxTop = it.first; boxH = it.second }
                        .then(Modifier.pointerInput(cfgs) {
                            // Gesture sendiri di pass INITIAL: tekan tahan 0,5 dtk -> item "terkunci" ke jari.
                            // Semua event setelahnya dikonsumsi lebih dulu sehingga scroll/klik anak tidak
                            // bisa mencuri gesture (penyebab geser urutan kadang tidak mau jalan).
                            while (true) { awaitPointerEventScope {
                                val down = awaitFirstDown(requireUnconsumed = false, pass = androidx.compose.ui.input.pointer.PointerEventPass.Initial)
                                val slop = viewConfiguration.touchSlop
                                var cancelled = false
                                withTimeoutOrNull(500L) {
                                    while (true) {
                                        val ev = awaitPointerEvent(androidx.compose.ui.input.pointer.PointerEventPass.Initial)
                                        val c = ev.changes.firstOrNull { it.id == down.id }
                                        if (c == null || !c.pressed || (c.position - down.position).getDistance() > slop) {
                                            cancelled = true
                                            break
                                        }
                                    }
                                }
                                if (cancelled) return@awaitPointerEventScope
                                val y0 = boxTop + down.position.y
                                val hit = localList.firstOrNull { k ->
                                    val tp = tops[k.id]; val sz = sizes[k.id]
                                    tp != null && sz != null && y0 >= tp && y0 <= tp + sz
                                } ?: return@awaitPointerEventScope
                                startTop = tops[hit.id] ?: 0f
                                startScroll = scrollSt.value
                                dragOff = 0f
                                dropIdx = localList.indexOfFirst { it.id == hit.id }
                                dragId = hit.id
                                haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.LongPress)
                                var ended = false
                                while (!ended) {
                                    val ev = awaitPointerEvent(androidx.compose.ui.input.pointer.PointerEventPass.Initial)
                                    val c = ev.changes.firstOrNull { it.id == down.id }
                                    if (c == null || !c.pressed) {
                                        ev.changes.forEach { it.consume() }
                                        ended = true
                                    } else {
                                        val dy = c.position.y - c.previousPosition.y
                                        if (dy != 0f) {
                                            dragOff += dy
                                            updateDrop()
                                        }
                                        ev.changes.forEach { it.consume() }
                                    }
                                }
                                val id = dragId
                                val from = localList.indexOfFirst { it.id == id }
                                val to = dropIdx
                                dragId = null; dragOff = 0f; dropIdx = -1
                                if (id != null && from >= 0 && to >= 0 && from != to) {
                                    val nl = localList.toMutableList()
                                    nl.add(to, nl.removeAt(from))
                                    localList = nl
                                    vm.reorder(nl.map { it.id })
                                }
                            } }
                        })
                ) {
                    Column(
                        Modifier.fillMaxSize()
                            .verticalScroll(scrollSt, enabled = !dragging)
                            .padding(vertical = 14.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                    localList.forEachIndexed { index, c ->
                        key(c.id) {
                        var rowMenu by remember { mutableStateOf(false) }
                        val isDrag = dragId == c.id
                        val dIdx = if (dragId == null) -1 else localList.indexOfFirst { it.id == dragId }
                        val dSize = (dragId?.let { sizes[it] } ?: 0f) + gapPx
                        val shiftTarget = when {
                            dragId == null || isDrag || dropIdx < 0 -> 0f
                            dIdx < dropIdx && index in (dIdx + 1)..dropIdx -> -dSize
                            dIdx > dropIdx && index in dropIdx until dIdx -> dSize
                            else -> 0f
                        }
                        val shiftAnim by androidx.compose.animation.core.animateFloatAsState(shiftTarget, label = "shift")
                        val shift = if (dragId == null) 0f else shiftAnim
                        Card(
                            Modifier.fillMaxWidth().padding(horizontal = 12.dp)
                                .trackItem { top, h -> tops[c.id] = top; topScr[c.id] = scrollSt.value; sizes[c.id] = h }
                                .graphicsLayer {
                                    translationY = if (isDrag) dragOff + (scrollSt.value - startScroll) else shift
                                    if (isDrag) { scaleX = 1.02f; scaleY = 1.02f; shadowElevation = 16f }
                                }
                                .zIndex(if (isDrag) 1f else 0f),
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surfaceVariant
                            ),
                            border = if (c.id == cur.id) androidx.compose.foundation.BorderStroke(2.5.dp, rbBrush) else null
                        ) {
                        Row(
                            Modifier.fillMaxWidth()
                                .clickable(enabled = !locked) {
                                    vm.select(c.id)
                                    scope.launch { drawer.close() }
                                }
                                .padding(start = 16.dp, end = 4.dp, top = 8.dp, bottom = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(
                                    c.name, maxLines = 1, overflow = TextOverflow.Ellipsis,
                                    fontWeight = FontWeight.Bold, fontSize = 16.sp
                                )
                                val sub = c.customTag.trim()
                                val typ = when (c.mode) { 0 -> "SSH WS"; 1 -> "SSH SSL/TLS"; else -> "SSH Enhanced" }
                                if (sub.isNotEmpty()) {
                                    Text(sub, fontSize = 12.sp, color = Color(0xFFFFD54F), maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                                Text(typ, fontSize = 11.sp, color = Color.Gray, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            IconButton(onClick = { vm.togglePin(c.id) }) {
                                Icon(
                                    Icons.Default.ThumbUp, if (c.isPinned) "Lepas pin" else "Pin",
                                    tint = if (c.isPinned) MaterialTheme.colorScheme.primary
                                    else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f)
                                )
                            }
                            Box {
                                IconButton(onClick = { rowMenu = true }) { Icon(Icons.Default.MoreVert, "Opsi") }
                                DropdownMenu(expanded = rowMenu, onDismissRequest = { rowMenu = false }) {
                                    DropdownMenuItem(text = { Text("Duplicate") }, onClick = {
                                        rowMenu = false
                                        dupId = c.id
                                    })
                                    DropdownMenuItem(text = { Text("Rename / Tag") }, onClick = {
                                        rowMenu = false
                                        renameId = c.id
                                    })
                                    DropdownMenuItem(text = { Text("Delete") }, enabled = !locked, onClick = {
                                        rowMenu = false
                                        delId = c.id
                                    })
                                }
                            }
                        }
                        }
                        }
                    }
                    }
                }
                }
            }
        }
    ) {
        Scaffold(
            containerColor = Color.Transparent,
            snackbarHost = { SnackbarHost(snack) },
            topBar = {
                TopAppBar(
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
                    title = { Text("AlfyTunnel") },
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawer.open() } }) { Icon(Icons.Default.Menu, "Config") }
                    },
                    actions = {
                        IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, "Menu") }
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                            DropdownMenuItem(text = { Text("Pengaturan & izin") }, onClick = {
                                menu = false
                                screen = 1
                            })
                            DropdownMenuItem(text = { Text("Bagikan Koneksi (Hotspot VPN)") }, onClick = {
                                menu = false
                                showHotspot = true
                            })
                            val autoRc by Prefs.alwaysReconnect.collectAsState()
                            DropdownMenuItem(
                                text = { Text("Auto Reconnect (Background)") },
                                trailingIcon = { Switch(checked = autoRc, onCheckedChange = { Prefs.setAlwaysReconnect(it) }) },
                                onClick = { Prefs.setAlwaysReconnect(!autoRc) }
                            )
                            DropdownMenuItem(text = { Text("Latar dari galeri") }, onClick = {
                                menu = false
                                bgPick.launch("image/*")
                            })
                            DropdownMenuItem(text = { Text("Hapus latar") }, onClick = {
                                menu = false
                                Img.clearBg(ctx)
                                toast("Latar dihapus")
                            })
                            DropdownMenuItem(text = { Text("Backup ke File (.alfytunnel.backup)") }, onClick = {
                                menu = false
                                saver.launch("${java.text.SimpleDateFormat("dd.MM.yyyy", java.util.Locale.getDefault()).format(java.util.Date())}.alfytunnel.backup")
                            })
                            DropdownMenuItem(text = { Text("Restore dari File") }, onClick = {
                                menu = false
                                opener.launch(arrayOf("*/*"))
                            })
                        }
                    }
                )
            }
        ) { pad ->
            val ls = rememberLazyListState()
            val logLs = rememberLazyListState()
            LaunchedEffect(logs.size, logs.lastOrNull()) {
                // Selalu ikuti log terbaru (list dibatasi 150 baris, jadi size tetap; pantau juga baris terakhir)
                val total = logs.size
                if (total > 0 && !logLs.isScrollInProgress) {
                    logLs.scrollToItem(total - 1)
                    logLs.scrollBy(100000f)
                }
            }
            LazyColumn(
                state = ls,
                modifier = Modifier.padding(pad).fillMaxSize().padding(horizontal = 12.dp, vertical = 4.dp)
            ) {
              item {
              Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(0.dp)) {
                // ===== 1. MODE =====
                RbDivider()
                CLabel("Mode")
                ModeRow("SSH WebSocket (80)", cur.mode == 0, !locked) { vm.edit { it.copy(mode = 0) } }
                ModeRow("SSH SSL/TLS (443)", cur.mode == 1, !locked) { vm.edit { it.copy(mode = 1) } }
                ModeRow("SSH Enhanced", cur.mode == 2, !locked) { vm.edit { it.copy(mode = 2) } }
                RbDivider()

                // ===== 2. SERVER & CONFIG =====
                CField(cur.server, "Server (host:port@user:pass)", !locked, true) { v -> vm.edit { it.copy(server = v) } }
                RbDivider()
                CField(cur.proxy, "Proxy (host:port, boleh kosong)", !locked, true) { v -> vm.edit { it.copy(proxy = v) } }
                RbDivider()
                CField(cur.sni, "SNI / TLS (mode SSL/TLS)", !locked && cur.mode == 1) { v -> vm.edit { it.copy(sni = v) } }
                RbDivider()
                CField(cur.payload, "Payload", !locked, true) { v -> vm.edit { it.copy(payload = v) } }
                RbDivider()
                HostName(host = Srv.parse(cur.server)?.host ?: "-")
                RbDivider()

                // ===== 3. STATUS & TOMBOL KONEK =====
                Text(
                    when (st) {
                        St.IDLE -> "Terputus"
                        St.CONNECTING, St.RECONNECTING -> "Menyambung"
                        St.CONNECTED -> "Terhubung"
                    },
                    Modifier.padding(top = 6.dp, bottom = 4.dp), fontSize = 13.sp, fontWeight = FontWeight.Medium
                )
                Button(
                    onClick = {
                        if (st == St.IDLE) {
                            val e = vm.validate(cur)
                            if (e != null) {
                                toast(e)
                            } else {
                                if (Prefs.stealthRoot.value) {
                                    startVpn(ctx, cur)
                                } else {
                                    val i = VpnService.prepare(ctx)
                                    if (i != null) vpnPerm.launch(i) else startVpn(ctx, cur)
                                }
                            }
                        } else {
                            ctx.startService(Intent(ctx, VpnSvc::class.java).setAction(VpnSvc.ACT_STOP))
                        }
                    },
                    shape = RoundedCornerShape(8.dp),
                    colors = if (st == St.IDLE) ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF00E676), contentColor = Color.Black
                    ) else ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFFF1744), contentColor = Color.White
                    ),
                    modifier = Modifier.fillMaxWidth().height(44.dp)
                ) { Text(if (st == St.IDLE) "KONEK" else "PUTUS", fontSize = 14.sp, fontWeight = FontWeight.Bold) }
                Spacer(Modifier.height(6.dp))
                RbDivider()

                // ===== 5. PENGATURAN TAMBAHAN =====
                var pilotMenu by remember { mutableStateOf(false) }
                val pilotOpts = listOf(
                    "AUTO" to "Auto",
                    "OPENSSH" to "OpenSSH",
                    "DROPBEAR" to "Dropbear"
                )
                val pilotKey = pilotOpts.firstOrNull { it.first.equals(cur.pilotType, ignoreCase = true) }?.first ?: "AUTO"
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = { showUdpgw = true },
                        modifier = Modifier.weight(1f).height(34.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                    ) {
                        Text(if (udpgw == 0) "UDPGW: Download" else "UDPGW: $udpgw", fontSize = 12.sp, maxLines = 1)
                    }
                    Box(Modifier.weight(1f)) {
                        OutlinedButton(
                            onClick = { pilotMenu = true },
                            enabled = !locked,
                            modifier = Modifier.fillMaxWidth().height(34.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                        ) {
                            Text("Pilot: " + pilotOpts.first { it.first == pilotKey }.second, Modifier.weight(1f), fontSize = 12.sp, maxLines = 1)
                            Text("▾", fontSize = 12.sp)
                        }
                        DropdownMenu(expanded = pilotMenu, onDismissRequest = { pilotMenu = false }) {
                            pilotOpts.forEach { (k, label) ->
                                DropdownMenuItem(text = { Text(label, fontSize = 13.sp) }, onClick = {
                                    pilotMenu = false
                                    vm.edit { it.copy(pilotType = k) }
                                })
                            }
                        }
                    }
                }
                RbDivider()

                FloatRow(onFloat = { v ->
                    Prefs.setFloat(v)
                    if (v && Build.VERSION.SDK_INT >= 23 && !android.provider.Settings.canDrawOverlays(ctx) && AccSvc.inst == null) {
                        toast("Izin overlay belum aktif. Ikuti langkah di Pengaturan & izin.")
                        screen = 1
                    }
                })
                RbDivider()

                // ===== 6. LOG =====
                Row(Modifier.fillMaxWidth().height(34.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Log", Modifier.weight(1f), fontSize = 13.sp, fontWeight = FontWeight.Medium)
                    TextButton(
                        onClick = {
                            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                            cm.setPrimaryClip(android.content.ClipData.newPlainText("log", logs.joinToString("\n") { logPlain(it) }))
                            toast("Log berhasil disalin")
                        },
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                    ) { Text("Salin", fontSize = 12.sp) }
                    TextButton(
                        onClick = { Bus.clear() },
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                    ) { Text("Bersihkan", fontSize = 12.sp) }
                }
              }
              }
              item {
                LazyColumn(state = logLs, modifier = Modifier.fillMaxWidth().height(200.dp)) {
                    items(logs) { LogLine(it) }
                }
              }
              item { RbDivider() }
            }
        }
    }
    }
    }

    renameId?.let { id ->
        var t by remember(id) { mutableStateOf(cfgs.firstOrNull { it.id == id }?.name ?: "") }
        var tg by remember(id) { mutableStateOf(cfgs.firstOrNull { it.id == id }?.customTag ?: "") }
        AlertDialog(
            onDismissRequest = { renameId = null },
            title = { Text("Edit config") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(value = t, onValueChange = { t = it }, singleLine = true, label = { Text("Nama") })
                    OutlinedTextField(
                        value = tg, onValueChange = { tg = it }, singleLine = true,
                        label = { Text("Tag (Opsional)") }, placeholder = { Text("[SSL] / [WS 80]") }
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (t.isNotBlank()) vm.rename(id, t.trim(), tg.trim())
                    renameId = null
                }) { Text("Simpan") }
            },
            dismissButton = { TextButton(onClick = { renameId = null }) { Text("Batal") } }
        )
    }

    dupId?.let { id ->
        var dn by remember(id) { mutableStateOf(cfgs.firstOrNull { it.id == id }?.name ?: "") }
        AlertDialog(
            onDismissRequest = { dupId = null },
            title = { Text("Duplicate config") },
            text = {
                OutlinedTextField(value = dn, onValueChange = { dn = it }, singleLine = true, label = { Text("Nama Config Baru") })
            },
            confirmButton = {
                TextButton(onClick = {
                    if (dn.isNotBlank()) vm.duplicate(id, dn.trim())
                    dupId = null
                }) { Text("Simpan") }
            },
            dismissButton = { TextButton(onClick = { dupId = null }) { Text("Batal") } }
        )
    }

    if (showUdpgw) {
        val opts = listOf(
            Triple(0, "Unduh / Download (Koneksi Utama)", "Gunakan koneksi SSH utama (TCP) untuk mengunduh file besar."),
            Triple(7200, "Game Online (Port 7200)", "Stabil untuk Mobile Legends/PUBG."),
            Triple(7100, "Panggilan Suara/Video (Port 7100)", "Optimal untuk WhatsApp/Telegram."),
            Triple(7300, "Universal (Port 7300)", "Mendukung hampir semua aplikasi UDP.")
        )
        AlertDialog(
            onDismissRequest = { showUdpgw = false },
            title = { Text("Pengaturan UDPGW") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    opts.forEach { (port, title, desc) ->
                        Row(
                            Modifier.fillMaxWidth().clickable {
                                Prefs.setUdpgw(port)
                                showUdpgw = false
                                toast(if (port == 0) "Mode Unduh/Download dipilih" else "UDPGW port $port dipilih")
                            },
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(selected = udpgw == port, onClick = {
                                Prefs.setUdpgw(port)
                                showUdpgw = false
                                toast(if (port == 0) "Mode Unduh/Download dipilih" else "UDPGW port $port dipilih")
                            })
                            Column(Modifier.weight(1f)) {
                                Text(title, style = MaterialTheme.typography.bodyLarge)
                                Text(desc, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showUdpgw = false }) { Text("Tutup") } }
        )
    }

    delId?.let { id ->
        AlertDialog(
            onDismissRequest = { delId = null },
            title = { Text("Hapus config?") },
            text = { Text("Config \"${cfgs.firstOrNull { it.id == id }?.name ?: ""}\" akan dihapus permanen.") },
            confirmButton = {
                TextButton(onClick = {
                    vm.delete(id)
                    delId = null
                }) { Text("Hapus") }
            },
            dismissButton = { TextButton(onClick = { delId = null }) { Text("Batal") } }
        )
    }

    pending?.let { l ->
        AlertDialog(
            onDismissRequest = { pending = null },
            title = { Text("Config sudah ada") },
            text = {
                Text("${vm.conflicts(l)} dari ${l.size} config punya ID yang sama dengan config yang ada. Timpa atau simpan sebagai salinan baru?")
            },
            confirmButton = {
                Row {
                    TextButton(onClick = {
                        vm.importConfigs(l, false)
                        pending = null
                        toast("Dipulihkan sebagai salinan")
                    }) { Text("Salinan") }
                    TextButton(onClick = {
                        vm.importConfigs(l, true)
                        pending = null
                        toast("Config ditimpa")
                    }) { Text("Timpa") }
                }
            },
            dismissButton = { TextButton(onClick = { pending = null }) { Text("Batal") } }
        )
    }
}


/** Catat posisi atas (root) & tinggi box untuk logika geser urutan config. */
private fun Modifier.trackBox(cb: (Pair<Float, Float>) -> Unit): Modifier =
    this.onGloballyPositioned { cb(it.positionInRoot().y to it.size.height.toFloat()) }

/** Catat posisi atas (root) & tinggi item config; dipasang SEBELUM graphicsLayer agar tidak terpengaruh translasi. */
private fun Modifier.trackItem(cb: (Float, Float) -> Unit): Modifier =
    this.onGloballyPositioned { cb(it.positionInRoot().y, it.size.height.toFloat()) }
