package com.alfy.tunnel

/**
 * Kontrak transport yang dipakai TunStack & VpnSvc.
 * SshLink mengimplementasikan ini sehingga logika TCP/IP stack di TunStack.kt tidak perlu tahu/berubah soal transport apa yang dipakai.
 */
interface TunnelLink {
    val alive: Boolean
    /** Host SSH yang sedang aktif (dipakai klien UDPGW). */
    val host: String
    fun connect()
    fun close()
    fun open(host: String, port: Int): SshChan
}
