package com.alfy.tunnel

import android.net.VpnService
import net.schmizz.sshj.DefaultConfig
import net.schmizz.sshj.SSHClient
import net.schmizz.sshj.connection.channel.direct.DirectConnection
import net.schmizz.sshj.transport.verification.PromiscuousVerifier
import java.io.FilterInputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.io.PushbackInputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.net.SocketAddress
import java.security.Security
import javax.net.SocketFactory
import java.security.cert.X509Certificate
import javax.net.ssl.SNIHostName
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSocket
import javax.net.ssl.X509TrustManager

private const val UA = "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120.0 Mobile Safari/537.36"

class SshLink(private val svc: VpnService, private val cfg: Config) : TunnelLink {
    @Volatile private var ses: SSHClient? = null
    @Volatile private var pending: Socket? = null
    private val dnsCache = HashMap<String, InetAddress>()
    @Volatile private var pin: PushbackInputStream? = null
    // Status pembaca Server Message (stream): dipakai supaya "Connected" baru dicatat setelah banner selesai.
    @Volatile private var bnUsed = false
    @Volatile private var bnDone = false
    @Volatile private var bnLast = 0L

    /** Tunggu pembaca banner (InputStream) selesai membaca semua teks server (maks [maxMs]). */
    private fun awaitBanner(maxMs: Long = 2500L) {
        if (!bnUsed) return
        val t0 = android.os.SystemClock.elapsedRealtime()
        while (android.os.SystemClock.elapsedRealtime() - t0 < maxMs) {
            val now = android.os.SystemClock.elapsedRealtime()
            val quiet = bnLast == 0L || now - bnLast >= 250L
            if (bnDone && quiet) return
            Thread.sleep(50)
        }
    }

    companion object {
        init {
            try {
                Security.removeProvider("BC")
                Security.insertProviderAt(Class.forName("org.bouncycastle.jce.provider.BouncyCastleProvider").getDeclaredConstructor().newInstance() as java.security.Provider, 1)
            } catch (e: Throwable) { }
        }
        private var rot = 0
        private val splitRe = Regex("""\[(split|instant_split|splitNoDelay|delay_split|split_delay|delay[=_]\d+)\]""", RegexOption.IGNORE_CASE)
        private val multiRe = Regex("""\[(crlf|cr|lf)\*(\d+)\]""", RegexOption.IGNORE_CASE)
        private val authRe = Regex("""\[auth\](\[crlf\])?""", RegexOption.IGNORE_CASE)
        private val rotRe = Regex("""\[rotate[=_]([^\]]*)\]""", RegexOption.IGNORE_CASE)
    }

    override val host: String get() = Srv.parse(cfg.server)?.host ?: ""

    override val alive: Boolean get() = ses?.let { it.isConnected && it.isAuthenticated } == true

    override fun connect() {
        close()
        bnUsed = false
        bnDone = false
        bnLast = 0L
        val sv = Srv.parse(cfg.server) ?: throw IOException("Format server salah")
        val sock = prepare(sv)
        val s = SSHClient(DefaultConfig().apply {
            keepAliveProvider = net.schmizz.keepalive.KeepAliveProvider.KEEP_ALIVE
            applyPilot(this)
            if (Prefs.useCompression.value) {
                try {
                    compressionFactories = listOf<net.schmizz.sshj.common.Factory.Named<net.schmizz.sshj.transport.compression.Compression>>(
                        net.schmizz.sshj.transport.compression.DelayedZlibCompression.Factory(),
                        net.schmizz.sshj.transport.compression.ZlibCompression.Factory(),
                        net.schmizz.sshj.transport.compression.NoneCompression.Factory()
                    )
                } catch (t: Throwable) { }
            }
        })
        s.addHostKeyVerifier(PromiscuousVerifier())
        s.connectTimeout = 20000
        s.timeout = 20000
        // Keep-alive SSH: ketuk server tiap 15 dtk, putus setelah 4x tanpa balasan (diset sebelum connect)
        try {
            val ka0 = s.connection.keepAlive
            ka0.keepAliveInterval = 15
            try { ka0.javaClass.getMethod("setMaxAliveCount", Int::class.javaPrimitiveType).invoke(ka0, 4) } catch (x: Throwable) { }
        } catch (x: Throwable) { }
        s.setSocketFactory(object : SocketFactory() {
            override fun createSocket(): Socket = wrap(sock)
            override fun createSocket(host: String?, port: Int): Socket = wrap(sock)
            override fun createSocket(host: String?, port: Int, la: InetAddress?, lp: Int): Socket = wrap(sock)
            override fun createSocket(host: InetAddress?, port: Int): Socket = wrap(sock)
            override fun createSocket(host: InetAddress?, port: Int, la: InetAddress?, lp: Int): Socket = wrap(sock)
        })
        try {
            s.connect(resolve(sv.host), sv.port)
            try {
                if (cfg.privateKey.isNotBlank()) authKey(s, sv) else s.authPassword(sv.user, sv.pass)
            } catch (ae: Exception) {
                try { s.disconnect() } catch (x: Exception) { }
                try { sock.close() } catch (x: Exception) { }
                Bus.log("Auth failed")
                throw IOException("Auth failed")
            }
            try {
                s.connection.keepAlive.keepAliveInterval = 15
                val ka = s.connection.keepAlive
                ka.javaClass.getMethod("setMaxAliveCount", Int::class.javaPrimitiveType).invoke(ka, 4)
            } catch (x: Throwable) { }
            try { sock.keepAlive = true; sock.tcpNoDelay = true } catch (x: Exception) { }
            // soTimeout WAJIB 0 setelah auth: thread pembaca sshj akan melempar SocketTimeoutException
            // (dan memutus sesi) bila server diam > timeout. Deteksi mati diserahkan ke keep-alive SSH.
            try { s.timeout = 0 } catch (x: Throwable) { }
            try { sock.soTimeout = 0 } catch (x: Throwable) { }
        } catch (e: Exception) {
            if (e is IOException && e.message == "Auth failed") throw e
            try { s.disconnect() } catch (x: Exception) { }
            try { sock.close() } catch (x: Exception) { }
            throw IOException("SSH gagal: ${e.message}")
        }
        ses = s
        pending = null
        // Urutan: SSH-2.0-... -> Server Message (banner) -> Auth complete -> Connected.
        awaitBanner()
        grabBanner(s)
        Bus.log("Auth complete")
    }

    /** Autentikasi Private Key; bila key gagal dimuat dan password tersedia, fallback ke password (dengan log). */
    private fun authKey(s: SSHClient, sv: Srv) {
        val kp = try {
            val pf: net.schmizz.sshj.userauth.password.PasswordFinder? =
                if (cfg.keyPass.isBlank()) null
                else net.schmizz.sshj.userauth.password.PasswordUtils.createOneOff(cfg.keyPass.toCharArray())
            s.loadKeys(cfg.privateKey.trim().replace("\r\n", "\n"), null, pf)
        } catch (e: Throwable) {
            Bus.log("Private Key gagal dimuat: ${e.message ?: e.javaClass.simpleName}")
            if (sv.pass.isEmpty()) throw IOException("Private Key tidak valid")
            Bus.log("Fallback ke login password")
            s.authPassword(sv.user, sv.pass)
            return
        }
        Bus.log("Auth dengan Private Key")
        s.authPublickey(sv.user, kp)
    }

    /** Pilot SSH: batasi daftar KEX/Cipher/HostKey sesuai cfg.pilotType. AUTO = default universal (tidak diubah). */
    private fun applyPilot(c: net.schmizz.sshj.Config) {
        val kex: Set<String>
        val ciph: Set<String>
        val hk: Set<String>?
        when {
            cfg.pilotType.equals("OPENSSH", ignoreCase = true) -> {
                kex = setOf("curve25519-sha256", "ecdh-sha2-nistp256")
                ciph = setOf("chacha20-poly1305@openssh.com", "aes128-ctr", "aes256-ctr")
                hk = null
            }
            cfg.pilotType.equals("DROPBEAR", ignoreCase = true) -> {
                kex = setOf("diffie-hellman-group14-sha1")
                ciph = setOf("aes128-cbc", "3des-cbc")
                hk = setOf("ssh-rsa")
            }
            else -> return
        }
        try {
            val k = c.keyExchangeFactories.filter { it.name in kex }
            if (k.isNotEmpty()) c.keyExchangeFactories = k
            val ci = c.cipherFactories.filter { it.name in ciph }
            if (ci.isNotEmpty()) c.cipherFactories = ci
            if (hk != null) {
                val h = c.keyAlgorithms.filter { it.name in hk }
                if (h.isNotEmpty()) c.keyAlgorithms = h
            }
            Bus.log("Pilot SSH: ${cfg.pilotType.uppercase()} (KEX=${c.keyExchangeFactories.size}, Cipher=${c.cipherFactories.size})")
        } catch (e: Throwable) {
            Bus.log("Pilot SSH gagal diterapkan, pakai default: ${e.message}")
        }
    }

    override fun open(host: String, port: Int): SshChan {
        val s = ses?.takeIf { it.isConnected && it.isAuthenticated } ?: throw IOException("SSH tidak terhubung")
        return SshChan(s, host, port)
    }

    private fun wrap(d: Socket): Socket = object : Socket() {
        override fun connect(ep: SocketAddress?) {}
        override fun connect(ep: SocketAddress?, timeout: Int) {}
        override fun isConnected(): Boolean = d.isConnected
        override fun isClosed(): Boolean = d.isClosed
        override fun close() { d.close() }
        override fun setSoTimeout(t: Int) { d.soTimeout = t }
        override fun getSoTimeout(): Int = d.soTimeout
        override fun setTcpNoDelay(on: Boolean) { d.tcpNoDelay = on }
        override fun getTcpNoDelay(): Boolean = d.tcpNoDelay
        override fun setKeepAlive(on: Boolean) { d.keepAlive = on }
        override fun getInetAddress(): InetAddress? = d.inetAddress
        override fun getPort(): Int = d.port
        override fun getRemoteSocketAddress(): SocketAddress? = d.remoteSocketAddress
        override fun shutdownInput() { d.shutdownInput() }
        override fun shutdownOutput() { d.shutdownOutput() }
        override fun getOutputStream(): OutputStream = d.getOutputStream()
        override fun getInputStream(): InputStream = object : FilterInputStream(pin ?: d.getInputStream()) {
            private val sb = StringBuilder()
            private var done = false
            private var hdr = false
            private var lines = 0
            init { bnUsed = true; bnDone = false; bnLast = android.os.SystemClock.elapsedRealtime() }
            private fun emit(t: String) {
                val tr = t.trim()
                if (tr.isEmpty()) return
                if (tr.startsWith("SSH-2.0-") || tr.startsWith("SSH-1.")) { Bus.log(tr, true); lines++; bnLast = android.os.SystemClock.elapsedRealtime(); return }
                if (!hdr) { hdr = true; Bus.log("Server Message:", true) }
                Bus.log(tr, true)
                lines++
                bnLast = android.os.SystemClock.elapsedRealtime()
            }
            private fun finish() {
                if (sb.isNotEmpty()) emit(sb.toString())
                sb.setLength(0)
                done = true
                bnDone = true
            }
            private fun feed(b: Int) {
                if (done) return
                if (b == 10) { emit(sb.toString()); sb.setLength(0); if (lines >= 500) { done = true; bnDone = true }; return }
                if (b == 13) return
                if (b != 9 && (b < 32 || b > 126)) { finish(); return }
                sb.append(b.toChar())
                if (sb.length > 4096) finish()
            }
            override fun read(): Int {
                val c = super.read()
                if (c >= 0) feed(c)
                return c
            }
            override fun read(b: ByteArray, off: Int, len: Int): Int {
                val n = super.read(b, off, len)
                if (!done && n > 0) { for (i in 0 until n) { if (done) break; feed(b[off + i].toInt() and 255) } }
                return n
            }
        }
    }

    /** Banner SSH_MSG_USERAUTH_BANNER (Server Message sesudah auth): diambil via refleksi, semua baris ke log UI. */
    private fun grabBanner(s: SSHClient) {
        try {
            var ua: Any? = try { s.javaClass.getMethod("getUserAuth").invoke(s) } catch (e: Throwable) { null }
            if (ua == null) {
                var k: Class<*>? = s.javaClass
                while (k != null && ua == null) {
                    try { val f = k.getDeclaredField("userAuth"); f.isAccessible = true; ua = f.get(s) } catch (e: Throwable) { }
                    k = k.superclass
                }
            }
            if (ua == null) return
            var txt: String? = try { ua.javaClass.getMethod("getBanner").invoke(ua) as? String } catch (e: Throwable) { null }
            if (txt.isNullOrBlank()) {
                var k: Class<*>? = ua.javaClass
                while (k != null && txt.isNullOrBlank()) {
                    for (f in k.declaredFields) {
                        if (f.type == String::class.java && f.name.contains("banner", true)) {
                            try { f.isAccessible = true; txt = f.get(ua) as? String } catch (e: Throwable) { }
                            if (!txt.isNullOrBlank()) break
                        }
                    }
                    k = k.superclass
                }
            }
            if (txt.isNullOrBlank()) return
            Bus.log("Server Message:", true)
            Bus.log(HTML_MARK + txt.replace("\r", "").trim(), true)
        } catch (e: Throwable) { }
    }

    override fun close() {
        try { pending?.close() } catch (e: Exception) { }
        pending = null
        try { ses?.disconnect() } catch (e: Exception) { }
        ses = null
        synchronized(dnsCache) { dnsCache.clear() }
    }

    private fun resolve(h: String): InetAddress = synchronized(dnsCache) {
        dnsCache.getOrPut(h) {
            // DNS dibatasi 8 dtk supaya tidak menggantung saat jaringan belum siap
            val res = arrayOfNulls<InetAddress>(1)
            val t = Thread { try { res[0] = InetAddress.getByName(h) } catch (e: Exception) { } }.also { it.isDaemon = true; it.start() }
            try { t.join(8000) } catch (e: InterruptedException) { throw e }
            res[0] ?: throw IOException("Host tidak ditemukan: $h")
        }
    }

    private fun rep(s: String, tag: String, v: String) = s.replace("[$tag]", v, ignoreCase = true)

    private fun payloadRaw(sv: Srv): String {
        val px = if (cfg.proxy.isBlank()) null else parseProxy(cfg.proxy)
        // Fallback: Mode 0 (Proxy) + Proxy terisi + Payload kosong -> kirim HTTP CONNECT standar.
        if (cfg.mode == 0 && px != null && cfg.payload.isBlank()) {
            val hp0 = "${sv.host}:${sv.port}"
            return "CONNECT $hp0 HTTP/1.1\r\nHost: $hp0\r\n" + (px.hdr?.let { "$it\r\n" } ?: "") + "\r\n"
        }
        var r = cfg.payload.ifBlank { Config.DEFAULT_PAYLOAD }
        // Baris baru asli (\r / \n) hanya dibuang bila user memakai [crlf] atau [split]; selain itu dibiarkan apa adanya.
        if (r.contains("[crlf]", ignoreCase = true) || r.contains("[lfcr]", ignoreCase = true) || multiRe.containsMatchIn(r) || splitRe.containsMatchIn(r)) {
            r = r.replace("\r", "").replace("\n", "")
        }
        r = r.replace("\\r", "\r").replace("\\n", "\n").replace("\\t", "\t")
        r = authRe.replace(r) { m -> px?.hdr?.let { it + m.groupValues[1] } ?: "" }
        val sni = cfg.sni.trim().ifEmpty { sv.host }
        r = rotRe.replace(r) { m ->
            val items = m.groupValues[1].split(';', ',', '|').map { it.trim() }.filter { it.isNotEmpty() }
            if (items.isEmpty()) "" else items[rot % items.size]
        }
        val hp = "${sv.host}:${sv.port}"
        r = rep(r, "host_port", hp)
        r = rep(r, "ssh_host", sv.host)
        r = rep(r, "ssh_port", sv.port.toString())
        r = rep(r, "ssh_host_port", hp)
        r = rep(r, "proxy_host", px?.host ?: sv.host)
        r = rep(r, "proxy_port", (px?.port ?: sv.port).toString())
        r = rep(r, "sni", sni)
        r = rep(r, "host", sv.host)
        r = rep(r, "port", sv.port.toString())
        r = rep(r, "ip", try { resolve(sv.host).hostAddress ?: sv.host } catch (e: Exception) { sv.host })
        r = rep(r, "protocol", "HTTP/1.1")
        r = rep(r, "method", "CONNECT")
        r = rep(r, "netData", "CONNECT $hp HTTP/1.1")
        r = rep(r, "raw", "CONNECT $hp HTTP/1.1[crlf][crlf]")
        r = rep(r, "realData", "CONNECT $hp HTTP/1.1\r\nHost: $hp\r\n\r\n")
        r = rep(r, "random", java.util.UUID.randomUUID().toString().take(8))
        return r
    }

    private fun expand(r: String): String =
        multiRe.replace(r) { m ->
            val n = (m.groupValues[2].toIntOrNull() ?: 1).coerceIn(1, 20)
            when (m.groupValues[1].lowercase()) { "crlf" -> "\r\n"; "cr" -> "\r"; else -> "\n" }.repeat(n)
        }.replace("[lfcr]", "\n\r", ignoreCase = true)
            .replace("[ua]", UA, ignoreCase = true)
            .replace("[crlf]", "\r\n", ignoreCase = true).replace("[cr]", "\r", ignoreCase = true)
            .replace("[lf]", "\n", ignoreCase = true)

    private fun sendPayload(s: Socket, sv: Srv) {
        val raw = payloadRaw(sv)
        Bus.log("Sending Payload: $raw")
        var last = 0
        var delay = 0L
        val ms = splitRe.findAll(raw).toList()
        val parts = ArrayList<Pair<Long, String>>()
        for (m in ms) {
            parts.add(delay to raw.substring(last, m.range.first))
            val t = m.groupValues[1].lowercase()
            delay = when {
                t == "instant_split" || t == "splitnodelay" -> 0L
                t == "delay_split" || t == "split_delay" -> 1500L
                t.startsWith("delay") -> t.filter { it.isDigit() }.toLongOrNull()?.coerceIn(0L, 10000L) ?: 300L
                else -> 0L
            }
            last = m.range.last + 1
        }
        parts.add(delay to raw.substring(last))
        for ((d, p) in parts) {
            if (d > 0) Thread.sleep(d)
            val t = expand(p)
            if (t.isNotEmpty()) send(s, t)
        }
    }

    private fun esc(t: String) = t.replace("\r", "\\r").replace("\n", "\\n")

    private fun prepare(sv: Srv): Socket {
        val px = if (cfg.proxy.isBlank()) null else parseProxy(cfg.proxy)
        val tls = cfg.mode == 1
        val tHost = px?.host ?: sv.host
        val tPort = px?.port ?: sv.port
        rot++
        pin = null
        Bus.log("Connecting to proxy $tHost port $tPort")
        val addr = resolve(tHost)
        Bus.log("Ip resolved, ${addr.hostAddress}")
        var s = Socket()
        pending = s
        svc.protect(s)
        s.keepAlive = true
        s.tcpNoDelay = true
        s.connect(InetSocketAddress(addr, tPort), 15000)
        s.soTimeout = 15000
        if (!tls) {
            pin = PushbackInputStream(s.getInputStream(), 16)
            sendPayload(s, sv)
            val rl = readHttp(pin!!)
            if (cfg.mode == 0 && cfg.wsFrame) {
                if (Regex("""\s101(\s|$)""").containsMatchIn(rl)) {
                    val ws = WsSocket(s, pin!!)
                    pin = PushbackInputStream(ws.getInputStream(), 16)
                    s = ws
                    Bus.log("WS Framing RFC 6455 aktif")
                } else {
                    Bus.log("WS Framing dilewati: respons bukan 101")
                }
            }
        } else {
            if (px != null) {
                send(s, "CONNECT ${sv.host}:${sv.port} HTTP/1.1\r\nHost: ${sv.host}:${sv.port}\r\n" + (px.hdr?.let { "$it\r\n" } ?: "") + "\r\n")
                readHttp(PushbackInputStream(s.getInputStream(), 16))
            }
            val sni = cfg.sni.trim().ifEmpty { sv.host }
            val tm = object : X509TrustManager {
                override fun checkClientTrusted(c: Array<X509Certificate>?, a: String?) {}
                override fun checkServerTrusted(c: Array<X509Certificate>?, a: String?) {}
                override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
            }
            val ctx = SSLContext.getInstance("TLS")
            ctx.init(null, arrayOf(tm), null)
            val ssl = ctx.socketFactory.createSocket(s, sni, tPort, true) as SSLSocket
            pending = ssl
            try {
                val p = ssl.sslParameters
                p.serverNames = listOf(SNIHostName(sni))
                ssl.sslParameters = p
            } catch (e: Exception) {
                Bus.log("SNI tidak valid, dipakai default")
            }
            ssl.startHandshake()
            Bus.log("TLS OK (SNI: $sni)")
            s = ssl
            pin = PushbackInputStream(ssl.getInputStream(), 16)
            if (cfg.payload.isNotBlank()) {
                sendPayload(s, sv)
                readHttp(pin!!)
            }
        }
        // Timeout handshake hanya berlaku sampai di sini; connect() menyetelnya ke 0 setelah auth.
        s.soTimeout = 20000
        return s
    }

    private fun send(s: Socket, t: String) {
        val o = s.getOutputStream()
        o.write(t.toByteArray(Charsets.ISO_8859_1))
        o.flush()
    }

    /** Baca satu atau lebih respons HTTP. Jika server langsung mengirim banner SSH, tidak ada yang dikonsumsi. */
    private fun readHttp(i: PushbackInputStream): String {
        var first = ""
        var n = 0
        while (n < 6) {
            val head = ByteArray(5)
            var got = 0
            while (got < 5) {
                val c = try {
                    i.read(head, got, 5 - got)
                } catch (e: java.net.SocketTimeoutException) {
                    if (n > 0 && got == 0) return first
                    throw e
                }
                if (c < 0) {
                    if (got == 0 && n > 0) return first
                    throw IOException("Koneksi ditutup saat menunggu respons")
                }
                got += c
            }
            val hs = String(head, Charsets.ISO_8859_1)
            if (hs.startsWith("SSH-")) {
                i.unread(head, 0, got)
                return first
            }
            if (n > 0 && !hs.startsWith("HTTP/")) {
                i.unread(head, 0, got)
                return first
            }
            val sb = StringBuilder(hs)
            while (!sb.endsWith("\r\n\r\n")) {
                val c = i.read()
                if (c < 0) throw IOException("Koneksi ditutup saat menunggu respons")
                sb.append(c.toChar())
                if (sb.length > 8192) throw IOException("Respons terlalu panjang")
            }
            if (Prefs.dbg.value) Bus.log("H: " + esc(sb.toString()))
            val line = sb.lineSequence().first().trim()
            Bus.log("Response: $line")
            val code = line.split(" ").getOrNull(1)?.toIntOrNull()
            if (cfg.mode != 2 && (code == null || (code != 101 && code != 200 && code !in 100..199))) {
                throw IOException("Respons ditolak: $line")
            }
            if (n == 0) first = line
            n++
            val cl = Regex("content-length:\\s*(\\d+)", RegexOption.IGNORE_CASE).find(sb.toString())
                ?.groupValues?.get(1)?.toIntOrNull() ?: 0
            if (cl > 0 && code != 101 && cl <= 65536) {
                var left = cl
                while (left > 0) {
                    val c = i.read()
                    if (c < 0) break
                    left--
                }
            }
        }
        return first
    }
}

/** Channel direct-tcpip sshj dengan API sama seperti sebelumnya (inputStream, outputStream, connect, disconnect). */
class SshChan(private val cl: SSHClient, private val host: String, private val port: Int) {
    @Volatile private var dc: DirectConnection? = null
    private fun d(): DirectConnection = dc ?: throw IOException("Channel belum terbuka")
    val inputStream: InputStream = object : InputStream() {
        override fun read(): Int = d().inputStream.read()
        override fun read(b: ByteArray, off: Int, len: Int): Int = d().inputStream.read(b, off, len)
        override fun available(): Int = dc?.inputStream?.available() ?: 0
    }
    val outputStream: OutputStream = object : OutputStream() {
        override fun write(b: Int) { d().outputStream.write(b) }
        override fun write(b: ByteArray, off: Int, len: Int) { d().outputStream.write(b, off, len) }
        override fun flush() { dc?.outputStream?.flush() }
    }
    fun connect(@Suppress("UNUSED_PARAMETER") timeoutMs: Int) {
        dc = cl.newDirectConnection(host, port)
    }
    fun disconnect() { try { dc?.close() } catch (e: Exception) { } }
}

/** Socket pembungkus: output di-frame binary RFC 6455 (masked), input di-unframe. Metode lain didelegasikan ke socket asli. */
private class WsSocket(private val d: Socket, src: InputStream) : Socket() {
    private val out = WsOut(d.getOutputStream())
    private val inp = WsIn(src, out)
    override fun connect(ep: SocketAddress?) {}
    override fun connect(ep: SocketAddress?, timeout: Int) {}
    override fun isConnected(): Boolean = d.isConnected
    override fun isClosed(): Boolean = d.isClosed
    override fun close() { d.close() }
    override fun setSoTimeout(t: Int) { d.soTimeout = t }
    override fun getSoTimeout(): Int = d.soTimeout
    override fun setTcpNoDelay(on: Boolean) { d.tcpNoDelay = on }
    override fun getTcpNoDelay(): Boolean = d.tcpNoDelay
    override fun setKeepAlive(on: Boolean) { d.keepAlive = on }
    override fun getInetAddress(): InetAddress? = d.inetAddress
    override fun getPort(): Int = d.port
    override fun getRemoteSocketAddress(): SocketAddress? = d.remoteSocketAddress
    override fun shutdownInput() { d.shutdownInput() }
    override fun shutdownOutput() { d.shutdownOutput() }
    override fun getOutputStream(): OutputStream = out
    override fun getInputStream(): InputStream = inp
}

private class WsOut(private val o: OutputStream) : OutputStream() {
    private val rnd = java.security.SecureRandom()
    private val lock = Any()

    fun frame(op: Int, b: ByteArray, off: Int, len: Int) {
        val hl = if (len < 126) 2 else if (len <= 0xFFFF) 4 else 10
        val f = ByteArray(hl + 4 + len)
        f[0] = op.toByte()
        when (hl) {
            2 -> f[1] = (0x80 or len).toByte()
            4 -> { f[1] = (0x80 or 126).toByte(); f[2] = (len shr 8).toByte(); f[3] = len.toByte() }
            else -> {
                f[1] = (0x80 or 127).toByte()
                for (i in 0 until 8) f[2 + i] = ((len.toLong() shr (8 * (7 - i))) and 0xFF).toByte()
            }
        }
        val mk = ByteArray(4).also { rnd.nextBytes(it) }
        System.arraycopy(mk, 0, f, hl, 4)
        for (i in 0 until len) f[hl + 4 + i] = (b[off + i].toInt() xor mk[i and 3].toInt()).toByte()
        synchronized(lock) { o.write(f); o.flush() }
    }

    override fun write(b: Int) { frame(0x82, byteArrayOf(b.toByte()), 0, 1) }
    override fun write(b: ByteArray, off: Int, len: Int) { if (len > 0) frame(0x82, b, off, len) }
    override fun flush() { synchronized(lock) { o.flush() } }
    override fun close() { o.close() }
}

private class WsIn(private val src: InputStream, private val out: WsOut) : InputStream() {
    private var remaining = 0L
    private var masked = false
    private val mask = ByteArray(4)
    private var mpos = 0
    private var eof = false

    private fun rb(): Int { val c = src.read(); if (c < 0) throw IOException("WS: koneksi terputus"); return c }
    private fun fill(b: ByteArray, n: Int) { var g = 0; while (g < n) { val c = src.read(b, g, n - g); if (c < 0) throw IOException("WS: koneksi terputus"); g += c } }

    /** Baca header frame berikutnya; bila frame data, set [remaining]. Return false bila EOF/close. */
    private fun nextFrame(): Boolean {
        while (true) {
            val b0 = src.read()
            if (b0 < 0) { eof = true; return false }
            val b1 = rb()
            val op = b0 and 0x0F
            var len = (b1 and 0x7F).toLong()
            if (len == 126L) len = ((rb() shl 8) or rb()).toLong()
            else if (len == 127L) { len = 0; for (i in 0 until 8) len = (len shl 8) or rb().toLong() }
            masked = (b1 and 0x80) != 0
            if (masked) { fill(mask, 4) }
            mpos = 0
            when (op) {
                0, 1, 2 -> { remaining = len; if (len > 0) return true }
                8 -> {
                    val p = ByteArray(minOf(len, 125L).toInt()); fill(p, p.size)
                    try { out.frame(0x88, p, 0, p.size) } catch (e: Exception) { }
                    eof = true; return false
                }
                9 -> {
                    val p = ByteArray(minOf(len, 125L).toInt()); fill(p, p.size)
                    if (masked) for (i in p.indices) p[i] = (p[i].toInt() xor mask[i and 3].toInt()).toByte()
                    out.frame(0x8A, p, 0, p.size)
                }
                10 -> skipN(len)
                else -> throw IOException("WS: opcode tidak dikenal $op")
            }
        }
    }

    private fun skipN(n: Long) { var l = n; while (l > 0) { rb(); l-- } }

    override fun read(): Int {
        val a = ByteArray(1)
        while (true) { val n = read(a, 0, 1); if (n < 0) return -1; if (n > 0) return a[0].toInt() and 255 }
    }

    override fun read(b: ByteArray, off: Int, len: Int): Int {
        if (len == 0) return 0
        if (eof) return -1
        if (remaining == 0L && !nextFrame()) return -1
        val n = src.read(b, off, minOf(len.toLong(), remaining).toInt())
        if (n < 0) throw IOException("WS: koneksi terputus")
        if (masked) for (i in 0 until n) b[off + i] = (b[off + i].toInt() xor mask[mpos++ and 3].toInt()).toByte()
        remaining -= n
        return n
    }

    override fun available(): Int = if (remaining > 0) minOf(remaining, src.available().toLong()).toInt() else 0
    override fun close() { src.close() }
}
