-keep class net.schmizz.sshj.** { *; }
-keep class com.hierynomus.** { *; }
-keep class org.bouncycastle.** { *; }
-keep class net.i2p.crypto.eddsa.** { *; }
-allowaccessmodification
-repackageclasses ""
-dontwarn **
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod
-keep class com.alfy.tunnel.MainVM { *; }
-keep class com.jcraft.jzlib.** { *; }
-keep class com.alfy.tunnel.OrigDst { *; }

# hev-socks5-tunnel (JNI): nama kelas & method native harus tetap
-keep class hev.htproxy.** { *; }
-dontwarn hev.htproxy.**
